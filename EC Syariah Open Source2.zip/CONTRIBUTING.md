# Contributing to EC Syariah Global

Thanks for considering a contribution! This project is a single-file Discord bot (`index.js`) on purpose — no build step, no framework, just Node.js and `discord.js`. Please keep that simplicity in mind.

## Before you start

- **Open an issue first** for anything beyond a small fix — new features, command changes, or restructuring. It saves everyone time if the approach is agreed on before code is written.
- Skim the changelog table in `README.md` to see how past changes were scoped and described — most updates here are intentionally small and self-contained.

## Ground rules for this project specifically

These aren't arbitrary style preferences — they reflect why this bot exists:

1. **No riba, no maysir, no gharar.** Any new economic feature must not introduce interest, a guaranteed fixed return on capital, gambling mechanics, or hidden/ambiguous terms. If you're unsure whether a feature fits, open an issue and ask before building it.
2. **Keep it lightweight.** No new npm dependencies unless there's genuinely no reasonable way to do it with what's already installed (`discord.js`, `dotenv`, and Node's built-ins). No database servers — `database.json` is intentional.
3. **English only**, in code, comments, command names/descriptions, and user-facing text.
4. **Every server is independent.** Settings, balances, markets, etc. are always keyed by guild ID. A feature that leaks or shares data across servers is a bug.
5. **Respect Discord's API limits.** Slash command/option names ≤32 characters, descriptions ≤100 characters, required options before optional ones. Run `node -c index.js` before opening a PR — it won't catch everything, but it catches typos.

## Making a change

1. Fork the repo and create a branch off `main`.
2. Copy `.env.example` to `.env` and fill in a **test bot's** token/client ID — never use a production bot for development.
3. `npm install`, then `npm start` to run it against your test server.
4. Add a row to the changelog table in `README.md` describing your change, following the existing format (version bump per semantic versioning: patch for bugfixes, minor for new features, major for breaking changes).
5. Open a pull request describing what changed and why.

## Reporting a bug

Please include:
- What command you ran and what happened vs. what you expected
- The relevant console log lines, if the bot crashed or logged an error
- Your `discord.js` and Node.js versions (`node -v`)

## Code of conduct

Be respectful. Disagreements about implementation are fine and expected — personal attacks aren't.
