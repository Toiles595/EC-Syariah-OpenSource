# EC Syariah Global — v3.8.2

Discord economy bot built on Islamic finance principles. Single file (`index.js`), JSON storage (`database.json` — created automatically on first run).

## Versioning

This project follows an incrementing naming convention: **EC Syariah Global 1A**, then `1B`, `1C`, ... for small updates, moving to `2A` for a bigger overhaul. The current version is set in `CONFIG.VERSION` at the top of `index.js` and shown via `/economy about` and the bot's Discord presence.

| Version | Changes |
|---|---|
| 1A | English commands, profession system (`/profession`), interactive `/work` with button + progress bar, global slash command registration, `/about` command |
| 1B | Added `/setcurrency-emoji` (admin-only) to customize the currency symbol shown everywhere, using either a server custom emoji or any regular emoji |
| 1.1.2D | Added `/profile` (combined balance + profession + level + badge card); added `/rolereward` (admin) to auto-grant a Discord role once a member's balance hits a threshold — **requires the privileged Server Members Intent**; added `/backup` (admin) to export this server's own economy data as a JSON file; **replaced the static market catalog with a player-driven market**: `/addmarket`, `/removemarket`, `/allserver-market`, `/marketsearch`. (1.1.2D also fixes an `/addmarket` option-order bug that caused Discord to reject the entire command registration batch.) |
| 1.2.1 | Added `/hijri` (check today's Hijri calendar date on demand) and `/autocalendar channel \| disable \| status` (admin) — auto-posts the daily Hijri date to a chosen channel every day at **18:00 WIB (Maghrib)** — the Islamic day begins at sunset, not midnight — using Node's built-in Islamic calendar (no external API) |
| 1.2.2 | Added `/setadzan-channel`, `/removeadzan-channel`, and `/adzan-channels` — automatic prayer time (adzan) reminders, supporting **multiple channels at once**, each with its own location (`Country/City` or `Country/City/Province`). Powered by the free [AlAdhan API](https://aladhan.com/prayer-times-api), using the KEMENAG (Indonesian Ministry of Religious Affairs) calculation method by default. **Requires Node.js 18+** (uses the built-in `fetch`) |
| 1.3.0 | Added a real item-purchasing system: `/additem` (image + description + price + optional stock), `/removeitem`, and `/buy` — shows a clean item card (big image, description, price, stock) with a **Buy** button that instantly transfers currency from buyer to seller and decrements stock. Existing simple `/addmarket` listings still work unchanged as display-only "legacy" items |
| **2.5.0** | **Complete command overhaul.** All 26 flat top-level commands were regrouped into 6 clean, modern parent commands with subcommands/subcommand groups — `/economy`, `/profession`, `/finance`, `/market`, `/islamic`, and `/admin` (all admin-only actions consolidated into one place). No feature was removed — this is a routing/organization change only, so all mechanics, cooldowns, and data behave exactly as before. |

| **2.5.1** | After a `/market buy` purchase completes, the bot now **DMs the buyer** a receipt embed (including the item's description, market, seller, and price paid) and **DMs the seller** a sale notification. Both DMs are best-effort — if a user's DMs are closed, the purchase still completes normally and the item card shows "Contact the seller" as before. |

| **2.6.0** | Verified every file (`index.js`, `README.md`, `package.json`, `.env.example`) is fully in English — no leftover non-English text found. Version bump only, no functional changes. |

| **2.7.0** | **Automatic item delivery.** Purchases made via `/market buy` (rich items added with `/market additem`) are now instantly added to the buyer's personal inventory — no more waiting on the seller to hand it over. Added `/economy inventory [user]` to view received items (name, description, price, and which market it came from). The purchase DM receipt and item card now reflect automatic delivery instead of "contact the seller." Legacy items (added the old way via `/market open`'s `item1/item2/item3`) still require contacting the owner, since they aren't real purchasable item records. |

| **2.8.0** | **Role-granting items.** `/market additem` now has an optional `role` field — the market owner picks a Discord role to attach to the item. Buyers can toggle it on/off anytime with the new `/economy use <item>`: equips the role if not active, unequips (removes it) if already active. `/economy inventory` now shows each role-item's equip status. Requires the same privileged Server Members Intent (and Manage Roles permission, role positioned above the target role) as `/admin rolereward`. |

| **2.8.1** | **Reduced RAM usage.** The Discord client now caps and periodically sweeps its internal caches (message, reaction, presence, invite, thread, and ban caches disabled entirely; member/user caches capped and swept hourly) instead of the discord.js default of caching almost everything forever. This is the main fix for a bot's memory usage slowly growing over days/weeks on hosts like Wispbyte. No behavior changed — the bot never relied on cached messages/reactions/presences in the first place. |

| **2.9.0** | **`/market open` items are now real, purchasable items — no more "additem-only" split.** Each of `item1`/`item2`/`item3` now optionally takes its own `description` (content DMed to the buyer on purchase — e.g. a docs/invite link) and its own `role` (toggleable via `/economy use`, same as items added with `/market additem`). A name with no description or role still works fine — it's just delivered by DM as a plain name. Items created this way share the market's single `allitemprice`. Markets created before this update keep working exactly as before (untouched, still legacy/contact-the-owner listings) — only newly created markets get the new behavior. |

| **2.9.1** | **🔒 Security fix: private content was leaking publicly.** In 2.9.0, an item's `description`/`item#description` was shown on the public item card in `/market buy` — meaning anyone in the channel could read it (e.g. a secret link) without paying. Fixed by splitting the field in two: a public **description** (unchanged, always visible on the item card — never put secrets here) and a new private **content** field (`/market additem`'s `content` option, `/market open`'s `item1content`/`item2content`/`item3content`) that is *only* ever sent by DM to the buyer after a successful purchase. The item card and `/economy inventory` now only show a safe "🔒 has private content, check your DMs" hint — never the content itself. If you used `item1description` etc. in 2.9.0 for secret links, recreate those items using the new `item1content` option instead. |

| **2.9.2** | **Crash fix.** The 2.9.1 privacy fix introduced two slash command option descriptions (`item1content`, `content` on `/market additem`) longer than Discord's hard 100-character limit for option descriptions, causing the bot to crash on startup with `ExpectedConstraintError: Invalid string length` while registering commands. Shortened both descriptions to fit the limit — no other behavior changed. |

| **3.0.0** | **Error reporting to an admin channel.** New `/admin errorlog channel \| disable` lets a server designate a channel that receives an embed report (context, message, truncated stack trace) whenever a command fails or the bot crashes unexpectedly (including uncaught exceptions/rejections, best-effort broadcast to every server that has it configured). This makes debugging on hosts like Wispbyte much easier — you see the actual error instead of just "server crashed" in the console. |

| **3.0.1** | **Safeguard: block links in the public `description` field.** `/market additem` now rejects (with an explanation) any `description` containing a URL, since sellers kept accidentally pasting secret links there — which is shown publicly before purchase — instead of in the private `content` field. This is a validation-only change; existing items already created with a link in `description` are **not** automatically fixed and must be recreated (`/market removeitem` then `/market additem` with the link moved to `content`). |

| **3.0.2** | **Extended the 3.0.1 safeguard to item name fields too.** Item names are always public (market listing, item card title) — so `/market open`'s `item1`/`item2`/`item3` and `/market additem`'s `name` now also reject a link, with a message pointing to the matching private `content` field (`item1content` etc., or `content`) instead. Verified all 4 project files remain fully in English. |

| **3.1.0** | **Big feature batch**, all kept intentionally lightweight (plain JSON, no new dependencies): **Anti-spam** — a 700ms per-user cooldown on every command/button. **`/admin audit`** — last 100 notable admin/economic actions per server (additem, removeitem, market open, backup, refund, edititem). **`/admin refund`** — reverses a user's purchase (refund buyer, deduct seller, remove item/role). **Market tax** — 2% of every `/market buy` sale now goes to the community zakat pool automatically. **`/market edititem`** — edit an existing item's price/description/content/image/stock/role without deleting and recreating it. **`/market auction start\|bid\|list`** — simple time-limited auctions; highest bidder wins automatically when the timer ends, item auto-delivered same as a regular purchase. **`/economy history`** — your last 10 transactions (daily, work, zakat, sedekah, mudarabah, qard, purchases, sales, refunds, auctions). **`/economy achievements`** — 5 lightweight achievements (First Purchase, Zakat Payer, Hard Worker, Investor, Generous Soul) that unlock automatically. **`/economy invite` / `/economy redeem`** — one-time referral bonus system. **`/economy quiz`** — a quick multiple-choice Islamic knowledge question every hour for a small reward. **Level-up DMs** — a one-time DM when a user's balance crosses into a new level tier. |

| **3.2.0** | **Every bot response is now an embed.** Previously many replies (confirmations, errors, cooldown notices, DMs) were plain text while others were embeds — now everything uses a consistent embed style (green for success/info, red for errors/warnings), including DMs and error messages. No functional change — this is purely a visual consistency pass. |

| **3.3.0** | **4 fixes/additions ahead of the v4.0 architecture split:** (1) **Auction bid escrow** — a bid now deducts the bidder's balance immediately and refunds whoever gets outbid, instead of only checking the balance at bid time (previously could go negative if the bidder spent the money elsewhere before the auction ended). (2) **Unique auction names** — `/market auction start` now rejects a name that's already an ongoing auction in the server. (3) **`/admin auction-cancel`** — cancel an ongoing auction, refunding the current bidder if there is one. (4) **Confirmation prompts** — `/admin refund`, `/market remove`, and `/admin auction-cancel` now show a Confirm/Cancel button before doing anything, instead of acting immediately. |

| **3.3.1** | New members now start with a balance of **0** instead of 500 (`CONFIG.STARTING_BALANCE`). Only affects brand-new user records going forward — existing members' balances are untouched. |

| **3.4.0** | **`/market rate`** — rate a market 1-5 stars (plus an optional short review) after buying something from it; the average rating display in the market embed already existed in the code but had no command to actually submit one until now. **`/market finditem`** — search item names across every market in the server at once, instead of browsing markets one by one. |

| **3.4.1** | **Startup diagnostics.** The bot now checks `DISCORD_TOKEN`/`CLIENT_ID` are set before attempting to connect (exits with a clear message if not, instead of hanging), logs "Starting bot — connecting to Discord..." immediately, and warns after 20s if it still hasn't connected (usually a bad token, the Server Members Intent not enabled, or the host's network blocking Discord). Purely diagnostic — doesn't change any bot behavior once connected. |
| **3.5.0** | **Gift codes + admin balance grants.** `/admin giftcode create` lets an admin make a redeemable code with a duration and a reward (balance, a role, and/or a free-text prize description — any combination), which members claim once each with `/economy giftcode`. `/admin giftcode list`/`revoke` manage active codes. Also added **`/admin addmoney`** — grants balance to any member (including other admins), created fresh rather than taken from anyone else's balance, unlike `/finance sedekah` which transfers between two members. Added **`/economy tos`** — a short Terms of Service covering the virtual currency having no real-world value, the entertainment-only nature of the finance simulations, and admin authority over balances/codes/markets. |
| **3.5.1** | **Per-server currency name.** Added **`/admin currency-name`**, alongside the existing `/admin currency-emoji`, so each server can rename its currency away from the default "Dirham" (e.g. to Riyal, Dinar, Gold Coin) independently of every other server the bot is in. Shown in `/economy about` and `/economy tos`. |
| **3.5.2** | **Bugfix: `/admin currency-name` didn't affect amount displays.** In 3.5.1, a renamed currency only showed up in `/economy about`/`/economy tos` — `/economy balance` and every other amount still showed the old default `DHM` symbol, since amount formatting reads a separate "symbol" setting from `/admin currency-emoji`. Fixed: if a server hasn't set a custom emoji, amount displays now fall back to the custom currency name before falling back to the hardcoded default. Setting an emoji still takes priority over the name, as before. |
| **3.6.0** | **Added `/islamic persian`** — a lightweight, standalone Persian (Solar Hijri / Jalali) calendar date, separate from the existing Islamic Hijri calendar feature (different calendar system entirely, despite the similar name). Uses Node's built-in Intl (ICU) calendar support, same as the Hijri feature — no external API or package needed. On-demand only, no auto-post option (kept intentionally simple). |
| **3.7.0** | **Added `/admin persian-calendar channel \| disable \| status`** — daily auto-post for the Persian calendar, mirroring `/admin calendar` (Hijri) but fully independent: its own channel, its own enabled/disabled state, its own status check. A server can run the Hijri auto-post, the Persian auto-post, both (to the same or different channels), or neither — enabling/disabling one never affects the other. |
| **3.8.0** | **Added Waqf — a permanent community endowment**, the 4th classical Islamic finance instrument alongside Zakat, Sedekah, and Qard Hasan. `/finance waqf donate` adds to the principal, which is **never spent** (a waqf's corpus must stay intact by definition). Instead, the principal generates a small **random daily yield** (0–2%, same non-guaranteed randomness as Mudarabah — a fixed guaranteed return is exactly the riba this bot avoids), floored at 0 on a bad day, accumulating in a separate distributable pool. `/finance waqf status` shows the principal, the distributable yield, and top contributors. `/admin waqf distribute` pays out *only* from that yield pool, to a member or split evenly across everyone holding a role — the principal itself can never be withdrawn by anyone, including admins. |
| **3.8.1** | **🔒 Bugfix: a corrupted `database.json` broke every command with "The application did not respond."** `loadDB()` was called before the interaction handler's `try/catch`, so a malformed JSON file (e.g. from a killed process mid-write, or a full disk) threw an uncaught error and left every interaction — any command, any server — completely unanswered, with no error message at all, until someone manually fixed the file. Fixed with two layers: `loadDB()` now self-heals from a corrupted file by backing it up (`database.json.corrupted-<timestamp>`) and starting fresh instead of crashing, and the `interactionCreate` handler now wraps the load itself so any remaining failure gets a proper error reply instead of silently hanging. |
| **3.8.2** | **Startup check for calendar accuracy on minimal hosts.** The Hijri and Persian calendars rely on Node's built-in ICU data — official Node.js 18+ builds include this by default, but some minimal Docker images used by budget hosts (occasionally the case on panels like Wispbyte) ship a stripped-down ICU build that silently falls back to the Gregorian calendar instead of erroring, so `/islamic hijri`/`/islamic persian` would quietly show the wrong date with no warning. The bot now checks this once at startup and logs a clear console warning if it detects the fallback, instead of the problem going unnoticed. No other changes. |

## Commands (v3.8.2 structure)

| Parent | Subcommand(s) | Notes |
|---|---|---|
| `/economy` | `balance [user]`, `daily`, `work`, `profile [user]`, `inventory [user]`, `use <item>`, `history`, `achievements [user]`, `invite`, `redeem <code>`, `quiz`, `giftcode <code>`, `leaderboard`, `about`, `tos` | Core wallet & activity. `history` shows your last 10 transactions; `achievements` shows unlocked/locked badges; `invite`/`redeem` are a one-time referral bonus; `quiz` is an hourly Islamic-knowledge question for a small reward; `giftcode` redeems a code created by an admin; `tos` shows the Terms of Service |
| `/profession` | `choose`, `info`, `list` | Pick a livelihood (miner, office worker, farmer, fisherman, Quran teacher, trader, plus any server-custom ones) |
| `/finance zakat` | `info`, `pay`, `pool` | 2.5% of balance above nisab (5,000 DHM by default), goes to a community pool |
| `/finance sedekah` | `user`, `pool` | Voluntary charity, no obligation |
| `/finance mudarabah` | `invest`, `status`, `withdraw` | Profit/loss-sharing investment. Ratio (60% investor / 40% pool) is disclosed **before** investing |
| `/finance qard` | `request`, `repay`, `list` | Interest-free loan between two users — repay the exact amount, never more |
| `/finance waqf` | `donate`, `status` | Permanent community endowment. `donate` adds to the protected principal (never spent); `status` shows the principal, distributable yield, and top contributors |
| `/market` | `open`, `remove`, `browse`, `search`, `additem`, `removeitem`, `buy`, `edititem`, `rate`, `finditem` | Player-driven market stalls. `open`'s item slots (`item1`/`item2`/`item3`) each take an optional `item#content` (**private** — DMed to the buyer only after purchase, e.g. a secret link) and `item#role` (toggleable via `/economy use`). `additem`/`edititem` support a public `description` (shown on the item card, never secret) and a separate private `content` field (same DM-only delivery). Every sale automatically sends 2% to the community zakat pool as a market tax. `rate` lets a buyer leave 1-5 stars on a market; `finditem` searches item names across every market at once |
| `/market auction` | `start`, `bid`, `list` | Simple time-limited auctions — highest bid when the timer ends wins automatically, item delivered the same way as a regular purchase (inventory + DM, with optional private content) |
| `/islamic` | `hijri`, `persian`, `adzan-list` | Today's Hijri (Islamic lunar) date, today's Persian (Solar Hijri) date — separate calendar systems despite the similar name — and a list of channels configured for prayer time reminders |
| `/admin` *(admin-only)* | `profession-add`, `currency-emoji`, `currency-name`, `backup`, `audit`, `refund`, `auction-cancel`, `addmoney`, `waqf distribute` | Add a custom profession, change the currency emoji or name (independently, both per-server), export server data as JSON, view the recent action log, reverse a user's purchase, cancel an ongoing auction, grant a member fresh balance, or pay out waqf yield to a member or role (the waqf principal itself can never be withdrawn). `refund` and `auction-cancel` show a Confirm/Cancel prompt first |
| `/admin giftcode` | `create`, `list`, `revoke` | Create a redeemable code with a balance, role, and/or free-text prize reward and a time limit; list active codes; revoke one early |
| `/admin rolereward` | `add`, `remove`, `list` | Auto-grant a Discord role once a member's balance hits a threshold. **Requires the privileged Server Members Intent** |
| `/admin calendar` | `channel`, `disable`, `status` | Auto-posts the daily Hijri date to a channel every day at **18:00 WIB (Maghrib)** |
| `/admin persian-calendar` | `channel`, `disable`, `status` | Auto-posts the daily Persian (Solar Hijri) date to a channel every day at **18:00 WIB**. Fully independent from `/admin calendar` — separate channel, separate enabled/disabled state |
| `/admin adzan` | `set`, `remove` | Add/update or remove a channel for automatic prayer time (adzan) reminders, each with its own location |
| `/admin errorlog` | `channel`, `disable` | Set or turn off a channel that receives bot error reports (context, message, and a truncated stack trace) |

## Levels & Badges

`/economy profile` shows a level (1-7) and a badge title, both derived automatically from the user's current balance — there's no separate XP to track. Tiers are defined in `CONFIG.LEVEL_TIERS` in `index.js` and can be freely renamed or re-priced.

## Enabling the Server Members Intent (required for `/admin rolereward` and `/economy use`)

Auto-granting a role needs the bot to fetch member objects, which requires the **privileged** "Server Members Intent":

1. Go to the [Discord Developer Portal](https://discord.com/developers/applications) → your application → **Bot** tab.
2. Under "Privileged Gateway Intents", toggle **Server Members Intent** ON, and save.
3. Make sure the bot's role has **Manage Roles** permission and is positioned *above* any role it needs to auto-grant (Server Settings → Roles) — this applies both to `/admin rolereward` thresholds and to any role attached to a market item via `/market additem`.

If this intent isn't enabled, the bot will fail to log in once `GatewayIntentBits.GuildMembers` is requested (already included in `index.js`) — enabling it in the portal is a one-time setup step.

## Reducing RAM Usage Further

The bot already caps its internal caches (see changelog 2.8.1). If you're still close to your hosting plan's RAM limit:

- **Restart the server on a schedule** (e.g. once a day via a cron/scheduled restart if your host supports it) — this resets the whole Node.js process's memory, which helps regardless of the cause.
- **Keep `database.json` reasonably sized** — it's plain JSON loaded fully into memory, so an extremely large server (thousands of users, huge markets) will use more RAM than a small one. This is normal and scales with your server size, not a bug.
- **Check your host's actual allocated RAM** — free-tier plans on panels like Wispbyte are often quite small (e.g. 512MB-1GB). If the bot is in many large servers, upgrading the plan is the most reliable fix.
- **Avoid running multiple bots/processes on the same server slot** if your panel allows it — each Node.js process has its own baseline memory overhead.

## Setup

1. Install dependencies:
   ```bash
   npm install
   ```
2. Copy `.env.example` to `.env` and fill in:
   - `DISCORD_TOKEN` — from the Discord Developer Portal (Bot tab)
   - `CLIENT_ID` — your application's Client ID (General Information tab)
3. Invite the bot to your server(s) with the `applications.commands` and `bot` scopes, with at least "Send Messages" and "Use Slash Commands" permissions.
4. Run:
   ```bash
   npm start
   ```

This version always registers slash commands **globally** (available in every server the bot is in). Global commands can take up to 1 hour to propagate after first registration or after any command change — this is a Discord API limitation, not something the code controls. Because v2.5.0 changed command names, older cached commands may briefly show up alongside the new ones until Discord finishes propagating — this resolves on its own.

## Hosting on Bot-Hosting.net / Wispbyte / HeavenCloud

- Upload the 4 files the bot actually needs to run (`index.js`, `package.json`, `.env.example`, and your own `.env`) — do **not** upload a local `node_modules` folder; run `npm install` on the host instead, which keeps the upload small. `README.md`, `LICENSE`, `CONTRIBUTING.md`, and `.gitignore` are for the GitHub repo and aren't required on the host.
- Set the environment variables (`DISCORD_TOKEN`, `CLIENT_ID`) in the panel's environment/variables section instead of committing `.env`.
- Startup command: `node index.js` (or `npm start`).
- `database.json` will persist as long as the host doesn't wipe the filesystem on restart — check your host's persistent storage settings. If your host wipes files on redeploy, consider periodically backing up `database.json` via GitHub or moving to a small hosted database later.
- Pair with UptimeRobot as usual if your host needs an HTTP ping to stay awake (this bot itself doesn't run a web server; add one only if your host requires it for uptime pings).

## Customization

All tunable numbers (currency name, daily/work amounts, nisab, zakat rate, mudarabah ratio and cycle length, max markets per member, level/badge tiers) are in the `CONFIG` object at the top of `index.js` — easy to adjust from a phone. The market itself is no longer a fixed catalog — members populate it themselves via `/market open`.

## Note

The mudarabah simulation is a game mechanic for entertainment/community engagement using virtual currency. It is not a real financial product and shouldn't be used as a template for real-money investment schemes.

## Disclaimer

This is an unofficial, community-built project. Its currency has no real-world monetary value and cannot be exchanged for real money, goods, or services. The zakat, sedekah, mudarabah, qard hasan, and waqf mechanics are simplified simulations for entertainment and community engagement — they are not fatwa, financial advice, or a substitute for consulting a qualified scholar on real obligations like actual zakat calculation. See `/economy tos` in the bot itself for the in-app terms.

## Contributing

Contributions are welcome — see [CONTRIBUTING.md](./CONTRIBUTING.md) for setup steps and ground rules (this project stays single-file, dependency-light, and interest/gambling-free by design).

## License

[MIT](./LICENSE) — free to use, modify, and self-host. If you fork this for your own server, a credit back to this repo is appreciated but not required.
