/**
 * SYARIAH ECONOMY BOT
 * A Discord.js v14 economy bot built on Islamic finance principles:
 *  - No riba (interest)        -> Qard Hasan = interest-free loans
 *  - No maysir (gambling)      -> Mudarabah is a disclosed profit/loss-sharing simulation, not chance-based gambling
 *  - Zakat & Sedekah           -> automatic almsgiving calculation + voluntary charity
 *  - Halal Market              -> player-driven market stalls (/addmarket), no interest, no speculation (gharar)
 *
 * Also includes: /profile (combined balance + profession + level + badge card),
 * /rolereward (auto-grant a Discord role at a balance milestone), and /backup
 * (admin export of this server's own data).
 *
 * Single-file architecture (per user preference) + JSON file storage (no external DB needed).
 * Works on Bot-Hosting.net / Wispbyte / HeavenCloud style panels.
 */

const {
  Client,
  GatewayIntentBits,
  REST,
  Routes,
  SlashCommandBuilder,
  EmbedBuilder,
  PermissionFlagsBits,
  ButtonBuilder,
  ButtonStyle,
  ActionRowBuilder,
  StringSelectMenuBuilder,
  AttachmentBuilder,
  ChannelType,
  Options,
  Sweepers,
} = require('discord.js');
const fs = require('fs');
const path = require('path');
require('dotenv').config();

// ---------------------------------------------------------------------------
// CONFIG
// ---------------------------------------------------------------------------
const TOKEN = process.env.DISCORD_TOKEN;
const CLIENT_ID = process.env.CLIENT_ID;

const DB_PATH = path.join(__dirname, 'database.json');

const CONFIG = {
  BOT_NAME: 'EC Syariah Global',
  VERSION: '3.8.2',

  CURRENCY_NAME: 'Dirham',
  CURRENCY_SYMBOL: 'DHM',
  STARTING_BALANCE: 0,

  DAILY_AMOUNT: [100, 250],       // random range
  DAILY_COOLDOWN_MS: 24 * 60 * 60 * 1000,

  NISAB: 5000,           // zakat threshold (in-game currency units)
  ZAKAT_RATE: 0.025,     // 2.5%

  MUDARABAH_CYCLE_MS: 24 * 60 * 60 * 1000, // simulated "business cycle" duration
  MUDARABAH_INVESTOR_SHARE: 0.6, // investor gets 60% of profit, "mudarib"/pool operator gets 40%
  MUDARABAH_MIN: 100,
  // Waqf's daily yield is random within this range (like Mudarabah, not a fixed
  // guaranteed percentage — a fixed guaranteed return on capital is exactly the
  // riba this bot avoids). Floored at 0 on a bad day; the principal itself is
  // never touched either way, since a waqf's corpus must stay intact.
  WAQF_DAILY_YIELD_RANGE: [0, 0.02], // 0%–2% of principal, applied to the distributable pool only

  // Each profession has its own number of "presses", pay-per-press range, and cooldown.
  PROFESSIONS: [
    {
      id: 'miner',
      name: 'Miner',
      emoji: '⛏️',
      description: 'Mines ore & gemstones. Higher pay, more presses required.',
      taskText: 'Mine iron ore to earn wages!',
      pressesRequired: 5,
      amountPerPress: [30, 60],
      cooldownMs: 45 * 60 * 1000,
    },
    {
      id: 'office_worker',
      name: 'Office Worker',
      emoji: '💼',
      description: 'Works at an office finishing daily reports.',
      taskText: 'Finish the office report to earn your salary!',
      pressesRequired: 3,
      amountPerPress: [45, 75],
      cooldownMs: 60 * 60 * 1000,
    },
    {
      id: 'farmer',
      name: 'Farmer',
      emoji: '🌾',
      description: 'Farms and harvests crops.',
      taskText: 'Harvest the crops to earn money!',
      pressesRequired: 4,
      amountPerPress: [25, 50],
      cooldownMs: 40 * 60 * 1000,
    },
    {
      id: 'fisherman',
      name: 'Fisherman',
      emoji: '🎣',
      description: 'Goes out to sea to catch fresh fish for sale.',
      taskText: 'Catch fish at sea to earn money!',
      pressesRequired: 4,
      amountPerPress: [25, 55],
      cooldownMs: 40 * 60 * 1000,
    },
    {
      id: 'quran_teacher',
      name: 'Quran Teacher',
      emoji: '📖',
      description: 'Teaches Quran recitation to neighborhood children.',
      taskText: 'Teach the children Quran recitation to earn wages!',
      pressesRequired: 3,
      amountPerPress: [35, 65],
      cooldownMs: 50 * 60 * 1000,
    },
    {
      id: 'trader',
      name: 'Trader',
      emoji: '🛍️',
      description: 'Sells goods and serves customers at a shop/market.',
      taskText: 'Serve customers at the shop to earn money!',
      pressesRequired: 5,
      amountPerPress: [20, 45],
      cooldownMs: 35 * 60 * 1000,
    },
  ],

  // The old built-in item catalog was removed (1.1.2D) — the market is now fully
  // player-driven via /addmarket. See db.markets[guildId] below.
  MAX_MARKETS_PER_USER: 10,
  MAX_ITEMS_PER_MARKET: 15, // rich items added via /additem, per market

  // Level/badge tiers shown on /profile, based on the user's current balance.
  // Thresholds must stay sorted ascending; the highest one the user meets applies.
  LEVEL_TIERS: [
    { level: 1, badge: '🌱 Newcomer', minBalance: 0 },
    { level: 2, badge: '🧑‍🌾 Hard Worker', minBalance: 1000 },
    { level: 3, badge: '🛍️ Trader', minBalance: 3000 },
    { level: 4, badge: '💼 Merchant', minBalance: 7000 },
    { level: 5, badge: '🏛️ Wealthy', minBalance: 15000 },
    { level: 6, badge: '👑 Tycoon', minBalance: 30000 },
    { level: 7, badge: '🕌 Sultan', minBalance: 60000 },
  ],

  // Auto Hijri calendar: what time of day (in UTC) the daily post fires.
  // In Islam, a new day begins at Maghrib (sunset), so 18:00 WIB (Western
  // Indonesia Time, UTC+7) is used rather than midnight. 11 UTC = 18:00 WIB.
  AUTO_CALENDAR_UTC_HOUR: 11,
  AUTO_CALENDAR_CHECK_INTERVAL_MS: 60 * 1000, // how often the scheduler checks the clock

  // Adzan (prayer time) reminders, powered by the free AlAdhan API (no key
  // needed): https://aladhan.com/prayer-times-api
  // Method 20 = KEMENAG (Kementerian Agama Republik Indonesia). See
  // https://aladhan.com/calculation-methods for other countries' authorities
  // if this bot is used by a non-Indonesian community.
  ADZAN_METHOD: 20,
  ADZAN_PRAYERS: ['Fajr', 'Dhuhr', 'Asr', 'Maghrib', 'Isha'],
  ADZAN_CHECK_INTERVAL_MS: 60 * 1000,

  // Market tax: a small cut of every /market buy sale goes to the community
  // zakat pool instead of the seller, on top of whatever zakat the seller pays
  // manually. Kept small so it doesn't feel punitive.
  MARKET_TAX_RATE: 0.02, // 2%

  // Simple per-user cooldown (ms) between any command/button press, to stop
  // rapid double-clicks (e.g. spam-clicking Buy) and basic command spam.
  ACTION_COOLDOWN_MS: 700,

  MAX_TRANSACTIONS_STORED: 25, // per user, for /economy history
  MAX_AUDIT_LOG_STORED: 100,   // per server, for /admin audit

  // Achievements are checked in code (see checkAchievements()); only the
  // unlocked ids are persisted per user. Keep this list small and additive —
  // removing an entry would leave stale ids in old users' data, which is
  // harmless (they're just ignored) but avoid reusing an old id for something else.
  ACHIEVEMENTS: [
    { id: 'first_purchase', emoji: '🛍️', name: 'First Purchase', desc: 'Buy your first item from any market' },
    { id: 'zakat_payer', emoji: '🕌', name: 'Zakat Payer', desc: 'Pay zakat 5 times' },
    { id: 'hard_worker', emoji: '💪', name: 'Hard Worker', desc: 'Work 20 times' },
    { id: 'investor', emoji: '🤝', name: 'Investor', desc: 'Complete a mudarabah investment' },
    { id: 'generous', emoji: '🤲', name: 'Generous Soul', desc: 'Give a total of 500+ in sedekah' },
  ],

  // Small pool of well-established, non-controversial Islamic knowledge
  // questions for /economy quiz. Kept to widely agreed basics — not fiqh
  // debates — since the bot serves a general audience of varying schools.
  QUIZZES: [
    { q: 'How many pillars of Islam are there?', options: ['3', '4', '5', '6'], correct: 2 },
    { q: 'How many obligatory prayers (salah) are there each day?', options: ['3', '4', '5', '6'], correct: 2 },
    { q: 'What is the Islamic holy book called?', options: ['The Torah', 'The Quran', 'The Gospel', 'The Psalms'], correct: 1 },
    { q: 'During which month do Muslims fast?', options: ['Shawwal', 'Rajab', 'Ramadan', 'Muharram'], correct: 2 },
    { q: 'What is the pilgrimage to Mecca called?', options: ['Umrah', 'Hajj', 'Sawm', 'Zakat'], correct: 1 },
    { q: 'Towards which city do Muslims face in prayer?', options: ['Medina', 'Jerusalem', 'Mecca', 'Cairo'], correct: 2 },
  ],
  QUIZ_REWARD: 30,
  QUIZ_COOLDOWN_MS: 60 * 60 * 1000, // 1 hour

  REFERRAL_BONUS_REFEREE: 200, // new user who redeems a code
  REFERRAL_BONUS_REFERRER: 100, // user whose code was redeemed
};

// ---------------------------------------------------------------------------
// STORAGE (simple JSON file "database")
// ---------------------------------------------------------------------------
function loadDB() {
  if (!fs.existsSync(DB_PATH)) {
    const initial = { users: {}, zakatPool: 0, sedekahPool: 0, settings: {}, customProfessions: {}, markets: {}, auctions: {} };
    fs.writeFileSync(DB_PATH, JSON.stringify(initial, null, 2));
    return initial;
  }

  let db;
  try {
    db = JSON.parse(fs.readFileSync(DB_PATH, 'utf8'));
  } catch (err) {
    // database.json exists but isn't valid JSON — e.g. the process was killed
    // mid-write, or the disk filled up. Previously this threw straight out of
    // loadDB(), which is called before any try/catch in interactionCreate, so
    // EVERY command silently failed forever ("The application did not
    // respond") until someone manually fixed the file. Self-heal instead:
    // preserve the broken file for inspection/recovery, then start a fresh
    // (empty) database so the bot keeps working. This loses that server's
    // data since the last successful write, which is unavoidable once the
    // file is actually corrupt — but it's far better than a permanently dead
    // bot. Admins can restore from their own /admin backup export if they
    // have one.
    console.error(`database.json is corrupted, resetting: ${err.message}`);
    try {
      fs.copyFileSync(DB_PATH, `${DB_PATH}.corrupted-${Date.now()}`);
    } catch (backupErr) {
      console.error('Could not back up corrupted database.json:', backupErr.message);
    }
    db = { users: {}, zakatPool: 0, sedekahPool: 0, settings: {}, customProfessions: {}, markets: {}, auctions: {} };
    fs.writeFileSync(DB_PATH, JSON.stringify(db, null, 2));
  }

  if (!db.settings) db.settings = {}; // migration for DBs created before this field existed
  if (!db.customProfessions) db.customProfessions = {}; // migration for DBs created before /addprofession existed
  if (!db.markets) db.markets = {}; // migration for DBs created before the player-driven market (1.1.2D) existed
  if (!db.auctions) db.auctions = {}; // migration for DBs created before the auction house (3.1.0) existed
  // migration: 1B stored a single GLOBAL currencyEmoji directly on db.settings.
  // 1C+ stores it per-server under db.settings[guildId], so the old flat value
  // no longer applies to any specific server and is dropped here.
  if (typeof db.settings.currencyEmoji === 'string') delete db.settings.currencyEmoji;
  return db;
}

function saveDB(db) {
  fs.writeFileSync(DB_PATH, JSON.stringify(db, null, 2));
}

// ---------------------------------------------------------------------------
// GUILD-SCOPED CONTEXT
// ---------------------------------------------------------------------------
// Every server (guild) gets its own isolated economy: balances, professions,
// work progress, debts, etc. all live under a `${guildId}:${userId}` key so
// the same Discord user has a completely separate profile in each server.
// CTX is (re)assigned once at the top of every interactionCreate before any
// handler runs, so getUser()/fmt() below can stay simple everywhere else in
// the file without threading guildId through every single function call.
let CTX = { db: null, guildId: null };

function getUser(db, userId) {
  const key = `${CTX.guildId}:${userId}`;
  if (!db.users[key]) {
    db.users[key] = {
      balance: CONFIG.STARTING_BALANCE,
      lastDaily: 0,
      lastWork: 0,
      profession: null,   // id from CONFIG.PROFESSIONS
      workProgress: 0,    // current "press" progress toward pressesRequired
      investment: null, // { amount, startTime }
      debts: [],        // money this user OWES: { lender, amount, date }
      loans: [],        // money this user LENT to others: { borrower, amount, date }
      inventory: [],     // item ids owned
      equippedRoles: [], // roleIds currently active from "used" inventory items
      stats: { purchases: 0, zakatPayments: 0, workCount: 0, mudarabahCount: 0, sedekahTotal: 0 },
      achievements: [],  // unlocked achievement ids, see CONFIG.ACHIEVEMENTS
      referralCode: null,
      referredBy: null,
      referralCount: 0,
      transactions: [],  // last 25: { ts, type, amount, note }
      lastQuiz: 0,
      lastNotifiedLevel: 1, // level 1 is the starting tier everyone begins at — don't DM for that
    };
  }
  // migration for users created before the profession system existed
  const u = db.users[key];
  if (u.profession === undefined) u.profession = null;
  if (u.workProgress === undefined) u.workProgress = 0;
  if (u.equippedRoles === undefined) u.equippedRoles = [];
  if (u.stats === undefined) u.stats = { purchases: 0, zakatPayments: 0, workCount: 0, mudarabahCount: 0, sedekahTotal: 0 };
  if (u.achievements === undefined) u.achievements = [];
  if (u.referralCode === undefined) u.referralCode = null;
  if (u.referredBy === undefined) u.referredBy = null;
  if (u.referralCount === undefined) u.referralCount = 0;
  if (u.transactions === undefined) u.transactions = [];
  if (u.lastQuiz === undefined) u.lastQuiz = 0;
  if (u.lastNotifiedLevel === undefined) u.lastNotifiedLevel = getLevelInfo(u.balance || 0).level;
  return u;
}

// Records a compact entry in the user's own transaction ledger, capped to the
// most recent MAX_TRANSACTIONS_STORED so /economy history stays small and the
// database file doesn't grow without bound.
function logTransaction(user, type, amount, note) {
  user.transactions = user.transactions || [];
  user.transactions.push({ ts: Date.now(), type, amount, note: note || null });
  if (user.transactions.length > CONFIG.MAX_TRANSACTIONS_STORED) {
    user.transactions = user.transactions.slice(-CONFIG.MAX_TRANSACTIONS_STORED);
  }
}

// Per-server audit trail of notable admin/economic actions, capped to the most
// recent MAX_AUDIT_LOG_STORED entries. Viewable via /admin audit.
function logAudit(db, guildId, userId, action, detail) {
  const s = db.settings[guildId] = db.settings[guildId] || {};
  if (!s.auditLog) s.auditLog = [];
  s.auditLog.push({ ts: Date.now(), userId, action, detail: detail || null });
  if (s.auditLog.length > CONFIG.MAX_AUDIT_LOG_STORED) {
    s.auditLog = s.auditLog.slice(-CONFIG.MAX_AUDIT_LOG_STORED);
  }
}

// Checks the user's current stats/inventory against CONFIG.ACHIEVEMENTS and
// unlocks any newly-earned ones. Returns the list of achievements unlocked
// just now (empty if none) so callers can optionally mention it.
function checkAchievements(user) {
  user.achievements = user.achievements || [];
  user.stats = user.stats || { purchases: 0, zakatPayments: 0, workCount: 0, mudarabahCount: 0, sedekahTotal: 0 };
  const newly = [];
  const conditions = {
    first_purchase: () => user.stats.purchases >= 1,
    zakat_payer: () => user.stats.zakatPayments >= 5,
    hard_worker: () => user.stats.workCount >= 20,
    investor: () => user.stats.mudarabahCount >= 1,
    generous: () => user.stats.sedekahTotal >= 500,
  };
  for (const ach of CONFIG.ACHIEVEMENTS) {
    if (user.achievements.includes(ach.id)) continue;
    const cond = conditions[ach.id];
    if (cond && cond()) {
      user.achievements.push(ach.id);
      newly.push(ach);
    }
  }
  return newly;
}

// Very small in-memory (not persisted — resets on restart, which is fine) rate
// limiter: rejects a user's action if they acted again within ACTION_COOLDOWN_MS.
// This only guards against rapid spam-clicking/spam-command abuse, not a real
// per-command cooldown system (daily/work already have their own cooldowns).
const lastActionAt = new Map();
function isRateLimited(userId) {
  const now = Date.now();
  const last = lastActionAt.get(userId) || 0;
  if (now - last < CONFIG.ACTION_COOLDOWN_MS) return true;
  lastActionAt.set(userId, now);
  return false;
}

// ---------------------------------------------------------------------------
// CONFIRMATION FLOW — used before destructive/hard-to-undo actions (admin
// refund, market remove, auction cancel) so a mis-click can't immediately
// wipe something out. The actual data isn't encoded in the button's customId
// (Discord caps that at 100 chars, and item/market names can be long) — it's
// held in this in-memory map instead, keyed by a short random token, and
// expires after 2 minutes. Being in-memory (not persisted) is fine here: if
// the bot restarts mid-confirmation, the user just sees "expired" and re-runs
// the command, no data is lost either way since nothing happened yet.
// ---------------------------------------------------------------------------
const pendingConfirmations = new Map();
const CONFIRMATION_TTL_MS = 2 * 60 * 1000;

function createConfirmation(ownerId, type, data) {
  const token = Math.random().toString(36).slice(2, 10);
  pendingConfirmations.set(token, { ownerId, type, data, expiresAt: Date.now() + CONFIRMATION_TTL_MS });
  return token;
}

function buildConfirmRow(token) {
  return new ActionRowBuilder().addComponents(
    new ButtonBuilder().setCustomId(`confirmyes:${token}`).setLabel('Confirm').setStyle(ButtonStyle.Danger),
    new ButtonBuilder().setCustomId(`confirmno:${token}`).setLabel('Cancel').setStyle(ButtonStyle.Secondary),
  );
}

// The currency symbol shown by fmt() below (e.g. "1,000 DHM"). Priority per
// server: a custom emoji set via /admin currency-emoji (most specific/visual
// choice), then a custom currency name set via /admin currency-name (so
// renaming the currency actually shows up in every amount, not just
// /economy about and /economy tos), then finally CONFIG.CURRENCY_SYMBOL.
function getCurrencySymbol() {
  const s = CTX.db && CTX.guildId ? CTX.db.settings[CTX.guildId] : null;
  if (s && s.currencyEmoji) return s.currencyEmoji;
  if (s && s.currencyName) return s.currencyName;
  return CONFIG.CURRENCY_SYMBOL;
}

// The currency name shown in /economy about, /economy tos, and anywhere else
// the full currency name (not just its short symbol) is spelled out. Each
// server can set its own via /admin currency-name, persisted at
// db.settings[guildId].currencyName. Falls back to CONFIG.CURRENCY_NAME.
function getCurrencyName() {
  const s = CTX.db && CTX.guildId ? CTX.db.settings[CTX.guildId] : null;
  return (s && s.currencyName) || CONFIG.CURRENCY_NAME;
}

function fmt(amount) {
  return `${Math.round(amount).toLocaleString('en-US')} ${getCurrencySymbol()}`;
}

// Wraps a plain text reply into a minimal embed, so every bot response —
// success, error, or info — has the same consistent embed look instead of
// a mix of plain messages and embeds. Color defaults to the bot's usual
// green; pass 0xe74c3c for errors/warnings where that reads better.
function simpleEmbed(text, color = 0x2ecc71) {
  return new EmbedBuilder().setColor(color).setDescription(String(text));
}

// Returns built-in professions plus any custom professions added via /addprofession
// for the current server (CTX.guildId). Custom ones are appended after built-ins.
function getAllProfessions() {
  const custom = (CTX.db && CTX.db.customProfessions && CTX.db.customProfessions[CTX.guildId]) || [];
  return [...CONFIG.PROFESSIONS, ...custom];
}

function getProfession(id) {
  return getAllProfessions().find(p => p.id === id) || null;
}

// Returns the highest level/badge tier the given balance qualifies for.
function getLevelInfo(balance) {
  let current = CONFIG.LEVEL_TIERS[0];
  for (const tier of CONFIG.LEVEL_TIERS) {
    if (balance >= tier.minBalance) current = tier;
  }
  const idx = CONFIG.LEVEL_TIERS.indexOf(current);
  const next = CONFIG.LEVEL_TIERS[idx + 1] || null;
  return { level: current.level, badge: current.badge, next };
}

// ---------------------------------------------------------------------------
// MARKETS (player-driven, 1.1.2D+)
// ---------------------------------------------------------------------------
// Any member can list their own market via /addmarket. Markets live under
// db.markets[guildId] as an array so a server can have many, one per member
// (or more). Market names are unique per-server (case-insensitive) so
// /marketsearch can look one up by name.
function getGuildMarkets(db) {
  if (!db.markets[CTX.guildId]) db.markets[CTX.guildId] = [];
  return db.markets[CTX.guildId];
}

function findMarketByName(db, name) {
  const markets = getGuildMarkets(db);
  return markets.find(m => m.name.toLowerCase() === name.toLowerCase()) || null;
}

// Time-limited auctions live under db.auctions[guildId] as an array, separate
// from regular markets/items since they're resolved automatically once their
// timer ends rather than bought on demand.
function getGuildAuctions(db) {
  if (!db.auctions[CTX.guildId]) db.auctions[CTX.guildId] = [];
  return db.auctions[CTX.guildId];
}

// ---------------------------------------------------------------------------
// ROLE REWARDS (auto-grant a Discord role once a member's balance reaches a
// configured amount). Config lives per-server at db.settings[guildId].roleRewards.
// Requires the GuildMembers privileged intent to fetch member objects and add
// roles — see CONFIG note near client creation below.
// ---------------------------------------------------------------------------
function getRoleRewards(db) {
  const s = db.settings[CTX.guildId] = db.settings[CTX.guildId] || {};
  if (!s.roleRewards) s.roleRewards = [];
  return s.roleRewards;
}

// Call this after any action that can increase a user's balance. Silently
// does nothing if no rewards are configured, the bot lacks permission, or
// the member can't be fetched (e.g. Server Members Intent not enabled). Also
// DMs the user once when they cross into a new level tier (see LEVEL_TIERS),
// independent of whether any role rewards are configured.
async function checkRoleRewards(guild, db, userId, balance) {
  try {
    const u = getUser(db, userId);
    const level = getLevelInfo(balance);
    if (level && (u.lastNotifiedLevel || 0) < level.level) {
      u.lastNotifiedLevel = level.level;
      saveDB(db);
      const discordUser = await guild.client.users.fetch(userId).catch(() => null);
      if (discordUser) {
        await discordUser.send({ embeds: [simpleEmbed(`🎉 You've reached **Level ${level.level}: ${level.badge}** with a balance of ${fmt(balance)}!`)] }).catch(() => null);
      }
    }

    const rewards = getRoleRewards(db);
    if (!rewards.length) return;

    const eligible = rewards.filter(r => balance >= r.amount);
    if (!eligible.length) return;

    const member = await guild.members.fetch(userId).catch(() => null);
    if (!member) return;

    for (const reward of eligible) {
      if (!member.roles.cache.has(reward.roleId)) {
        await member.roles.add(reward.roleId).catch(() => { /* missing permission or role hierarchy issue, skip */ });
      }
    }
  } catch (_) {
    // never let role-reward automation break the underlying economy command
  }
}

// ---------------------------------------------------------------------------
// HIJRI CALENDAR
// Uses Node's built-in Intl (ICU) islamic-umalqura calendar — no external API
// or package needed, works fully offline.
// ---------------------------------------------------------------------------
function getHijriParts(date = new Date()) {
  const fmt = new Intl.DateTimeFormat('en-u-ca-islamic-umalqura', {
    day: 'numeric', month: 'long', year: 'numeric', weekday: 'long',
  });
  const parts = fmt.formatToParts(date);
  const get = (type) => parts.find(p => p.type === type)?.value || '';
  return {
    weekday: get('weekday'),
    day: get('day'),
    month: get('month'),
    year: get('year'),
    text: `${get('weekday')}, ${get('day')} ${get('month')} ${get('year')} H`,
  };
}

function buildHijriEmbed(date = new Date()) {
  const hijri = getHijriParts(date);
  const gregorian = date.toLocaleDateString('en-GB', {
    weekday: 'long', day: 'numeric', month: 'long', year: 'numeric', timeZone: 'Asia/Jakarta',
  });
  const isFriday = hijri.weekday === 'Friday';

  const embed = new EmbedBuilder()
    .setColor(0x2ecc71)
    .setTitle('🕌 Islamic (Hijri) Calendar')
    .addFields(
      { name: 'Hijri Date', value: `**${hijri.text}**` },
      { name: 'Gregorian Date', value: gregorian },
    )
    .setFooter({ text: CONFIG.BOT_NAME });

  if (isFriday) {
    embed.setDescription('🌙 Today is **Jumu\'ah (Friday)** — a blessed day, don\'t forget to send salawat and read Surah Al-Kahf.');
  }
  return embed;
}

// ---------------------------------------------------------------------------
// PERSIAN CALENDAR (Solar Hijri / Jalali)
// A separate, standalone feature from the Islamic Hijri calendar above — this
// is the solar calendar used civically in Iran and Afghanistan, unrelated to
// the lunar Hijri calendar despite the similar name. Also uses Node's
// built-in Intl (ICU) calendar support — no external API or package needed.
// ---------------------------------------------------------------------------
function getPersianParts(date = new Date()) {
  const fmt = new Intl.DateTimeFormat('en-u-ca-persian', {
    day: 'numeric', month: 'long', year: 'numeric', weekday: 'long',
  });
  const parts = fmt.formatToParts(date);
  const get = (type) => parts.find(p => p.type === type)?.value || '';
  return {
    weekday: get('weekday'),
    day: get('day'),
    month: get('month'),
    year: get('year'),
    text: `${get('weekday')}, ${get('day')} ${get('month')} ${get('year')} SH`,
  };
}

function buildPersianEmbed(date = new Date()) {
  const persian = getPersianParts(date);
  const gregorian = date.toLocaleDateString('en-GB', {
    weekday: 'long', day: 'numeric', month: 'long', year: 'numeric', timeZone: 'Asia/Jakarta',
  });

  return new EmbedBuilder()
    .setColor(0x27ae60)
    .setTitle('📅 Persian (Solar Hijri) Calendar')
    .addFields(
      { name: 'Persian Date', value: `**${persian.text}**` },
      { name: 'Gregorian Date', value: gregorian },
    )
    .setFooter({ text: CONFIG.BOT_NAME });
}

// Per-server auto-calendar config lives at db.settings[guildId].autoCalendar:
// { channelId, enabled, lastPostedDateKey }
function getAutoCalendarSettings(db, guildId) {
  const s = db.settings[guildId] = db.settings[guildId] || {};
  if (!s.autoCalendar) s.autoCalendar = { channelId: null, enabled: false, lastPostedDateKey: null };
  return s.autoCalendar;
}

// Separate per-server auto-calendar config for the Persian calendar, at
// db.settings[guildId].autoCalendarPersian — independent channel/enabled
// state from the Hijri one above, so a server can run either, both, or
// neither, each posting to its own channel.
function getAutoCalendarPersianSettings(db, guildId) {
  const s = db.settings[guildId] = db.settings[guildId] || {};
  if (!s.autoCalendarPersian) s.autoCalendarPersian = { channelId: null, enabled: false, lastPostedDateKey: null };
  return s.autoCalendarPersian;
}

// Per-server waqf (permanent community endowment) lives at
// db.settings[guildId].waqf: { principal, growthPool, contributions, lastGrowthDateKey }
// - principal: total ever donated. NEVER decreases — a waqf's corpus is
//   preserved by definition; only its yield may be spent.
// - growthPool: accumulated distributable yield, spent via /admin waqf distribute.
// - contributions: { userId: totalDonatedByThatUser } — for the top-contributors list.
// - lastGrowthDateKey: WIB date key of the last time daily yield was applied,
//   so the scheduler only applies it once per day even if it ticks every minute.
function getWaqf(db, guildId) {
  const s = db.settings[guildId] = db.settings[guildId] || {};
  if (!s.waqf) s.waqf = { principal: 0, growthPool: 0, contributions: {}, lastGrowthDateKey: null };
  return s.waqf;
}

// Returns the current date, expressed as a YYYY-MM-DD key in WIB (UTC+7), used
// to detect "a new WIB day has started" regardless of what timezone the host
// server's OS clock is set to.
function getWIBDateKey(date = new Date()) {
  const wib = new Date(date.getTime() + 7 * 60 * 60 * 1000);
  return wib.toISOString().slice(0, 10);
}

// Checks every server's auto-calendar settings once a minute; posts the daily
// Hijri embed and/or the daily Persian embed to their own (independently
// configured) channel exactly once per WIB day, right at 18:00 WIB / Maghrib
// (CONFIG.AUTO_CALENDAR_UTC_HOUR in UTC). A server can enable either, both,
// or neither — they don't affect one another. The same daily tick also applies
// waqf yield (see getWaqf above) once per WIB day for every server with a
// waqf principal, independently of whether auto-calendar is configured at all.
function startAutoCalendarScheduler() {
  setInterval(async () => {
    const now = new Date();
    if (now.getUTCHours() !== CONFIG.AUTO_CALENDAR_UTC_HOUR) return;

    const db = loadDB();
    const todayKey = getWIBDateKey(now);
    let changed = false;

    for (const [guildId, settings] of Object.entries(db.settings)) {
      const ac = settings?.autoCalendar;
      if (ac && ac.enabled && ac.channelId && ac.lastPostedDateKey !== todayKey) {
        try {
          const channel = await client.channels.fetch(ac.channelId).catch(() => null);
          if (channel) {
            await channel.send({ embeds: [buildHijriEmbed(now)] });
          }
          ac.lastPostedDateKey = todayKey;
          changed = true;
        } catch (err) {
          console.error(`Hijri auto-calendar post failed for guild ${guildId}:`, err);
        }
      }

      const acp = settings?.autoCalendarPersian;
      if (acp && acp.enabled && acp.channelId && acp.lastPostedDateKey !== todayKey) {
        try {
          const channel = await client.channels.fetch(acp.channelId).catch(() => null);
          if (channel) {
            await channel.send({ embeds: [buildPersianEmbed(now)] });
          }
          acp.lastPostedDateKey = todayKey;
          changed = true;
        } catch (err) {
          console.error(`Persian auto-calendar post failed for guild ${guildId}:`, err);
        }
      }

      const waqf = settings?.waqf;
      if (waqf && waqf.principal > 0 && waqf.lastGrowthDateKey !== todayKey) {
        // Random yield, like Mudarabah — never a guaranteed fixed percentage.
        // Floored at 0 on a bad day; principal itself is never reduced either way.
        const [minRate, maxRate] = CONFIG.WAQF_DAILY_YIELD_RANGE;
        const rate = minRate + Math.random() * (maxRate - minRate);
        const yieldAmount = Math.max(0, Math.round(waqf.principal * rate));
        waqf.growthPool += yieldAmount;
        waqf.lastGrowthDateKey = todayKey;
        changed = true;
      }
    }

    if (changed) saveDB(db);
  }, CONFIG.AUTO_CALENDAR_CHECK_INTERVAL_MS);
}

// ---------------------------------------------------------------------------
// ADZAN (PRAYER TIME) REMINDERS
// Uses the free AlAdhan API (https://aladhan.com/prayer-times-api), no key
// required. Prayer times are fetched once per local day per configured
// channel and cached in db.settings[guildId].adzanChannels.
// ---------------------------------------------------------------------------

// Accepts "Country/City" or "Country/City/Province" as documented in the
// /setadzan-channel command description. Falls back to treating the whole
// string as a free-text address if it doesn't contain a "/".
function parseLocationInput(input) {
  const parts = input.split('/').map(s => s.trim()).filter(Boolean);
  if (parts.length === 1) {
    return { raw: input, geocodeQuery: parts[0] };
  }
  const [country, city, province] = parts;
  const geocodeQuery = [city, province, country].filter(Boolean).join(', ');
  return { raw: input, country, city, province, geocodeQuery };
}

// Prayer time strings from AlAdhan sometimes include a suffix like
// "04:37 (WIB)" — this keeps just the "HH:mm" portion.
function stripTimeSuffix(t) {
  const m = String(t).match(/^(\d{2}:\d{2})/);
  return m ? m[1] : t;
}

function getLocalDateKey(timezone, date = new Date()) {
  return new Intl.DateTimeFormat('en-CA', { timeZone: timezone, year: 'numeric', month: '2-digit', day: '2-digit' }).format(date);
}

function getLocalTimeHHMM(timezone, date = new Date()) {
  return new Intl.DateTimeFormat('en-GB', { timeZone: timezone, hour: '2-digit', minute: '2-digit', hour12: false }).format(date);
}

// Fetches today's prayer timings for a free-text address query. Requires
// Node 18+ (global fetch). Throws on failure — callers should catch.
async function fetchPrayerTimes(geocodeQuery) {
  const url = `https://api.aladhan.com/v1/timingsByAddress?address=${encodeURIComponent(geocodeQuery)}&method=${CONFIG.ADZAN_METHOD}`;
  const res = await fetch(url);
  if (!res.ok) throw new Error(`AlAdhan API returned HTTP ${res.status}`);
  const data = await res.json();
  if (data.code !== 200 || !data.data) throw new Error('AlAdhan API could not resolve that location');
  return {
    timings: data.data.timings,
    timezone: data.data.meta.timezone,
  };
}

function getAdzanChannels(db, guildId) {
  const s = db.settings[guildId] = db.settings[guildId] || {};
  if (!s.adzanChannels) s.adzanChannels = [];
  return s.adzanChannels;
}

// Per-server error log channel: db.settings[guildId].errorLogChannelId. Set via
// /admin errorlog channel, disabled via /admin errorlog disable. Sends a compact
// embed with what failed and where — never throws itself, since logging a crash
// must never cause a second crash.
async function logErrorToChannel(client, db, guildId, error, context) {
  try {
    if (!guildId) return; // errors outside a guild (e.g. DMs) have nowhere configured to go
    const s = db.settings[guildId];
    const channelId = s && s.errorLogChannelId;
    if (!channelId) return;
    const channel = await client.channels.fetch(channelId).catch(() => null);
    if (!channel) return;

    const stack = (error && error.stack) ? error.stack.slice(0, 1000) : String(error).slice(0, 1000);
    const embed = new EmbedBuilder()
      .setColor(0xe74c3c)
      .setTitle('⚠️ Bot Error')
      .addFields(
        { name: 'Context', value: context || 'Unknown', inline: false },
        { name: 'Message', value: `\`\`\`${String((error && error.message) || error).slice(0, 500)}\`\`\``, inline: false },
        { name: 'Stack (truncated)', value: `\`\`\`${stack}\`\`\``, inline: false },
      )
      .setTimestamp();
    await channel.send({ embeds: [embed] });
  } catch (_) {
    // Logging must never throw — if this fails, it just fails silently.
  }
}

function buildAdzanEmbed(prayerName, entry, hhmm) {
  return new EmbedBuilder()
    .setColor(0x16a085)
    .setTitle(`🕌 Prayer Time — ${prayerName}`)
    .setDescription(`It's time for **${prayerName}** prayer in **${entry.raw}** (${hhmm} local time).`)
    .setFooter({ text: CONFIG.BOT_NAME });
}

// Checks every configured adzan channel once a minute. Refreshes cached
// prayer times once per local calendar day per channel, then posts a
// reminder the minute each prayer time is reached (deduplicated per day).
function startAdzanScheduler() {
  setInterval(async () => {
    const now = new Date();
    const db = loadDB();
    let changed = false;

    for (const [guildId, settings] of Object.entries(db.settings)) {
      const entries = settings?.adzanChannels;
      if (!entries || !entries.length) continue;

      for (const entry of entries) {
        try {
          const todayKey = entry.timezone ? getLocalDateKey(entry.timezone, now) : null;

          if (!entry.timezone || entry.timingsDateKey !== todayKey) {
            const { timings, timezone } = await fetchPrayerTimes(entry.geocodeQuery);
            entry.timings = timings;
            entry.timezone = timezone;
            entry.timingsDateKey = getLocalDateKey(timezone, now);
            entry.postedFlags = {};
            changed = true;
          }

          const nowHHMM = getLocalTimeHHMM(entry.timezone, now);
          for (const prayer of CONFIG.ADZAN_PRAYERS) {
            const target = entry.timings && stripTimeSuffix(entry.timings[prayer]);
            if (!target || entry.postedFlags?.[prayer]) continue;
            if (target === nowHHMM) {
              const channel = await client.channels.fetch(entry.channelId).catch(() => null);
              if (channel) await channel.send({ embeds: [buildAdzanEmbed(prayer, entry, nowHHMM)] });
              entry.postedFlags[prayer] = true;
              changed = true;
            }
          }
        } catch (err) {
          console.error(`Adzan scheduler error for guild ${guildId}, channel ${entry.channelId}:`, err.message);
        }
      }
    }

    if (changed) saveDB(db);
  }, CONFIG.ADZAN_CHECK_INTERVAL_MS);
}

function progressBar(current, total, size = 10) {
  const filled = Math.max(0, Math.min(size, Math.round((current / total) * size)));
  return `[${'■'.repeat(filled)}${'□'.repeat(size - filled)}] ${current}/${total}`;
}

function buildWorkEmbed(prof, progress) {
  return new EmbedBuilder()
    .setColor(0x2ecc71)
    .setTitle(`${prof.emoji} ${prof.name}`)
    .setDescription(`${prof.taskText}\nProgress: ${progressBar(progress, prof.pressesRequired)}`);
}

function buildWorkRow(prof, ownerId, disabled = false) {
  return new ActionRowBuilder().addComponents(
    new ButtonBuilder()
      .setCustomId(`work:${ownerId}`)
      .setLabel('Work')
      .setEmoji(prof.emoji)
      .setStyle(ButtonStyle.Primary)
      .setDisabled(disabled),
    new ButtonBuilder()
      .setCustomId(`workchange:${ownerId}`)
      .setLabel('Change Profession')
      .setStyle(ButtonStyle.Secondary),
  );
}

function buildProfessionSelectRow(ownerId) {
  const menu = new StringSelectMenuBuilder()
    .setCustomId(`professionselect:${ownerId}`)
    .setPlaceholder('Choose a profession')
    .addOptions(getAllProfessions().slice(0, 25).map(p => ({
      label: p.name,
      description: p.description.slice(0, 100),
      value: p.id,
      emoji: p.emoji,
    })));
  return new ActionRowBuilder().addComponents(menu);
}

// ---------------------------------------------------------------------------
// SLASH COMMAND DEFINITIONS
// ---------------------------------------------------------------------------
const commands = [
  // ---- /economy: core wallet & activity commands -------------------------
  new SlashCommandBuilder()
    .setName('economy')
    .setDescription('Core economy commands: balance, daily, work, profile, leaderboard')
    .addSubcommand(sc => sc.setName('balance')
      .setDescription('Check your (or another user\'s) Dirham balance')
      .addUserOption(o => o.setName('user').setDescription('User to check').setRequired(false)))
    .addSubcommand(sc => sc.setName('daily').setDescription('Claim your daily halal income'))
    .addSubcommand(sc => sc.setName('work').setDescription('Do halal work to earn Dirham (based on your chosen profession)'))
    .addSubcommand(sc => sc.setName('profile')
      .setDescription('View a combined profile card: balance, profession, level & badge')
      .addUserOption(o => o.setName('user').setDescription('User to view').setRequired(false)))
    .addSubcommand(sc => sc.setName('inventory')
      .setDescription('View items you\'ve automatically received from market purchases')
      .addUserOption(o => o.setName('user').setDescription('User to view').setRequired(false)))
    .addSubcommand(sc => sc.setName('use')
      .setDescription('Toggle on/off a role-granting item from your inventory')
      .addStringOption(o => o.setName('item').setDescription('Item to toggle').setRequired(true).setAutocomplete(true)))
    .addSubcommand(sc => sc.setName('history').setDescription('View your recent transaction history'))
    .addSubcommand(sc => sc.setName('achievements')
      .setDescription('View your unlocked (and locked) achievements')
      .addUserOption(o => o.setName('user').setDescription('User to view').setRequired(false)))
    .addSubcommand(sc => sc.setName('invite').setDescription('Get your personal referral code to share with friends'))
    .addSubcommand(sc => sc.setName('redeem')
      .setDescription('Redeem a friend\'s referral code (one-time, new members only)')
      .addStringOption(o => o.setName('code').setDescription('The referral code to redeem').setRequired(true)))
    .addSubcommand(sc => sc.setName('quiz').setDescription('Answer a quick Islamic knowledge question for a small reward'))
    .addSubcommand(sc => sc.setName('giftcode')
      .setDescription('Redeem a gift code for its reward')
      .addStringOption(o => o.setName('code').setDescription('The gift code to redeem').setRequired(true)))
    .addSubcommand(sc => sc.setName('leaderboard').setDescription('Top richest users'))
    .addSubcommand(sc => sc.setName('about').setDescription('Show bot name, version, and info'))
    .addSubcommand(sc => sc.setName('tos').setDescription('View the Terms of Service for this bot\'s virtual economy')),

  // ---- /profession: choose & browse professions ---------------------------
  new SlashCommandBuilder()
    .setName('profession')
    .setDescription('Choose & manage your halal profession')
    .addSubcommand(sc => sc.setName('choose')
      .setDescription('Choose your new profession')
      .addStringOption(o => o.setName('profession')
        .setDescription('The profession to choose (type to search, including this server\'s custom ones)')
        .setRequired(true)
        .setAutocomplete(true)))
    .addSubcommand(sc => sc.setName('info').setDescription('Check your current profession & work progress'))
    .addSubcommand(sc => sc.setName('list').setDescription('List all available professions')),

  // ---- /finance: zakat, sedekah, mudarabah, qard, grouped by concept -----
  new SlashCommandBuilder()
    .setName('finance')
    .setDescription('Islamic finance: zakat, sedekah, mudarabah investment, qard hasan loans, and waqf endowment')
    .addSubcommandGroup(g => g.setName('zakat')
      .setDescription('Zakat (obligatory almsgiving)')
      .addSubcommand(sc => sc.setName('info').setDescription('Check your zakat status'))
      .addSubcommand(sc => sc.setName('pay').setDescription('Pay your due zakat (2.5% above nisab)'))
      .addSubcommand(sc => sc.setName('pool').setDescription('Check total community zakat pool')))
    .addSubcommandGroup(g => g.setName('sedekah')
      .setDescription('Voluntary charity (sedekah)')
      .addSubcommand(sc => sc.setName('user')
        .setDescription('Give sedekah to another user')
        .addUserOption(o => o.setName('target').setDescription('Recipient').setRequired(true))
        .addIntegerOption(o => o.setName('amount').setDescription('Amount').setRequired(true).setMinValue(1)))
      .addSubcommand(sc => sc.setName('pool')
        .setDescription('Give sedekah to the community charity pool')
        .addIntegerOption(o => o.setName('amount').setDescription('Amount').setRequired(true).setMinValue(1))))
    .addSubcommandGroup(g => g.setName('mudarabah')
      .setDescription('Profit-and-loss sharing investment (no interest, no gambling)')
      .addSubcommand(sc => sc.setName('invest')
        .setDescription('Invest capital into a simulated halal business venture')
        .addIntegerOption(o => o.setName('amount').setDescription('Capital to invest').setRequired(true).setMinValue(CONFIG.MUDARABAH_MIN)))
      .addSubcommand(sc => sc.setName('status').setDescription('Check your ongoing investment'))
      .addSubcommand(sc => sc.setName('withdraw').setDescription('Withdraw capital + your share of profit/loss once the cycle ends')))
    .addSubcommandGroup(g => g.setName('qard')
      .setDescription('Qard Hasan: interest-free loans between users')
      .addSubcommand(sc => sc.setName('request')
        .setDescription('Request an interest-free loan from another user')
        .addUserOption(o => o.setName('lender').setDescription('Who you are borrowing from').setRequired(true))
        .addIntegerOption(o => o.setName('amount').setDescription('Amount to borrow').setRequired(true).setMinValue(1)))
      .addSubcommand(sc => sc.setName('repay')
        .setDescription('Repay a debt you owe (exact amount, no interest)')
        .addUserOption(o => o.setName('lender').setDescription('Who you owe').setRequired(true))
        .addIntegerOption(o => o.setName('amount').setDescription('Amount to repay').setRequired(true).setMinValue(1)))
      .addSubcommand(sc => sc.setName('list').setDescription('List your debts and loans')))
    .addSubcommandGroup(g => g.setName('waqf')
      .setDescription('Waqf: a permanent community endowment, separate from the sedekah pool')
      .addSubcommand(sc => sc.setName('donate')
        .setDescription('Donate to this server\'s waqf endowment (permanent — principal is never spent)')
        .addIntegerOption(o => o.setName('amount').setDescription('Amount to donate').setRequired(true).setMinValue(1)))
      .addSubcommand(sc => sc.setName('status').setDescription('Check the waqf endowment\'s principal, distributable yield, and top contributors'))),

  // ---- /market: player-driven halal market & item purchasing --------------
  new SlashCommandBuilder()
    .setName('market')
    .setDescription('Open, browse, and shop the player-driven halal market')
    .addSubcommand(sc => sc.setName('open')
      .setDescription('Open your own halal market stall for other members to browse')
      .addStringOption(o => o.setName('name').setDescription('Name of your market (must be unique in this server)').setRequired(true).setMaxLength(50))
      .addStringOption(o => o.setName('item1').setDescription('First item for sale (e.g. a role name or channel access)').setRequired(true).setMaxLength(100))
      .addIntegerOption(o => o.setName('allitemprice').setDescription('Price for any single item in this market').setRequired(true).setMinValue(1))
      .addStringOption(o => o.setName('item1content').setDescription('PRIVATE: DMed to buyer after purchase only (e.g. a link) — never shown publicly').setRequired(false).setMaxLength(1000))
      .addRoleOption(o => o.setName('item1role').setDescription('Discord role item1 grants — buyer can toggle it with /economy use').setRequired(false))
      .addStringOption(o => o.setName('item2').setDescription('Second item for sale').setRequired(false).setMaxLength(100))
      .addStringOption(o => o.setName('item2content').setDescription('PRIVATE content delivered only by DM after item2 is bought').setRequired(false).setMaxLength(1000))
      .addRoleOption(o => o.setName('item2role').setDescription('Discord role item2 grants').setRequired(false))
      .addStringOption(o => o.setName('item3').setDescription('Third item for sale').setRequired(false).setMaxLength(100))
      .addStringOption(o => o.setName('item3content').setDescription('PRIVATE content delivered only by DM after item3 is bought').setRequired(false).setMaxLength(1000))
      .addRoleOption(o => o.setName('item3role').setDescription('Discord role item3 grants').setRequired(false)))
    .addSubcommand(sc => sc.setName('remove')
      .setDescription('Close/remove one of your own markets')
      .addStringOption(o => o.setName('name').setDescription('Name of the market to remove').setRequired(true).setAutocomplete(true)))
    .addSubcommand(sc => sc.setName('browse').setDescription('Browse every market opened by members of this server'))
    .addSubcommand(sc => sc.setName('search')
      .setDescription('Look up one member\'s market by its name')
      .addStringOption(o => o.setName('name').setDescription('Name of the market to search for').setRequired(true).setAutocomplete(true)))
    .addSubcommand(sc => sc.setName('additem')
      .setDescription('Add a purchasable item (with image + description) to your own market')
      .addStringOption(o => o.setName('market').setDescription('Your market').setRequired(true).setAutocomplete(true))
      .addStringOption(o => o.setName('name').setDescription('Item name').setRequired(true).setMaxLength(80))
      .addIntegerOption(o => o.setName('price').setDescription('Price for this item').setRequired(true).setMinValue(1))
      .addStringOption(o => o.setName('description').setDescription('Public blurb shown on the item card BEFORE purchase — never put secrets/links here').setRequired(false).setMaxLength(300))
      .addStringOption(o => o.setName('image').setDescription('Image URL shown on the item card (must start with http:// or https://)').setRequired(false))
      .addIntegerOption(o => o.setName('stock').setDescription('How many are available (leave empty for unlimited)').setRequired(false).setMinValue(0))
      .addRoleOption(o => o.setName('role').setDescription('Discord role this item grants — buyers can toggle it on/off with /economy use').setRequired(false))
      .addStringOption(o => o.setName('content').setDescription('PRIVATE: DMed to buyer after purchase only (e.g. a link) — hidden from everyone else').setRequired(false).setMaxLength(1000)))
    .addSubcommand(sc => sc.setName('removeitem')
      .setDescription('Remove one of your items from your market')
      .addStringOption(o => o.setName('market').setDescription('Your market').setRequired(true).setAutocomplete(true))
      .addStringOption(o => o.setName('item').setDescription('The item to remove').setRequired(true).setAutocomplete(true)))
    .addSubcommand(sc => sc.setName('buy')
      .setDescription('View an item\'s card and purchase it')
      .addStringOption(o => o.setName('market').setDescription('Which market').setRequired(true).setAutocomplete(true))
      .addStringOption(o => o.setName('item').setDescription('Which item').setRequired(true).setAutocomplete(true)))
    .addSubcommand(sc => sc.setName('edititem')
      .setDescription('Edit an existing item\'s price/description/content/image/stock/role')
      .addStringOption(o => o.setName('market').setDescription('Your market').setRequired(true).setAutocomplete(true))
      .addStringOption(o => o.setName('item').setDescription('The item to edit').setRequired(true).setAutocomplete(true))
      .addIntegerOption(o => o.setName('price').setDescription('New price').setRequired(false).setMinValue(1))
      .addStringOption(o => o.setName('description').setDescription('New public blurb — never put secrets/links here').setRequired(false).setMaxLength(300))
      .addStringOption(o => o.setName('content').setDescription('New PRIVATE content, DMed only after purchase').setRequired(false).setMaxLength(1000))
      .addStringOption(o => o.setName('image').setDescription('New image URL (http:// or https://)').setRequired(false))
      .addIntegerOption(o => o.setName('stock').setDescription('New stock count (0 = out of stock)').setRequired(false).setMinValue(0))
      .addRoleOption(o => o.setName('role').setDescription('New role this item grants').setRequired(false)))
    .addSubcommand(sc => sc.setName('rate')
      .setDescription('Rate a market you\'ve bought from (1-5 stars)')
      .addStringOption(o => o.setName('market').setDescription('The market to rate').setRequired(true).setAutocomplete(true))
      .addIntegerOption(o => o.setName('stars').setDescription('Rating from 1 to 5').setRequired(true).setMinValue(1).setMaxValue(5))
      .addStringOption(o => o.setName('review').setDescription('Optional short review').setRequired(false).setMaxLength(200)))
    .addSubcommand(sc => sc.setName('finditem')
      .setDescription('Search item names across every market in this server')
      .addStringOption(o => o.setName('query').setDescription('Text to search for in item names').setRequired(true).setMaxLength(80)))
    .addSubcommandGroup(g => g.setName('auction')
      .setDescription('Time-limited auctions — highest bid wins when it ends')
      .addSubcommand(sc => sc.setName('start')
        .setDescription('Start an auction for an item')
        .addStringOption(o => o.setName('name').setDescription('What you\'re auctioning').setRequired(true).setMaxLength(80))
        .addIntegerOption(o => o.setName('startprice').setDescription('Starting bid').setRequired(true).setMinValue(1))
        .addIntegerOption(o => o.setName('duration').setDescription('Duration in minutes (1-1440)').setRequired(true).setMinValue(1).setMaxValue(1440))
        .addStringOption(o => o.setName('content').setDescription('PRIVATE content DMed only to the winner').setRequired(false).setMaxLength(1000)))
      .addSubcommand(sc => sc.setName('bid')
        .setDescription('Place a bid on an ongoing auction')
        .addStringOption(o => o.setName('auction').setDescription('Which auction').setRequired(true).setAutocomplete(true))
        .addIntegerOption(o => o.setName('amount').setDescription('Your bid amount').setRequired(true).setMinValue(1)))
      .addSubcommand(sc => sc.setName('list').setDescription('List ongoing auctions in this server'))),

  // ---- /islamic: calendar & prayer time features --------------------------
  new SlashCommandBuilder()
    .setName('islamic')
    .setDescription('Hijri calendar and prayer time (adzan) info')
    .addSubcommand(sc => sc.setName('hijri').setDescription('Check today\'s Hijri (Islamic) calendar date'))
    .addSubcommand(sc => sc.setName('persian').setDescription('Check today\'s Persian (Solar Hijri) calendar date'))
    .addSubcommand(sc => sc.setName('adzan-list').setDescription('List all channels configured for prayer time reminders in this server')),

  // ---- /admin: server configuration, all admin-only ------------------------
  new SlashCommandBuilder()
    .setName('admin')
    .setDescription('(Admin) Server configuration for the economy bot')
    .setDefaultMemberPermissions(PermissionFlagsBits.Administrator)
    .addSubcommand(sc => sc.setName('profession-add')
      .setDescription('Add a custom profession for this server')
      .addStringOption(o => o.setName('profname').setDescription('Name of the new profession').setRequired(true))
      .addStringOption(o => o.setName('description').setDescription('Flavor text describing the work task').setRequired(true))
      .addIntegerOption(o => o.setName('worktime')
        .setDescription('Cooldown in minutes after finishing a work session (1-1440)')
        .setRequired(true).setMinValue(1).setMaxValue(1440))
      .addIntegerOption(o => o.setName('dhr')
        .setDescription('Dirham Rate (1-100): how much this profession pays per work session')
        .setRequired(true).setMinValue(1).setMaxValue(100)))
    .addSubcommand(sc => sc.setName('currency-emoji')
      .setDescription('Change the currency emoji shown in bot messages')
      .addStringOption(o => o.setName('emoji')
        .setDescription('A server emoji or any emoji from your keyboard')
        .setRequired(true)))
    .addSubcommand(sc => sc.setName('currency-name')
      .setDescription('Rename this server\'s currency (replaces "Dirham" in bot text)')
      .addStringOption(o => o.setName('name')
        .setDescription('New currency name for this server, e.g. Riyal, Dinar, Gold Coin')
        .setRequired(true).setMaxLength(30)))
    .addSubcommand(sc => sc.setName('backup').setDescription('Export this server\'s economy data as a JSON file'))
    .addSubcommand(sc => sc.setName('audit').setDescription('View the recent admin/economic action log for this server'))
    .addSubcommand(sc => sc.setName('refund')
      .setDescription('Reverse a user\'s market purchase (removes item, refunds buyer, deducts seller)')
      .addUserOption(o => o.setName('user').setDescription('The buyer to refund').setRequired(true))
      .addStringOption(o => o.setName('item').setDescription('Name of the purchased item to refund').setRequired(true)))
    .addSubcommand(sc => sc.setName('auction-cancel')
      .setDescription('Cancel an ongoing auction and refund the current bidder, if any')
      .addStringOption(o => o.setName('auction').setDescription('Name of the auction to cancel').setRequired(true).setAutocomplete(true)))
    .addSubcommandGroup(g => g.setName('rolereward')
      .setDescription('Configure Discord roles auto-granted at balance milestones')
      .addSubcommand(sc => sc.setName('add')
        .setDescription('Grant a role automatically once a member\'s balance reaches an amount')
        .addRoleOption(o => o.setName('role').setDescription('Role to grant').setRequired(true))
        .addIntegerOption(o => o.setName('amount').setDescription('Balance threshold required').setRequired(true).setMinValue(1)))
      .addSubcommand(sc => sc.setName('remove')
        .setDescription('Remove a configured role reward')
        .addRoleOption(o => o.setName('role').setDescription('Role to stop auto-granting').setRequired(true)))
      .addSubcommand(sc => sc.setName('list').setDescription('List all configured role rewards for this server')))
    .addSubcommandGroup(g => g.setName('waqf')
      .setDescription('Distribute the waqf endowment\'s distributable yield (never the protected principal)')
      .addSubcommand(sc => sc.setName('distribute')
        .setDescription('Pay out yield from the waqf endowment to a member or every holder of a role')
        .addIntegerOption(o => o.setName('amount').setDescription('Amount to distribute from the yield pool').setRequired(true).setMinValue(1))
        .addUserOption(o => o.setName('user').setDescription('Give it all to this member (use this OR role, not both)').setRequired(false))
        .addRoleOption(o => o.setName('role').setDescription('Split it evenly among every member with this role (use this OR user, not both)').setRequired(false))))
    .addSubcommandGroup(g => g.setName('calendar')
      .setDescription('Auto-post the daily Hijri calendar date to a channel')
      .addSubcommand(sc => sc.setName('channel')
        .setDescription('Set the channel for daily Hijri calendar posts (18:00 WIB / Maghrib) and enable it')
        .addChannelOption(o => o.setName('channel').setDescription('Text channel to post in').setRequired(true).addChannelTypes(ChannelType.GuildText)))
      .addSubcommand(sc => sc.setName('disable').setDescription('Turn off daily auto-posting'))
      .addSubcommand(sc => sc.setName('status').setDescription('Check the current auto-calendar setting')))
    .addSubcommandGroup(g => g.setName('persian-calendar')
      .setDescription('Auto-post the daily Persian (Solar Hijri) calendar date to a channel')
      .addSubcommand(sc => sc.setName('channel')
        .setDescription('Set the channel for daily Persian calendar posts (18:00 WIB) and enable it')
        .addChannelOption(o => o.setName('channel').setDescription('Text channel to post in').setRequired(true).addChannelTypes(ChannelType.GuildText)))
      .addSubcommand(sc => sc.setName('disable').setDescription('Turn off daily Persian auto-posting'))
      .addSubcommand(sc => sc.setName('status').setDescription('Check the current Persian auto-calendar setting')))
    .addSubcommandGroup(g => g.setName('adzan')
      .setDescription('Manage channels that receive prayer time (adzan) reminders')
      .addSubcommand(sc => sc.setName('set')
        .setDescription('Add or update a channel that receives prayer time reminders')
        .addChannelOption(o => o.setName('channel').setDescription('Text channel to post prayer reminders in').setRequired(true).addChannelTypes(ChannelType.GuildText))
        .addStringOption(o => o.setName('location')
          .setDescription('Format: Country/City or Country/City/Province, e.g. Indonesia/Jakarta')
          .setRequired(true)))
      .addSubcommand(sc => sc.setName('remove')
        .setDescription('Stop prayer time reminders for a channel')
        .addChannelOption(o => o.setName('channel').setDescription('Channel to remove').setRequired(true).addChannelTypes(ChannelType.GuildText))))
    .addSubcommandGroup(g => g.setName('errorlog')
      .setDescription('Configure a channel that receives bot error reports')
      .addSubcommand(sc => sc.setName('channel')
        .setDescription('Set the channel that receives bot error reports')
        .addChannelOption(o => o.setName('channel').setDescription('Text channel for error reports').setRequired(true).addChannelTypes(ChannelType.GuildText)))
      .addSubcommand(sc => sc.setName('disable').setDescription('Stop sending error reports')))
    .addSubcommand(sc => sc.setName('addmoney')
      .setDescription('Grant balance to a member — created fresh, not taken from anyone')
      .addUserOption(o => o.setName('user').setDescription('Who receives the balance (can be any member, including admins)').setRequired(true))
      .addIntegerOption(o => o.setName('amount').setDescription('Amount to add').setRequired(true).setMinValue(1)))
    .addSubcommandGroup(g => g.setName('giftcode')
      .setDescription('Create and manage redeemable gift codes')
      .addSubcommand(sc => sc.setName('create')
        .setDescription('Create a new gift code members can redeem')
        .addStringOption(o => o.setName('code').setDescription('The code members will type in (not case-sensitive)').setRequired(true).setMaxLength(30))
        .addIntegerOption(o => o.setName('duration').setDescription('How long the code stays valid, in minutes').setRequired(true).setMinValue(1).setMaxValue(525600))
        .addIntegerOption(o => o.setName('money').setDescription('Balance reward (leave empty for none)').setRequired(false).setMinValue(1))
        .addRoleOption(o => o.setName('role').setDescription('Role reward — toggleable later with /economy use').setRequired(false))
        .addStringOption(o => o.setName('prize').setDescription('Description of a non-balance prize (e.g. "1 free consultation")').setRequired(false).setMaxLength(200)))
      .addSubcommand(sc => sc.setName('list').setDescription('List currently active gift codes'))
      .addSubcommand(sc => sc.setName('revoke')
        .setDescription('Deactivate a gift code early')
        .addStringOption(o => o.setName('code').setDescription('The code to revoke').setRequired(true).setAutocomplete(true)))),
].map(c => c.toJSON());

// ---------------------------------------------------------------------------
// REGISTER COMMANDS
// ---------------------------------------------------------------------------
async function registerCommands() {
  const rest = new REST({ version: '10' }).setToken(TOKEN);
  try {
    await rest.put(Routes.applicationCommands(CLIENT_ID), { body: commands });
    console.log('Slash commands registered globally (may take up to 1hr to propagate to all servers).');
  } catch (err) {
    console.error('Failed to register commands:', err);
  }
}

// ---------------------------------------------------------------------------
// CLIENT
// ---------------------------------------------------------------------------
// GuildMembers is a *privileged* intent — it must also be toggled ON under
// "Server Members Intent" in the Discord Developer Portal (Bot tab) or the
// bot will fail to log in. It's required for the role reward system
// (/rolereward) to fetch member objects and assign roles automatically.
const client = new Client({
  intents: [GatewayIntentBits.Guilds, GatewayIntentBits.GuildMembers],
  // This bot never reads message content, reactions, presences, invites, etc. — by default
  // discord.js caches all of that forever in RAM, which is the #1 cause of a Node.js Discord
  // bot's memory usage growing over time. Setting these to 0 (or a low cap) stops that cache
  // from being built in the first place, since we only ever fetch members/users on demand.
  makeCache: Options.cacheWithLimits({
    ...Options.DefaultMakeCacheSettings,
    MessageManager: 0,
    ReactionManager: 0,
    PresenceManager: 0,
    GuildInviteManager: 0,
    GuildScheduledEventManager: 0,
    ThreadManager: 0,
    StageInstanceManager: 0,
    GuildBanManager: 0,
    GuildEmojiManager: 200,       // used for /admin currency-emoji lookups, small cap is enough
    GuildMemberManager: 500,      // used for role grant/rolereward — capped so it doesn't grow unbounded on large servers
    UserManager: 500,
  }),
  // Even with caps above, periodically sweep out old cached members/users that haven't
  // been touched in a while, so long-running processes don't slowly creep back up in RAM.
  sweepers: {
    ...Sweepers.defaultSweeperSettings,
    guildMembers: {
      interval: 3600,             // every hour
      filter: () => (member) => member.id !== client.user?.id,
    },
    users: {
      interval: 3600,
      filter: () => (user) => user.id !== client.user?.id,
    },
  },
});

client.once('ready', async () => {
  console.log(`Logged in as ${client.user.tag} — ${CONFIG.BOT_NAME} v${CONFIG.VERSION}`);
  client.user.setActivity(`${CONFIG.BOT_NAME} v${CONFIG.VERSION} | /economy work`, { type: 3 }); // type 3 = Watching
  await registerCommands();
  startAutoCalendarScheduler();
  startAdzanScheduler();
  setInterval(() => resolveEndedAuctions(client, loadDB()), CONFIG.ADZAN_CHECK_INTERVAL_MS);
});

client.on('interactionCreate', async (interaction) => {
  let db;
  try {
    db = loadDB();
  } catch (err) {
    // loadDB() is self-healing against a corrupted file (see loadDB itself),
    // so reaching here means something else entirely broke (e.g. disk full,
    // permissions). Reply instead of leaving Discord to time out with
    // "The application did not respond" and no explanation at all.
    console.error('Fatal: could not load database:', err);
    if (interaction.isAutocomplete()) return interaction.respond([]).catch(() => null);
    if (interaction.isRepliable()) {
      await interaction.reply({ embeds: [simpleEmbed('⚠️ The bot hit a storage error and couldn\'t load its data. Please try again in a moment.', 0xe74c3c)], ephemeral: true }).catch(() => null);
    }
    return;
  }

  // This bot's economy is per-server: each guild has its own isolated balances,
  // professions, and currency emoji. DMs have no guild to scope data to.
  if (!interaction.guildId) {
    if (interaction.isAutocomplete()) return interaction.respond([]);
    if (interaction.isRepliable()) {
      await interaction.reply({ embeds: [simpleEmbed('⚠️ This bot only works inside a server, not in DMs.')], ephemeral: true });
    }
    return;
  }

  CTX = { db, guildId: interaction.guildId };

  // Basic anti-spam: ignore (not even an error reply, just silently drop) rapid
  // repeat commands/button clicks from the same user. Autocomplete is exempt —
  // Discord fires that continuously as someone types, that's not abuse.
  if (!interaction.isAutocomplete() && isRateLimited(interaction.user.id)) {
    if (interaction.isRepliable()) {
      await interaction.reply({ embeds: [simpleEmbed('⏳ You\'re doing that too fast — try again in a second.')], ephemeral: true }).catch(() => null);
    }
    return;
  }

  try {
    if (interaction.isChatInputCommand()) {
      const { commandName } = interaction;
      const sub = interaction.options.getSubcommand(false);
      const group = interaction.options.getSubcommandGroup(false);

      if (commandName === 'economy') {
        if (sub === 'balance') await handleBalance(interaction, db);
        else if (sub === 'daily') await handleDaily(interaction, db);
        else if (sub === 'work') await handleWork(interaction, db);
        else if (sub === 'profile') await handleProfile(interaction, db);
        else if (sub === 'inventory') await handleInventory(interaction, db);
        else if (sub === 'use') await handleUseItem(interaction, db);
        else if (sub === 'history') await handleHistory(interaction, db);
        else if (sub === 'achievements') await handleAchievements(interaction, db);
        else if (sub === 'invite') await handleInvite(interaction, db);
        else if (sub === 'redeem') await handleRedeem(interaction, db);
        else if (sub === 'quiz') await handleQuiz(interaction, db);
        else if (sub === 'giftcode') await handleClaimGiftCode(interaction, db);
        else if (sub === 'leaderboard') await handleLeaderboard(interaction, db);
        else if (sub === 'about') await handleAbout(interaction, db);
        else if (sub === 'tos') await handleTos(interaction, db);
      } else if (commandName === 'profession') {
        await handleProfession(interaction, db);
      } else if (commandName === 'finance') {
        if (group === 'zakat') await handleZakat(interaction, db);
        else if (group === 'sedekah') await handleSedekah(interaction, db);
        else if (group === 'mudarabah') await handleMudarabah(interaction, db);
        else if (group === 'qard') await handleQard(interaction, db);
        else if (group === 'waqf') await handleWaqf(interaction, db);
      } else if (commandName === 'market') {
        if (sub === 'open') await handleAddMarket(interaction, db);
        else if (sub === 'remove') await handleRemoveMarket(interaction, db);
        else if (sub === 'browse') await handleAllServerMarket(interaction, db);
        else if (sub === 'search') await handleMarketSearch(interaction, db);
        else if (sub === 'finditem') await handleFindItem(interaction, db);
        else if (sub === 'rate') await handleRateMarket(interaction, db);
        else if (sub === 'additem') await handleAddItem(interaction, db);
        else if (sub === 'removeitem') await handleRemoveItem(interaction, db);
        else if (sub === 'buy') await handleBuy(interaction, db);
        else if (sub === 'edititem') await handleEditItem(interaction, db);
        else if (group === 'auction') {
          if (sub === 'start') await handleAuctionStart(interaction, db);
          else if (sub === 'bid') await handleAuctionBid(interaction, db);
          else if (sub === 'list') await handleAuctionList(interaction, db);
        }
      } else if (commandName === 'islamic') {
        if (sub === 'hijri') await handleHijri(interaction, db);
        else if (sub === 'persian') await handlePersian(interaction, db);
        else if (sub === 'adzan-list') await handleListAdzanChannels(interaction, db);
      } else if (commandName === 'admin') {
        if (group === 'rolereward') await handleRoleReward(interaction, db);
        else if (group === 'waqf') await handleAdminWaqfDistribute(interaction, db);
        else if (group === 'calendar') await handleAutoCalendar(interaction, db);
        else if (group === 'persian-calendar') await handleAutoCalendarPersian(interaction, db);
        else if (group === 'adzan') {
          if (sub === 'set') await handleSetAdzanChannel(interaction, db);
          else if (sub === 'remove') await handleRemoveAdzanChannel(interaction, db);
        } else if (group === 'errorlog') await handleErrorLogConfig(interaction, db);
        else if (group === 'giftcode') {
          if (sub === 'create') await handleGiftCodeCreate(interaction, db);
          else if (sub === 'list') await handleGiftCodeList(interaction, db);
          else if (sub === 'revoke') await handleGiftCodeRevoke(interaction, db);
        } else if (sub === 'profession-add') await handleAddProfession(interaction, db);
        else if (sub === 'currency-emoji') await handleSetCurrencyEmoji(interaction, db);
        else if (sub === 'currency-name') await handleSetCurrencyName(interaction, db);
        else if (sub === 'backup') await handleBackup(interaction, db);
        else if (sub === 'audit') await handleAudit(interaction, db);
        else if (sub === 'refund') await handleRefund(interaction, db);
        else if (sub === 'auction-cancel') await handleAuctionCancel(interaction, db);
        else if (sub === 'addmoney') await handleAddMoney(interaction, db);
      }
    } else if (interaction.isAutocomplete()) {
      const focusedName = interaction.options.getFocused(true).name;
      const sub = interaction.options.getSubcommand(false);
      if (interaction.commandName === 'profession') await handleProfessionAutocomplete(interaction);
      else if (interaction.commandName === 'economy' && sub === 'use') await handleUseItemAutocomplete(interaction, db);
      else if (interaction.commandName === 'market') {
        if (sub === 'remove') await handleOwnMarketAutocomplete(interaction, db);
        else if (sub === 'search') await handleAnyMarketAutocomplete(interaction, db);
        else if (sub === 'additem') await handleOwnMarketAutocomplete(interaction, db);
        else if (sub === 'removeitem') {
          if (focusedName === 'market') await handleOwnMarketAutocomplete(interaction, db);
          else if (focusedName === 'item') await handleItemAutocomplete(interaction, db);
        } else if (sub === 'buy') {
          if (focusedName === 'market') await handleAnyMarketAutocomplete(interaction, db);
          else if (focusedName === 'item') await handleItemAutocomplete(interaction, db);
        } else if (sub === 'edititem') {
          if (focusedName === 'market') await handleOwnMarketAutocomplete(interaction, db);
          else if (focusedName === 'item') await handleItemAutocomplete(interaction, db);
        } else if (sub === 'bid' && focusedName === 'auction') {
          await handleAuctionAutocomplete(interaction, db);
        } else if (sub === 'rate' && focusedName === 'market') {
          await handleAnyMarketAutocomplete(interaction, db);
        }
      } else if (interaction.commandName === 'admin' && sub === 'auction-cancel') {
        await handleAuctionAutocomplete(interaction, db);
      } else if (interaction.commandName === 'admin' && sub === 'revoke') {
        await handleGiftCodeAutocomplete(interaction, db);
      }
    } else if (interaction.isButton()) {
      const parts = interaction.customId.split(':');
      const action = parts[0];
      if (action === 'work') await handleWorkPress(interaction, db, parts[1]);
      else if (action === 'workchange') await handleWorkChangePrompt(interaction, db, parts[1]);
      else if (action === 'buyitem') await handleBuyItemClick(interaction, db, parts[1], parts[2], parts[3]);
      else if (action === 'quiz') await handleQuizAnswer(interaction, db, parts[1], parts[2]);
      else if (action === 'confirmyes') await handleConfirmYes(interaction, db, parts[1]);
      else if (action === 'confirmno') await handleConfirmNo(interaction, parts[1]);
    } else if (interaction.isStringSelectMenu()) {
      const [action, ownerId] = interaction.customId.split(':');
      if (action === 'professionselect') await handleProfessionSelect(interaction, db, ownerId);
    }
  } catch (err) {
    console.error(err);
    const cmdContext = interaction.isChatInputCommand() || interaction.isAutocomplete()
      ? `/${interaction.commandName}${interaction.options?.getSubcommand?.(false) ? ' ' + interaction.options.getSubcommand(false) : ''} — used by ${interaction.user?.tag || interaction.user?.id}`
      : `Interaction type: ${interaction.type} — used by ${interaction.user?.tag || interaction.user?.id}`;
    await logErrorToChannel(client, db, interaction.guildId, err, cmdContext);
    if (interaction.isAutocomplete()) {
      try { await interaction.respond([]); } catch (_) { /* ignore */ }
      return;
    }
    const msg = { embeds: [simpleEmbed('Something went wrong. Please try again.', 0xe74c3c)], ephemeral: true };
    if (interaction.replied || interaction.deferred) await interaction.followUp(msg);
    else await interaction.reply(msg);
  }
});

// ---------------------------------------------------------------------------
// HANDLERS
// ---------------------------------------------------------------------------
async function handleBalance(interaction, db) {
  const target = interaction.options.getUser('user') || interaction.user;
  const u = getUser(db, target.id);
  saveDB(db);

  const embed = new EmbedBuilder()
    .setColor(0x1abc9c)
    .setTitle(`💰 ${target.username}'s Balance`)
    .setDescription(`**${fmt(u.balance)}**`)
    .setFooter({ text: 'Syariah Economy Bot' });

  await interaction.reply({ embeds: [embed] });
}

async function handleDaily(interaction, db) {
  const u = getUser(db, interaction.user.id);
  const now = Date.now();
  const remaining = u.lastDaily + CONFIG.DAILY_COOLDOWN_MS - now;

  if (remaining > 0) {
    const hrs = Math.ceil(remaining / (60 * 60 * 1000));
    return interaction.reply({ embeds: [simpleEmbed(`⏳ You already claimed today's rizq. Try again in ~${hrs}h.`)], ephemeral: true });
  }

  const amount = randInt(CONFIG.DAILY_AMOUNT[0], CONFIG.DAILY_AMOUNT[1]);
  u.balance += amount;
  u.lastDaily = now;
  logTransaction(u, 'daily', amount, 'Daily rizq claim');
  saveDB(db);
  await checkRoleRewards(interaction.guild, db, interaction.user.id, u.balance);

  await interaction.reply({ embeds: [simpleEmbed(`🌅 Alhamdulillah! You received your daily rizq of **${fmt(amount)}**.`)] });
}

async function handleWork(interaction, db) {
  const u = getUser(db, interaction.user.id);

  if (!u.profession) {
    saveDB(db);
    return interaction.reply({
      embeds: [simpleEmbed("⚠️ You haven't chosen a profession yet! Use `/profession choose` to pick one first.")],
      ephemeral: true,
    });
  }

  const prof = getProfession(u.profession);
  const now = Date.now();
  const remaining = u.lastWork + prof.cooldownMs - now;

  // only blocked by cooldown if they're not mid-way through an unfinished work card
  if (remaining > 0 && u.workProgress === 0) {
    const mins = Math.ceil(remaining / (60 * 1000));
    return interaction.reply({ embeds: [simpleEmbed(`⏳ You're still resting from work as **${prof.name}**. Try again in ~${mins}m.`)], ephemeral: true });
  }

  saveDB(db);
  const embed = buildWorkEmbed(prof, u.workProgress);
  const row = buildWorkRow(prof, interaction.user.id);
  return interaction.reply({ embeds: [embed], components: [row] });
}

async function handleProfession(interaction, db) {
  const sub = interaction.options.getSubcommand();

  if (sub === 'list') {
    const all = getAllProfessions();
    const list = all.map(p =>
      `${p.emoji} **${p.name}**${p.custom ? ' *(custom)*' : ''} — ${p.description}\n　└ ${p.pressesRequired}x presses, ~${fmt(p.amountPerPress[0])}-${fmt(p.amountPerPress[1])}/press, cooldown ${Math.round(p.cooldownMs / 60000)}m`
    ).join('\n\n');
    const embed = new EmbedBuilder()
      .setColor(0x2ecc71)
      .setTitle('👷 Profession List')
      .setDescription(list);
    return interaction.reply({ embeds: [embed] });
  }

  const u = getUser(db, interaction.user.id);

  if (sub === 'choose') {
    const profId = interaction.options.getString('profession');
    const prof = getProfession(profId);
    if (!prof) {
      return interaction.reply({ embeds: [simpleEmbed("That profession wasn't found. Please pick one from the autocomplete suggestions as you type.")], ephemeral: true });
    }
    u.profession = profId;
    u.workProgress = 0;
    saveDB(db);
    return interaction.reply({ embeds: [simpleEmbed(`✅ Your profession is now **${prof.emoji} ${prof.name}**! Use \`/economy work\` to start earning.`)] });
  }

  if (sub === 'info') {
    saveDB(db);
    if (!u.profession) {
      return interaction.reply({ embeds: [simpleEmbed("You haven't chosen a profession yet. Use `/profession choose` to pick one.")], ephemeral: true });
    }
    const prof = getProfession(u.profession);
    if (!prof) {
      return interaction.reply({ embeds: [simpleEmbed('Your previously chosen profession no longer exists. Please pick a new one with `/profession choose`.')], ephemeral: true });
    }
    const embed = new EmbedBuilder()
      .setColor(0x2ecc71)
      .setTitle(`${prof.emoji} Profession: ${prof.name}`)
      .setDescription(prof.description)
      .addFields({ name: 'Current Progress', value: progressBar(u.workProgress, prof.pressesRequired) });
    return interaction.reply({ embeds: [embed] });
  }
}

async function handleProfessionAutocomplete(interaction) {
  const focused = interaction.options.getFocused().toLowerCase();
  const matches = getAllProfessions()
    .filter(p => p.name.toLowerCase().includes(focused))
    .slice(0, 25)
    .map(p => ({ name: `${p.emoji} ${p.name}${p.custom ? ' (custom)' : ''}`, value: p.id }));
  await interaction.respond(matches);
}

async function handleAddProfession(interaction, db) {
  const name = interaction.options.getString('profname').trim();
  const description = interaction.options.getString('description').trim();
  const worktime = interaction.options.getInteger('worktime'); // cooldown, in minutes
  const dhr = interaction.options.getInteger('dhr');            // Dirham Rate, 1-100

  if (!name.length || name.length > 50) {
    return interaction.reply({ embeds: [simpleEmbed('Profession name must be between 1 and 50 characters.')], ephemeral: true });
  }
  if (!description.length || description.length > 200) {
    return interaction.reply({ embeds: [simpleEmbed('Description must be between 1 and 200 characters.')], ephemeral: true });
  }

  db.customProfessions[CTX.guildId] = db.customProfessions[CTX.guildId] || [];
  const guildCustom = db.customProfessions[CTX.guildId];

  // Discord select menus cap out at 25 options; built-ins (6) + custom must stay under that.
  const MAX_CUSTOM_PROFESSIONS = 19;
  if (guildCustom.length >= MAX_CUSTOM_PROFESSIONS) {
    return interaction.reply({ embeds: [simpleEmbed(`This server already has the maximum of ${MAX_CUSTOM_PROFESSIONS} custom professions.`)], ephemeral: true });
  }

  const slug = name.toLowerCase().replace(/[^a-z0-9]+/g, '_').replace(/^_+|_+$/g, '').slice(0, 40);
  const id = `custom_${slug || Date.now()}`;

  if (getProfession(id)) {
    return interaction.reply({ embeds: [simpleEmbed('A profession with a very similar name already exists in this server. Please choose a different name.')], ephemeral: true });
  }

  const EMOJI_POOL = ['🧑‍💼', '🧰', '🧵', '🧪', '🎨', '🚚', '🧱', '🖥️', '🎬', '🍳', '🚜', '⚒️', '🧑‍🔧', '📦', '🎓', '🧑‍🌾', '🧑‍🍳', '🧑‍⚕️', '🧑‍🎤'];
  const emoji = EMOJI_POOL[guildCustom.length % EMOJI_POOL.length];

  const pressesRequired = 4; // fixed for all custom professions, keeps difficulty consistent
  const amountPerPress = [dhr, dhr * 2];
  const cooldownMs = worktime * 60 * 1000;

  const newProf = {
    id,
    name,
    emoji,
    description,
    taskText: description,
    pressesRequired,
    amountPerPress,
    cooldownMs,
    custom: true,
  };

  guildCustom.push(newProf);
  saveDB(db);

  const embed = new EmbedBuilder()
    .setColor(0x2ecc71)
    .setTitle('✅ Custom Profession Added')
    .setDescription(`${emoji} **${name}** is now available in this server's profession list.`)
    .addFields(
      { name: 'Description', value: description },
      { name: 'Work Sessions', value: `${pressesRequired}x presses`, inline: true },
      { name: 'Pay Per Press', value: `${fmt(amountPerPress[0])} - ${fmt(amountPerPress[1])}`, inline: true },
      { name: 'Cooldown', value: `${worktime} minute(s)`, inline: true },
    )
    .setFooter({ text: 'Members can now select it with /profession choose' });
  return interaction.reply({ embeds: [embed] });
}

async function handleWorkPress(interaction, db, ownerId) {
  if (interaction.user.id !== ownerId) {
    return interaction.reply({ embeds: [simpleEmbed("This isn\'t your work session! Use `/economy work` to start your own.")], ephemeral: true });
  }

  const u = getUser(db, ownerId);
  const prof = getProfession(u.profession);
  if (!prof) {
    return interaction.update({ embeds: [simpleEmbed('Profession not found. Choose one again with `/profession choose`.', 0xe74c3c)], components: [] });
  }

  u.workProgress += 1;

  if (u.workProgress >= prof.pressesRequired) {
    let amount = 0;
    for (let i = 0; i < prof.pressesRequired; i++) amount += randInt(prof.amountPerPress[0], prof.amountPerPress[1]);
    u.balance += amount;
    u.workProgress = 0;
    u.lastWork = Date.now();
    u.stats = u.stats || { purchases: 0, zakatPayments: 0, workCount: 0, mudarabahCount: 0, sedekahTotal: 0 };
    u.stats.workCount = (u.stats.workCount || 0) + 1;
    logTransaction(u, 'work', amount, `Worked as ${prof.name}`);
    const newAchievements = checkAchievements(u);
    saveDB(db);
    await checkRoleRewards(interaction.guild, db, ownerId, u.balance);

    let doneText = `✅ Done! You worked as **${prof.name}** and earned **${fmt(amount)}**.\nCome back again in ~${Math.round(prof.cooldownMs / 60000)}m.`;
    if (newAchievements.length) {
      doneText += `\n🏆 Achievement unlocked: ${newAchievements.map(a => `${a.emoji} **${a.name}**`).join(', ')}!`;
    }
    const doneEmbed = new EmbedBuilder()
      .setColor(0x2ecc71)
      .setTitle(`${prof.emoji} ${prof.name}`)
      .setDescription(doneText);
    return interaction.update({ embeds: [doneEmbed], components: [] });
  }

  saveDB(db);
  const embed = buildWorkEmbed(prof, u.workProgress);
  const row = buildWorkRow(prof, ownerId);
  return interaction.update({ embeds: [embed], components: [row] });
}

async function handleWorkChangePrompt(interaction, db, ownerId) {
  if (interaction.user.id !== ownerId) {
    return interaction.reply({ embeds: [simpleEmbed('Use `/profession choose` to pick your own profession.')], ephemeral: true });
  }
  const row = buildProfessionSelectRow(ownerId);
  return interaction.reply({ embeds: [simpleEmbed('Choose your new profession:')], components: [row], ephemeral: true });
}

async function handleProfessionSelect(interaction, db, ownerId) {
  if (interaction.user.id !== ownerId) {
    return interaction.reply({ embeds: [simpleEmbed("This isn't your menu.")], ephemeral: true });
  }
  const profId = interaction.values[0];
  const prof = getProfession(profId);
  const u = getUser(db, ownerId);
  u.profession = profId;
  u.workProgress = 0;
  saveDB(db);
  return interaction.update({ embeds: [simpleEmbed(`✅ Your profession is now **${prof.emoji} ${prof.name}**! Use \`/economy work\` to start earning.`)], components: [] });
}

async function handleZakat(interaction, db) {
  const sub = interaction.options.getSubcommand();
  const u = getUser(db, interaction.user.id);

  if (sub === 'pool') {
    saveDB(db);
    return interaction.reply({ embeds: [simpleEmbed(`🕌 Community zakat pool currently holds **${fmt(db.zakatPool)}**, distributed to those in need.`)] });
  }

  if (sub === 'info') {
    const due = u.balance > CONFIG.NISAB ? u.balance * CONFIG.ZAKAT_RATE : 0;
    saveDB(db);
    const embed = new EmbedBuilder()
      .setColor(0xf1c40f)
      .setTitle('🕌 Zakat Info')
      .addFields(
        { name: 'Your Balance', value: fmt(u.balance), inline: true },
        { name: 'Nisab Threshold', value: fmt(CONFIG.NISAB), inline: true },
        { name: 'Zakat Due (2.5%)', value: due > 0 ? fmt(due) : 'Not obligatory yet', inline: true },
      );
    return interaction.reply({ embeds: [embed] });
  }

  if (sub === 'pay') {
    if (u.balance <= CONFIG.NISAB) {
      return interaction.reply({ embeds: [simpleEmbed(`You're below nisab (${fmt(CONFIG.NISAB)}), zakat isn't obligatory on you yet. You may still give sedekah voluntarily with \`/finance sedekah\`.`)], ephemeral: true });
    }
    const due = Math.round(u.balance * CONFIG.ZAKAT_RATE);
    u.balance -= due;
    db.zakatPool += due;
    u.stats = u.stats || { purchases: 0, zakatPayments: 0, workCount: 0, mudarabahCount: 0, sedekahTotal: 0 };
    u.stats.zakatPayments = (u.stats.zakatPayments || 0) + 1;
    logTransaction(u, 'zakat', -due, 'Zakat payment');
    const newAchievements = checkAchievements(u);
    saveDB(db);
    let replyText = `✅ You paid your zakat of **${fmt(due)}**. May Allah accept it and purify your wealth.`;
    if (newAchievements.length) {
      replyText += `\n🏆 Achievement unlocked: ${newAchievements.map(a => `${a.emoji} **${a.name}**`).join(', ')}!`;
    }
    return interaction.reply({ embeds: [simpleEmbed(replyText)] });
  }
}

async function handleSedekah(interaction, db) {
  const sub = interaction.options.getSubcommand();
  const sender = getUser(db, interaction.user.id);
  const amount = interaction.options.getInteger('amount');

  if (amount > sender.balance) {
    return interaction.reply({ embeds: [simpleEmbed(`You don't have enough balance. Your balance: ${fmt(sender.balance)}.`)], ephemeral: true });
  }

  if (sub === 'pool') {
    sender.balance -= amount;
    db.sedekahPool += amount;
    sender.stats = sender.stats || { purchases: 0, zakatPayments: 0, workCount: 0, mudarabahCount: 0, sedekahTotal: 0 };
    sender.stats.sedekahTotal = (sender.stats.sedekahTotal || 0) + amount;
    logTransaction(sender, 'sedekah', -amount, 'Sedekah to community pool');
    const newAchievements = checkAchievements(sender);
    saveDB(db);
    let replyText = `🤲 JazakAllahu khairan! You gave **${fmt(amount)}** sedekah to the community pool (total: ${fmt(db.sedekahPool)}).`;
    if (newAchievements.length) replyText += `\n🏆 Achievement unlocked: ${newAchievements.map(a => `${a.emoji} **${a.name}**`).join(', ')}!`;
    return interaction.reply({ embeds: [simpleEmbed(replyText)] });
  }

  if (sub === 'user') {
    const target = interaction.options.getUser('target');
    if (target.id === interaction.user.id) {
      return interaction.reply({ embeds: [simpleEmbed('You cannot give sedekah to yourself.')], ephemeral: true });
    }
    const recipient = getUser(db, target.id);
    sender.balance -= amount;
    recipient.balance += amount;
    sender.stats = sender.stats || { purchases: 0, zakatPayments: 0, workCount: 0, mudarabahCount: 0, sedekahTotal: 0 };
    sender.stats.sedekahTotal = (sender.stats.sedekahTotal || 0) + amount;
    logTransaction(sender, 'sedekah', -amount, `Sedekah to <@${target.id}>`);
    logTransaction(recipient, 'sedekah-received', amount, `Sedekah from <@${interaction.user.id}>`);
    const newAchievements = checkAchievements(sender);
    saveDB(db);
    await checkRoleRewards(interaction.guild, db, target.id, recipient.balance);
    let replyText = `🤲 JazakAllahu khairan! You gave **${fmt(amount)}** sedekah to <@${target.id}>.`;
    if (newAchievements.length) replyText += `\n🏆 Achievement unlocked: ${newAchievements.map(a => `${a.emoji} **${a.name}**`).join(', ')}!`;
    return interaction.reply({ embeds: [simpleEmbed(replyText)] });
  }
}

async function handleMudarabah(interaction, db) {
  const sub = interaction.options.getSubcommand();
  const u = getUser(db, interaction.user.id);

  if (sub === 'invest') {
    if (u.investment) {
      return interaction.reply({ embeds: [simpleEmbed('You already have an ongoing investment. Withdraw it first with `/finance mudarabah withdraw` once the cycle ends.')], ephemeral: true });
    }
    const amount = interaction.options.getInteger('amount');
    if (amount > u.balance) {
      return interaction.reply({ embeds: [simpleEmbed(`Insufficient balance. Your balance: ${fmt(u.balance)}.`)], ephemeral: true });
    }
    u.balance -= amount;
    u.investment = { amount, startTime: Date.now() };
    logTransaction(u, 'mudarabah-invest', -amount, 'Mudarabah investment started');
    saveDB(db);
    const hrs = CONFIG.MUDARABAH_CYCLE_MS / (60 * 60 * 1000);
    return interaction.reply({ embeds: [simpleEmbed(
      `📈 You invested **${fmt(amount)}** into a simulated halal business venture (mudarabah).\n` +
      `Profit or loss will be shared **${CONFIG.MUDARABAH_INVESTOR_SHARE * 100}% to you / ${(1 - CONFIG.MUDARABAH_INVESTOR_SHARE) * 100}% to the operating pool**, as agreed upfront (no fixed interest).\n` +
      `Cycle duration: ~${hrs}h. Use \`/finance mudarabah withdraw\` once it matures.`
    )] });
  }

  if (sub === 'status') {
    if (!u.investment) return interaction.reply({ embeds: [simpleEmbed('You have no ongoing investment.')], ephemeral: true });
    const elapsed = Date.now() - u.investment.startTime;
    const remaining = CONFIG.MUDARABAH_CYCLE_MS - elapsed;
    saveDB(db);
    if (remaining <= 0) {
      return interaction.reply({ embeds: [simpleEmbed(`📊 Your investment of **${fmt(u.investment.amount)}** has matured. Use \`/finance mudarabah withdraw\` to collect it.`)] });
    }
    return interaction.reply({ embeds: [simpleEmbed(`📊 Investment of **${fmt(u.investment.amount)}** ongoing. Matures in ~${Math.ceil(remaining / (60 * 60 * 1000))}h.`)] });
  }

  if (sub === 'withdraw') {
    if (!u.investment) return interaction.reply({ embeds: [simpleEmbed('You have no ongoing investment.')], ephemeral: true });
    const elapsed = Date.now() - u.investment.startTime;
    if (elapsed < CONFIG.MUDARABAH_CYCLE_MS) {
      const remaining = CONFIG.MUDARABAH_CYCLE_MS - elapsed;
      return interaction.reply({ embeds: [simpleEmbed(`Your investment hasn't matured yet. ~${Math.ceil(remaining / (60 * 60 * 1000))}h remaining.`)], ephemeral: true });
    }

    // Simulated business outcome (transparent, disclosed, not a chance-for-money wager: this
    // represents real-world business risk, and both outcomes were disclosed before investing).
    const roll = Math.random();
    let outcomeText, resultAmount;
    const principal = u.investment.amount;

    if (roll < 0.55) {
      // profit scenario
      const profitRate = 0.05 + Math.random() * 0.25; // 5%-30% profit
      const profit = principal * profitRate;
      const investorShare = profit * CONFIG.MUDARABAH_INVESTOR_SHARE;
      resultAmount = principal + investorShare;
      outcomeText = `📈 The venture was profitable! Total profit: ${fmt(profit)}. Your share: **${fmt(investorShare)}**.`;
    } else if (roll < 0.85) {
      // breakeven
      resultAmount = principal;
      outcomeText = `➖ The venture broke even. Your capital is returned in full: **${fmt(principal)}**.`;
    } else {
      // loss scenario - in real mudarabah, investor bears financial loss (operator only loses effort)
      const lossRate = 0.05 + Math.random() * 0.15; // 5%-20% loss
      const loss = principal * lossRate;
      resultAmount = principal - loss;
      outcomeText = `📉 The venture faced a loss of ${fmt(loss)}. As per mudarabah principle, you (the capital provider) bear the financial loss. Returned: **${fmt(resultAmount)}**.`;
    }

    u.balance += resultAmount;
    u.investment = null;
    u.stats = u.stats || { purchases: 0, zakatPayments: 0, workCount: 0, mudarabahCount: 0, sedekahTotal: 0 };
    u.stats.mudarabahCount = (u.stats.mudarabahCount || 0) + 1;
    logTransaction(u, 'mudarabah-withdraw', resultAmount, 'Mudarabah investment withdrawn');
    const newAchievements = checkAchievements(u);
    saveDB(db);
    await checkRoleRewards(interaction.guild, db, interaction.user.id, u.balance);
    if (newAchievements.length) {
      outcomeText += `\n🏆 Achievement unlocked: ${newAchievements.map(a => `${a.emoji} **${a.name}**`).join(', ')}!`;
    }
    return interaction.reply({ embeds: [simpleEmbed(outcomeText)] });
  }
}

async function handleQard(interaction, db) {
  const sub = interaction.options.getSubcommand();

  if (sub === 'request') {
    const lenderUser = interaction.options.getUser('lender');
    const amount = interaction.options.getInteger('amount');

    if (lenderUser.id === interaction.user.id) {
      return interaction.reply({ embeds: [simpleEmbed('You cannot borrow from yourself.')], ephemeral: true });
    }

    const borrower = getUser(db, interaction.user.id);
    const lender = getUser(db, lenderUser.id);

    if (amount > lender.balance) {
      return interaction.reply({ embeds: [simpleEmbed(`<@${lenderUser.id}> doesn't have enough balance to lend that much.`)], ephemeral: true });
    }

    lender.balance -= amount;
    borrower.balance += amount;
    borrower.debts.push({ lender: lenderUser.id, amount, date: Date.now() });
    lender.loans.push({ borrower: interaction.user.id, amount, date: Date.now() });
    logTransaction(borrower, 'qard-borrowed', amount, `Borrowed from <@${lenderUser.id}>`);
    logTransaction(lender, 'qard-lent', -amount, `Lent to <@${interaction.user.id}>`);
    saveDB(db);
    await checkRoleRewards(interaction.guild, db, interaction.user.id, borrower.balance);

    return interaction.reply({ embeds: [simpleEmbed(`🤝 Qard Hasan: <@${interaction.user.id}> borrowed **${fmt(amount)}** from <@${lenderUser.id}>, interest-free. Repay the exact amount with \`/finance qard repay\`.`)] });
  }

  if (sub === 'repay') {
    const lenderUser = interaction.options.getUser('lender');
    const amount = interaction.options.getInteger('amount');

    const borrower = getUser(db, interaction.user.id);
    const lender = getUser(db, lenderUser.id);

    const debtIndex = borrower.debts.findIndex(d => d.lender === lenderUser.id);
    if (debtIndex === -1) {
      return interaction.reply({ embeds: [simpleEmbed(`You have no recorded debt to <@${lenderUser.id}>.`)], ephemeral: true });
    }

    const debt = borrower.debts[debtIndex];
    if (amount > borrower.balance) {
      return interaction.reply({ embeds: [simpleEmbed(`Insufficient balance. Your balance: ${fmt(borrower.balance)}.`)], ephemeral: true });
    }

    const payAmount = Math.min(amount, debt.amount);
    borrower.balance -= payAmount;
    lender.balance += payAmount;
    debt.amount -= payAmount;
    logTransaction(borrower, 'qard-repay', -payAmount, `Repaid <@${lenderUser.id}>`);
    logTransaction(lender, 'qard-received', payAmount, `Repayment from <@${interaction.user.id}>`);

    const loan = lender.loans.find(l => l.borrower === interaction.user.id);
    if (loan) loan.amount -= payAmount;

    if (debt.amount <= 0) {
      borrower.debts.splice(debtIndex, 1);
      const loanIndex = lender.loans.findIndex(l => l.borrower === interaction.user.id);
      if (loanIndex !== -1) lender.loans.splice(loanIndex, 1);
    }

    saveDB(db);
    await checkRoleRewards(interaction.guild, db, lenderUser.id, lender.balance);
    return interaction.reply({ embeds: [simpleEmbed(`✅ You repaid **${fmt(payAmount)}** to <@${lenderUser.id}>. ${debt.amount > 0 ? `Remaining debt: ${fmt(debt.amount)}.` : 'Debt fully settled, no interest charged.'}`)] });
  }

  if (sub === 'list') {
    const u = getUser(db, interaction.user.id);
    saveDB(db);
    const debtsText = u.debts.length
      ? u.debts.map(d => `• Owe <@${d.lender}>: ${fmt(d.amount)}`).join('\n')
      : 'None';
    const loansText = u.loans.length
      ? u.loans.map(l => `• <@${l.borrower}> owes you: ${fmt(l.amount)}`).join('\n')
      : 'None';

    const embed = new EmbedBuilder()
      .setColor(0x3498db)
      .setTitle('🤝 Qard Hasan — Your Ledger')
      .addFields(
        { name: 'You Owe', value: debtsText },
        { name: 'Owed To You', value: loansText },
      );
    return interaction.reply({ embeds: [embed] });
  }
}

async function handleWaqf(interaction, db) {
  const sub = interaction.options.getSubcommand();
  const waqf = getWaqf(db, CTX.guildId);

  if (sub === 'donate') {
    const amount = interaction.options.getInteger('amount');
    const u = getUser(db, interaction.user.id);

    if (amount > u.balance) {
      return interaction.reply({ embeds: [simpleEmbed(`⚠️ Insufficient balance. You need ${fmt(amount)}, you have ${fmt(u.balance)}.`, 0xe74c3c)], ephemeral: true });
    }

    u.balance -= amount;
    waqf.principal += amount;
    waqf.contributions[interaction.user.id] = (waqf.contributions[interaction.user.id] || 0) + amount;
    logTransaction(u, 'waqf-donate', -amount, 'Donated to the waqf endowment');
    saveDB(db);

    return interaction.reply({ embeds: [simpleEmbed(
      `🕌 JazakAllahu khairan! You donated **${fmt(amount)}** to this server's waqf.\n` +
      `This is now part of the **permanent endowment principal** — it will never be spent directly, only its yield (see \`/finance waqf status\`).`
    )] });
  }

  if (sub === 'status') {
    saveDB(db);

    const contributors = Object.entries(waqf.contributions)
      .sort((a, b) => b[1] - a[1])
      .slice(0, 5);
    const contributorsText = contributors.length
      ? contributors.map(([userId, total], i) => `**${i + 1}.** <@${userId}> — ${fmt(total)}`).join('\n')
      : 'No contributions yet — be the first with `/finance waqf donate`.';

    const embed = new EmbedBuilder()
      .setColor(0x1f7a5c)
      .setTitle('🕌 Waqf Endowment')
      .setDescription('A permanent community fund. The principal below is never spent — only its yield is, and only by an admin via `/admin waqf distribute`.')
      .addFields(
        { name: 'Principal (protected, permanent)', value: `**${fmt(waqf.principal)}**`, inline: true },
        { name: 'Distributable Yield', value: `**${fmt(waqf.growthPool)}**`, inline: true },
        { name: 'Top Contributors', value: contributorsText },
      )
      .setFooter({ text: CONFIG.BOT_NAME });

    return interaction.reply({ embeds: [embed] });
  }
}

async function handleAdminWaqfDistribute(interaction, db) {
  const waqf = getWaqf(db, CTX.guildId);
  const amount = interaction.options.getInteger('amount');
  const targetUser = interaction.options.getUser('user');
  const targetRole = interaction.options.getRole('role');

  if (!targetUser && !targetRole) {
    return interaction.reply({ embeds: [simpleEmbed('⚠️ Pick either a `user` or a `role` to distribute to (not neither).', 0xe74c3c)], ephemeral: true });
  }
  if (targetUser && targetRole) {
    return interaction.reply({ embeds: [simpleEmbed('⚠️ Pick only one: `user` OR `role`, not both.', 0xe74c3c)], ephemeral: true });
  }
  if (amount > waqf.growthPool) {
    return interaction.reply({ embeds: [simpleEmbed(`⚠️ Only ${fmt(waqf.growthPool)} of yield is available to distribute — the protected principal (${fmt(waqf.principal)}) can't be touched.`, 0xe74c3c)], ephemeral: true });
  }

  if (targetUser) {
    const recipient = getUser(db, targetUser.id);
    recipient.balance += amount;
    waqf.growthPool -= amount;
    logTransaction(recipient, 'waqf-distribute', amount, 'Waqf yield distribution');
    logAudit(db, CTX.guildId, interaction.user.id, 'waqf-distribute', `${fmt(amount)} to <@${targetUser.id}>`);
    saveDB(db);
    await checkRoleRewards(interaction.guild, db, targetUser.id, recipient.balance);
    return interaction.reply({ embeds: [simpleEmbed(`✅ Distributed **${fmt(amount)}** of waqf yield to <@${targetUser.id}>. Remaining yield pool: ${fmt(waqf.growthPool)}.`)] });
  }

  // Role distribution: split the amount evenly among every member currently holding the role.
  const members = await interaction.guild.members.fetch().catch(() => null);
  const recipients = members ? members.filter(m => m.roles.cache.has(targetRole.id) && !m.user.bot) : null;

  if (!recipients || recipients.size === 0) {
    return interaction.reply({ embeds: [simpleEmbed(`⚠️ No members currently hold **${targetRole.name}** (or I couldn't fetch the member list — check the Server Members Intent).`, 0xe74c3c)], ephemeral: true });
  }

  const share = Math.floor(amount / recipients.size);
  if (share < 1) {
    return interaction.reply({ embeds: [simpleEmbed(`⚠️ ${fmt(amount)} split across ${recipients.size} members with **${targetRole.name}** rounds down to 0 each. Distribute a larger amount.`, 0xe74c3c)], ephemeral: true });
  }

  let totalGiven = 0;
  for (const member of recipients.values()) {
    const recipient = getUser(db, member.id);
    recipient.balance += share;
    logTransaction(recipient, 'waqf-distribute', share, `Waqf yield distribution (role: ${targetRole.name})`);
    totalGiven += share;
    await checkRoleRewards(interaction.guild, db, member.id, recipient.balance);
  }
  waqf.growthPool -= totalGiven;
  logAudit(db, CTX.guildId, interaction.user.id, 'waqf-distribute', `${fmt(totalGiven)} split among ${recipients.size} members with role ${targetRole.name}`);
  saveDB(db);

  return interaction.reply({ embeds: [simpleEmbed(`✅ Distributed **${fmt(share)}** each to **${recipients.size}** members with **${targetRole.name}** (${fmt(totalGiven)} total). Remaining yield pool: ${fmt(waqf.growthPool)}.`)] });
}

// Builds the embed used for a single market, both in /marketsearch and
// inside /allserver-market's listing.
function generateItemId() {
  return `it_${Date.now().toString(36)}${Math.floor(Math.random() * 1296).toString(36)}`;
}

// Market items can be either a legacy plain string (old /addmarket listings,
// display-only, "contact the owner to purchase") or a rich item object added
// via /additem: { id, name, description, price, image, stock }. `stock` of
// null/undefined means unlimited.
function isRichItem(it) {
  return typeof it === 'object' && it !== null;
}

function findItemInMarket(market, itemName) {
  const needle = itemName.trim().toLowerCase();
  return market.items.find(it => isRichItem(it) && it.name.toLowerCase() === needle);
}

// Lightweight rating: just an average of stars, no stored review text.
function getMarketRating(market) {
  const stars = Object.values(market.ratings || {});
  if (!stars.length) return null;
  const avg = stars.reduce((a, b) => a + b, 0) / stars.length;
  return { avg, count: stars.length };
}

function buildMarketEmbed(market) {
  const lines = market.items.map((it, idx) => {
    if (isRichItem(it)) {
      const stockText = (it.stock === null || it.stock === undefined) ? 'unlimited' : (it.stock > 0 ? `${it.stock} left` : 'SOLD OUT');
      return `**${idx + 1}.** 🛒 ${it.name} — ${fmt(it.price)} (${stockText})`;
    }
    return `**${idx + 1}.** ${it}`;
  }).join('\n');

  const rating = getMarketRating(market);
  const ratingText = rating ? `${'⭐'.repeat(Math.round(rating.avg))} ${rating.avg.toFixed(1)} (${rating.count} rating${rating.count === 1 ? '' : 's'})` : 'No ratings yet';

  return new EmbedBuilder()
    .setColor(0xe67e22)
    .setTitle(`🏪 ${market.name}`)
    .setDescription(`Owned by <@${market.ownerId}>`)
    .addFields(
      { name: 'Items for Sale', value: lines || 'No items listed' },
      { name: 'Item Price (shared)', value: fmt(market.allItemPrice), inline: true },
      { name: 'Rating', value: ratingText, inline: true },
    )
    .setFooter({ text: 'Items with 🛒 can be bought directly with /market buy — others are legacy listings, contact the owner to purchase.' });
}

// Clean "search result" style card for a single rich item: big image, title,
// description below — mirrors the reference layout the user asked for.
function buildItemCardEmbed(market, item) {
  const stockText = (item.stock === null || item.stock === undefined) ? 'Unlimited' : (item.stock > 0 ? `${item.stock}` : 'Sold Out');
  const embed = new EmbedBuilder()
    .setColor(0x2ecc71)
    .setTitle(`🛒 ${item.name}`)
    .setDescription(item.description || '*No description provided.*')
    .addFields(
      { name: 'Price', value: fmt(item.price), inline: true },
      { name: 'Stock', value: stockText, inline: true },
      { name: 'Sold by', value: `<@${market.ownerId}>`, inline: true },
    )
    .setFooter({ text: `From market: ${market.name}` });
  if (item.image) embed.setImage(item.image);
  if (item.deliveryContent) {
    embed.addFields({ name: '🔒 Includes Private Content', value: 'Revealed only by DM to the buyer after purchase.' });
  }
  return embed;
}

function buildBuyButtonRow(buyerId, marketId, item, disabled = false) {
  const soldOut = item.stock !== null && item.stock !== undefined && item.stock <= 0;
  return new ActionRowBuilder().addComponents(
    new ButtonBuilder()
      .setCustomId(`buyitem:${buyerId}:${marketId}:${item.id}`)
      .setLabel(soldOut ? 'Sold Out' : `Buy for ${fmt(item.price)}`)
      .setEmoji('🛍️')
      .setStyle(soldOut ? ButtonStyle.Secondary : ButtonStyle.Success)
      .setDisabled(disabled || soldOut)
  );
}

async function handleAddMarket(interaction, db) {
  const name = interaction.options.getString('name').trim();
  const item1 = interaction.options.getString('item1').trim();
  const item2 = interaction.options.getString('item2')?.trim();
  const item3 = interaction.options.getString('item3')?.trim();
  const allItemPrice = interaction.options.getInteger('allitemprice');

  if (!name.length || name.length > 50) {
    return interaction.reply({ embeds: [simpleEmbed('Market name must be between 1 and 50 characters.')], ephemeral: true });
  }
  for (const [slotLabel, value] of [['item1', item1], ['item2', item2], ['item3', item3]]) {
    if (value && /https?:\/\/\S+/i.test(value)) {
      return interaction.reply({
        embeds: [simpleEmbed(`⚠️ **${slotLabel}** contains a link, but item names are always shown publicly (in the market listing and item card) — even before anyone buys. If this link is meant to be a reward/secret for buyers only, put it in **${slotLabel}content** instead (only DMed to the buyer after purchase).`)],
        ephemeral: true,
      });
    }
  }

  const markets = getGuildMarkets(db);

  if (findMarketByName(db, name)) {
    return interaction.reply({ embeds: [simpleEmbed(`A market named **${name}** already exists in this server. Please choose a different name.`)], ephemeral: true });
  }

  const ownedByUser = markets.filter(m => m.ownerId === interaction.user.id).length;
  if (ownedByUser >= CONFIG.MAX_MARKETS_PER_USER) {
    return interaction.reply({ embeds: [simpleEmbed(`You've reached the maximum of ${CONFIG.MAX_MARKETS_PER_USER} markets per member.`)], ephemeral: true });
  }

  // Each item slot becomes a real purchasable item — buyers get it added to their inventory
  // automatically and a DM with its private content (e.g. a link) the moment they buy it via
  // /market buy. That content is NEVER shown publicly (not in the market listing, not in the
  // pre-purchase item card) — only revealed by DM to the buyer after payment. A role or content
  // is optional per item; a bare name with neither is fine too.
  const slots = [
    { name: item1, deliveryContent: interaction.options.getString('item1content')?.trim() || null, role: interaction.options.getRole('item1role') },
    { name: item2, deliveryContent: interaction.options.getString('item2content')?.trim() || null, role: interaction.options.getRole('item2role') },
    { name: item3, deliveryContent: interaction.options.getString('item3content')?.trim() || null, role: interaction.options.getRole('item3role') },
  ].filter(slot => slot.name);

  const items = slots.map(slot => ({
    id: generateItemId(),
    name: slot.name,
    description: null,
    price: allItemPrice,
    image: null,
    stock: null,
    roleId: slot.role ? slot.role.id : null,
    deliveryContent: slot.deliveryContent,
  }));

  const market = {
    id: `${interaction.user.id}_${Date.now()}`,
    ownerId: interaction.user.id,
    name,
    items,
    allItemPrice,
    createdAt: Date.now(),
    ratings: {}, // { userId: stars } — one rating per user, kept lightweight (no review text)
  };
  markets.push(market);
  saveDB(db);
  logAudit(db, CTX.guildId, interaction.user.id, 'market-open', name);

  return interaction.reply({ embeds: [simpleEmbed(`✅ Your market is now open! Members can buy items directly with \`/market buy\` — they'll get it added to their inventory and a DM automatically.`), buildMarketEmbed(market)] });
}

async function handleRemoveMarket(interaction, db) {
  const name = interaction.options.getString('name').trim();
  const markets = getGuildMarkets(db);
  const idx = markets.findIndex(m => m.name.toLowerCase() === name.toLowerCase());

  if (idx === -1) {
    return interaction.reply({ embeds: [simpleEmbed(`No market named **${name}** was found.`)], ephemeral: true });
  }
  const market = markets[idx];
  const isOwner = market.ownerId === interaction.user.id;
  const isAdmin = interaction.memberPermissions?.has(PermissionFlagsBits.Administrator);
  if (!isOwner && !isAdmin) {
    return interaction.reply({ embeds: [simpleEmbed('Only the market owner or a server admin can remove this market.', 0xe74c3c)], ephemeral: true });
  }

  const token = createConfirmation(interaction.user.id, 'removemarket', { guildId: CTX.guildId, marketName: market.name });
  return interaction.reply({
    embeds: [simpleEmbed(`⚠️ Remove market **${market.name}** (${market.items.length} item(s))? This can't be undone.`, 0xe67e22)],
    components: [buildConfirmRow(token)],
    ephemeral: true,
  });
}

function executeRemoveMarket(db, guildId, marketName) {
  const markets = db.markets[guildId] || [];
  const idx = markets.findIndex(m => m.name.toLowerCase() === marketName.toLowerCase());
  if (idx === -1) return null;
  const [removed] = markets.splice(idx, 1);
  saveDB(db);
  return removed;
}

async function handleAllServerMarket(interaction, db) {
  const markets = getGuildMarkets(db);
  saveDB(db);

  if (!markets.length) {
    return interaction.reply({ embeds: [simpleEmbed('No markets have been opened in this server yet. Be the first with `/market open`!' )]});
  }

  const embed = new EmbedBuilder()
    .setColor(0xe67e22)
    .setTitle('🏬 All Server Markets')
    .setDescription(
      markets.slice(0, 25).map(m => `🏪 **${m.name}** — owned by <@${m.ownerId}> — ${m.items.length} item(s) @ ${fmt(m.allItemPrice)} each`).join('\n')
    )
    .setFooter({ text: `Use /market search [name] to view a market's items • ${markets.length} market(s) total` });

  return interaction.reply({ embeds: [embed] });
}

async function handleMarketSearch(interaction, db) {
  const name = interaction.options.getString('name').trim();
  const market = findMarketByName(db, name);
  saveDB(db);

  if (!market) {
    return interaction.reply({ embeds: [simpleEmbed(`No market named **${name}** was found. Use \`/market browse\` to see all open markets.`)], ephemeral: true });
  }

  return interaction.reply({ embeds: [buildMarketEmbed(market)] });
}

async function handleAddItem(interaction, db) {
  const marketName = interaction.options.getString('market').trim();
  const itemName = interaction.options.getString('name').trim();
  const price = interaction.options.getInteger('price');
  const description = interaction.options.getString('description')?.trim() || null;
  const image = interaction.options.getString('image')?.trim() || null;
  const stock = interaction.options.getInteger('stock');
  const role = interaction.options.getRole('role');
  const deliveryContent = interaction.options.getString('content')?.trim() || null;

  if (image && !/^https?:\/\//i.test(image)) {
    return interaction.reply({ embeds: [simpleEmbed('⚠️ The image must be a URL starting with `http://` or `https://`.')], ephemeral: true });
  }
  if (/https?:\/\/\S+/i.test(itemName)) {
    return interaction.reply({
      embeds: [simpleEmbed('⚠️ The item **name** contains a link, but names are always shown publicly (market listing, item card title) — even before anyone buys. If this link is meant to be a reward/secret for buyers only, put it in the **content** option instead.')],
      ephemeral: true,
    });
  }
  if (description && /https?:\/\/\S+/i.test(description)) {
    return interaction.reply({
      embeds: [simpleEmbed('⚠️ Your **description** contains a link, but `description` is shown publicly to everyone before purchase — including people who haven\'t paid. If this link is meant to be a reward/secret for buyers only, put it in the **content** option instead (only DMed to the buyer after purchase). Re-run the command with the link moved to `content`.')],
      ephemeral: true,
    });
  }

  const market = findMarketByName(db, marketName);
  if (!market) {
    return interaction.reply({ embeds: [simpleEmbed(`No market named **${marketName}** was found.`)], ephemeral: true });
  }
  const isOwner = market.ownerId === interaction.user.id;
  const isAdmin = interaction.memberPermissions?.has(PermissionFlagsBits.Administrator);
  if (!isOwner && !isAdmin) {
    return interaction.reply({ embeds: [simpleEmbed('Only the market owner or a server admin can add items to this market.')], ephemeral: true });
  }

  const richItemCount = market.items.filter(isRichItem).length;
  if (richItemCount >= CONFIG.MAX_ITEMS_PER_MARKET) {
    return interaction.reply({ embeds: [simpleEmbed(`This market already has the maximum of ${CONFIG.MAX_ITEMS_PER_MARKET} items.`)], ephemeral: true });
  }
  if (findItemInMarket(market, itemName)) {
    return interaction.reply({ embeds: [simpleEmbed(`**${itemName}** already exists in this market. Remove it first with \`/market removeitem\` to replace it.`)], ephemeral: true });
  }

  const item = {
    id: generateItemId(),
    name: itemName,
    description,
    price,
    image,
    stock: (stock === null || stock === undefined) ? null : stock,
    roleId: role ? role.id : null,
    deliveryContent,
  };
  market.items.push(item);
  saveDB(db);
  logAudit(db, CTX.guildId, interaction.user.id, 'additem', `${itemName} in ${market.name} (${fmt(price)})`);

  return interaction.reply({
    embeds: [
      simpleEmbed(`✅ **${itemName}** added to **${market.name}**! Members can now buy it with \`/market buy market:${market.name} item:${itemName}\`.${role ? ` Buyers will be able to toggle the **${role.name}** role on/off with \`/economy use\`.` : ''}${deliveryContent ? ' 🔒 The private content you set will only be revealed to a buyer by DM after purchase — never shown publicly.' : ''}`),
      buildItemCardEmbed(market, item),
    ],
  });
}

async function handleRemoveItem(interaction, db) {
  const marketName = interaction.options.getString('market').trim();
  const itemName = interaction.options.getString('item').trim();

  const market = findMarketByName(db, marketName);
  if (!market) {
    return interaction.reply({ embeds: [simpleEmbed(`No market named **${marketName}** was found.`)], ephemeral: true });
  }
  const isOwner = market.ownerId === interaction.user.id;
  const isAdmin = interaction.memberPermissions?.has(PermissionFlagsBits.Administrator);
  if (!isOwner && !isAdmin) {
    return interaction.reply({ embeds: [simpleEmbed('Only the market owner or a server admin can remove items from this market.')], ephemeral: true });
  }

  const idx = market.items.findIndex(it => isRichItem(it) && it.name.toLowerCase() === itemName.toLowerCase());
  if (idx === -1) {
    return interaction.reply({ embeds: [simpleEmbed(`No item named **${itemName}** was found in **${market.name}**.`)], ephemeral: true });
  }

  market.items.splice(idx, 1);
  saveDB(db);
  logAudit(db, CTX.guildId, interaction.user.id, 'removeitem', `${itemName} from ${market.name}`);
  return interaction.reply({ embeds: [simpleEmbed(`🗑️ **${itemName}** removed from **${market.name}**.`)] });
}

async function handleEditItem(interaction, db) {
  const marketName = interaction.options.getString('market').trim();
  const itemName = interaction.options.getString('item').trim();

  const market = findMarketByName(db, marketName);
  if (!market) {
    return interaction.reply({ embeds: [simpleEmbed(`No market named **${marketName}** was found.`)], ephemeral: true });
  }
  const isOwner = market.ownerId === interaction.user.id;
  const isAdmin = interaction.memberPermissions?.has(PermissionFlagsBits.Administrator);
  if (!isOwner && !isAdmin) {
    return interaction.reply({ embeds: [simpleEmbed('Only the market owner or a server admin can edit items in this market.')], ephemeral: true });
  }

  const item = findItemInMarket(market, itemName);
  if (!item) {
    return interaction.reply({ embeds: [simpleEmbed(`No item named **${itemName}** was found in **${market.name}**.`)], ephemeral: true });
  }

  const price = interaction.options.getInteger('price');
  const description = interaction.options.getString('description');
  const content = interaction.options.getString('content');
  const image = interaction.options.getString('image');
  const stock = interaction.options.getInteger('stock');
  const role = interaction.options.getRole('role');

  if (image !== null && image !== undefined && !/^https?:\/\//i.test(image)) {
    return interaction.reply({ embeds: [simpleEmbed('⚠️ The image must be a URL starting with `http://` or `https://`.')], ephemeral: true });
  }
  if (description && /https?:\/\/\S+/i.test(description)) {
    return interaction.reply({ embeds: [simpleEmbed('⚠️ **description** is public — a link here would be visible before purchase. Put it in **content** instead.')], ephemeral: true });
  }

  const changes = [];
  if (price !== null && price !== undefined) { item.price = price; changes.push(`price → ${fmt(price)}`); }
  if (description !== null && description !== undefined) { item.description = description.trim() || null; changes.push('description updated'); }
  if (content !== null && content !== undefined) { item.deliveryContent = content.trim() || null; changes.push('private content updated'); }
  if (image !== null && image !== undefined) { item.image = image.trim() || null; changes.push('image updated'); }
  if (stock !== null && stock !== undefined) { item.stock = stock; changes.push(`stock → ${stock}`); }
  if (role !== null && role !== undefined) { item.roleId = role.id; changes.push(`role → ${role.name}`); }

  if (!changes.length) {
    return interaction.reply({ embeds: [simpleEmbed('Nothing to update — provide at least one field to change.')], ephemeral: true });
  }

  saveDB(db);
  logAudit(db, CTX.guildId, interaction.user.id, 'edititem', `${item.name} in ${market.name}: ${changes.join(', ')}`);
  return interaction.reply({ embeds: [simpleEmbed(`✅ Updated **${item.name}**: ${changes.join(', ')}.`), buildItemCardEmbed(market, item)] });
}

async function handleRateMarket(interaction, db) {
  const marketName = interaction.options.getString('market').trim();
  const stars = interaction.options.getInteger('stars');
  const review = interaction.options.getString('review')?.trim() || null;

  const market = findMarketByName(db, marketName);
  if (!market) {
    return interaction.reply({ embeds: [simpleEmbed(`No market named **${marketName}** was found.`, 0xe74c3c)], ephemeral: true });
  }
  if (market.ownerId === interaction.user.id) {
    return interaction.reply({ embeds: [simpleEmbed("You can't rate your own market.", 0xe74c3c)], ephemeral: true });
  }
  const buyer = getUser(db, interaction.user.id);
  const hasBought = (buyer.inventory || []).some(it => it.market === market.name);
  if (!hasBought) {
    return interaction.reply({ embeds: [simpleEmbed(`You need to have bought something from **${market.name}** before rating it.`, 0xe74c3c)], ephemeral: true });
  }

  market.ratings = market.ratings || {};
  const isUpdate = market.ratings[interaction.user.id] !== undefined;
  market.ratings[interaction.user.id] = stars;
  saveDB(db);

  const rating = getMarketRating(market);
  return interaction.reply({
    embeds: [simpleEmbed(`⭐ ${isUpdate ? 'Updated your rating' : 'Rated'} **${market.name}** ${stars}/5${review ? `: "${review}"` : ''}. New average: ${rating.avg.toFixed(1)} (${rating.count} rating${rating.count === 1 ? '' : 's'}).`)],
  });
}

async function handleFindItem(interaction, db) {
  const query = interaction.options.getString('query').trim().toLowerCase();
  const markets = getGuildMarkets(db);
  const results = [];
  for (const market of markets) {
    for (const it of market.items) {
      if (isRichItem(it) && it.name.toLowerCase().includes(query)) {
        results.push({ market: market.name, item: it });
      }
    }
  }

  if (!results.length) {
    return interaction.reply({ embeds: [simpleEmbed(`No purchasable items matching "${query}" were found in any market.`, 0xe74c3c)], ephemeral: true });
  }

  const lines = results.slice(0, 15).map(r => {
    const stockText = (r.item.stock === null || r.item.stock === undefined) ? 'unlimited' : (r.item.stock > 0 ? `${r.item.stock} left` : 'SOLD OUT');
    return `🛒 **${r.item.name}** — ${fmt(r.item.price)} (${stockText}) — from **${r.market}**`;
  });
  const embed = new EmbedBuilder()
    .setColor(0x3498db)
    .setTitle(`🔎 Results for "${query}"`)
    .setDescription(lines.join('\n'))
    .setFooter({ text: `${results.length} match(es)${results.length > 15 ? ' • showing the first 15' : ''} • buy with /market buy` });
  return interaction.reply({ embeds: [embed] });
}

async function handleBuy(interaction, db) {
  const marketName = interaction.options.getString('market').trim();
  const itemName = interaction.options.getString('item').trim();

  const market = findMarketByName(db, marketName);
  if (!market) {
    return interaction.reply({ embeds: [simpleEmbed(`No market named **${marketName}** was found. Use \`/market browse\` to browse.`)], ephemeral: true });
  }
  const item = findItemInMarket(market, itemName);
  if (!item) {
    return interaction.reply({ embeds: [simpleEmbed(`No purchasable item named **${itemName}** was found in **${market.name}**.`)], ephemeral: true });
  }

  saveDB(db);
  const embed = buildItemCardEmbed(market, item);
  const row = buildBuyButtonRow(interaction.user.id, market.id, item);
  return interaction.reply({ embeds: [embed], components: [row] });
}

async function handleItemAutocomplete(interaction, db) {
  const focused = interaction.options.getFocused().toLowerCase();
  const marketName = interaction.options.getString('market');
  if (!marketName) return interaction.respond([]);

  const market = findMarketByName(db, marketName);
  if (!market) return interaction.respond([]);

  const matches = market.items
    .filter(isRichItem)
    .filter(it => it.name.toLowerCase().includes(focused))
    .slice(0, 25)
    .map(it => ({ name: `${it.name} — ${fmt(it.price)}`, value: it.name }));
  await interaction.respond(matches);
}

async function handleBuyItemClick(interaction, db, buyerId, marketId, itemId) {
  if (interaction.user.id !== buyerId) {
    return interaction.reply({ embeds: [simpleEmbed("This isn\'t your purchase — run `/market buy` yourself to buy this item.")], ephemeral: true });
  }

  const markets = getGuildMarkets(db);
  const market = markets.find(m => m.id === marketId);
  if (!market) {
    return interaction.update({ embeds: [simpleEmbed('⚠️ This market no longer exists.', 0xe74c3c)], components: [] });
  }
  const item = market.items.find(it => isRichItem(it) && it.id === itemId);
  if (!item) {
    return interaction.update({ embeds: [simpleEmbed('⚠️ This item no longer exists.', 0xe74c3c)], components: [] });
  }
  if (item.stock !== null && item.stock !== undefined && item.stock <= 0) {
    return interaction.update({ embeds: [buildItemCardEmbed(market, item)], components: [buildBuyButtonRow(buyerId, marketId, item, true)] });
  }
  if (market.ownerId === buyerId) {
    return interaction.reply({ embeds: [simpleEmbed("You can't buy your own item.")], ephemeral: true });
  }

  const buyer = getUser(db, buyerId);
  if (buyer.balance < item.price) {
    return interaction.reply({ embeds: [simpleEmbed(`⚠️ Insufficient balance. You need ${fmt(item.price)}, you have ${fmt(buyer.balance)}.`)], ephemeral: true });
  }

  const seller = getUser(db, market.ownerId);
  const tax = Math.round(item.price * CONFIG.MARKET_TAX_RATE);
  buyer.balance -= item.price;
  seller.balance += (item.price - tax);
  db.zakatPool = (db.zakatPool || 0) + tax;
  if (item.stock !== null && item.stock !== undefined) item.stock -= 1;

  buyer.stats = buyer.stats || { purchases: 0, zakatPayments: 0, workCount: 0, mudarabahCount: 0, sedekahTotal: 0 };
  buyer.stats.purchases = (buyer.stats.purchases || 0) + 1;
  logTransaction(buyer, 'purchase', -item.price, `Bought ${item.name} from ${market.name}`);
  logTransaction(seller, 'sale', item.price - tax, `Sold ${item.name} to <@${buyerId}>`);
  const newAchievements = checkAchievements(buyer);

  // Auto-deliver: the item goes straight into the buyer's inventory, no need to wait on the seller.
  buyer.inventory.push({
    name: item.name,
    description: item.description || null,
    image: item.image || null,
    price: item.price,
    market: market.name,
    sellerId: market.ownerId,
    purchasedAt: Date.now(),
    roleId: item.roleId || null,
    deliveryContent: item.deliveryContent || null,
  });
  saveDB(db);

  const soldOut = item.stock !== null && item.stock !== undefined && item.stock <= 0;
  const doneEmbed = buildItemCardEmbed(market, item);
  let completeText = `You bought **${item.name}** for ${fmt(item.price)} (${fmt(tax)} went to the community zakat pool). It has been added to your inventory automatically — check \`/economy inventory\`.${item.roleId ? ' Toggle its role on/off anytime with `/economy use`.' : ''}`;
  if (newAchievements.length) {
    completeText += `\n🏆 Achievement unlocked: ${newAchievements.map(a => `${a.emoji} **${a.name}**`).join(', ')}!`;
  }
  doneEmbed.setColor(0x2ecc71).addFields({ name: '✅ Purchase Complete', value: completeText });

  // DM the buyer a receipt (with the item's description) and notify the seller.
  // Wrapped in try/catch since a user's DMs may be closed — this must never block the purchase itself.
  try {
    const receiptEmbed = new EmbedBuilder()
      .setColor(0x2ecc71)
      .setTitle(`🧾 Purchase Receipt — ${item.name}`)
      .setDescription(item.description || '*No description provided.*')
      .addFields(
        { name: 'Market', value: market.name, inline: true },
        { name: 'Seller', value: `<@${market.ownerId}>`, inline: true },
        { name: 'Price Paid', value: fmt(item.price), inline: true },
      )
      .setFooter({ text: 'Delivered automatically — view it anytime with /economy inventory.' });
    if (item.deliveryContent) {
      receiptEmbed.addFields({ name: '🔓 Your Content', value: item.deliveryContent });
    }
    if (item.image) receiptEmbed.setThumbnail(item.image);
    await interaction.user.send({ embeds: [receiptEmbed] });
  } catch (err) {
    // Buyer likely has DMs disabled — ignore, the purchase already succeeded.
  }
  try {
    const sellerUser = await interaction.client.users.fetch(market.ownerId);
    const saleEmbed = new EmbedBuilder()
      .setColor(0x3498db)
      .setTitle(`💰 Item Sold — ${item.name}`)
      .setDescription(`<@${buyerId}> just bought **${item.name}** from your market **${market.name}**.`)
      .addFields(
        { name: 'Price', value: fmt(item.price), inline: true },
        { name: 'Remaining Stock', value: item.stock === null || item.stock === undefined ? 'Unlimited' : `${item.stock}`, inline: true },
      );
    await sellerUser.send({ embeds: [saleEmbed] });
  } catch (err) {
    // Seller likely has DMs disabled — ignore, the purchase already succeeded.
  }

  return interaction.update({ embeds: [doneEmbed], components: [buildBuyButtonRow(buyerId, marketId, item, true)] });
}

// ---------------------------------------------------------------------------
// AUCTIONS — time-limited, highest bid wins. Resolved automatically by
// resolveEndedAuctions(), called on the same periodic timer as the adzan/
// calendar checks (see near the bottom of the file).
// ---------------------------------------------------------------------------
async function handleAuctionStart(interaction, db) {
  const name = interaction.options.getString('name').trim();
  const startPrice = interaction.options.getInteger('startprice');
  const durationMin = interaction.options.getInteger('duration');
  const content = interaction.options.getString('content')?.trim() || null;

  if (/https?:\/\/\S+/i.test(name)) {
    return interaction.reply({ embeds: [simpleEmbed('⚠️ The auction **name** is always public — a link here would be visible to everyone. Put it in **content** instead (DMed only to the winner).')], ephemeral: true });
  }

  const auctions = getGuildAuctions(db);
  if (auctions.some(a => !a.resolved && a.name.toLowerCase() === name.toLowerCase())) {
    return interaction.reply({ embeds: [simpleEmbed(`⚠️ An ongoing auction named **${name}** already exists in this server. Please choose a different name.`, 0xe74c3c)], ephemeral: true });
  }
  const activeCount = auctions.filter(a => !a.resolved && a.sellerId === interaction.user.id).length;
  if (activeCount >= CONFIG.MAX_MARKETS_PER_USER) {
    return interaction.reply({ embeds: [simpleEmbed(`You already have ${activeCount} active auction(s) — please wait for one to end first.`)], ephemeral: true });
  }

  const auction = {
    id: `${interaction.user.id}_${Date.now()}`,
    sellerId: interaction.user.id,
    name,
    deliveryContent: content,
    startPrice,
    currentBid: startPrice,
    currentBidderId: null,
    endsAt: Date.now() + durationMin * 60 * 1000,
    resolved: false,
  };
  auctions.push(auction);
  saveDB(db);

  return interaction.reply({ embeds: [simpleEmbed(`🔨 Auction started for **${name}**! Starting bid: ${fmt(startPrice)}. Ends <t:${Math.floor(auction.endsAt / 1000)}:R>. Bid with \`/market auction bid auction:${name}\`.`)] });
}

async function handleAuctionBid(interaction, db) {
  const auctionName = interaction.options.getString('auction').trim();
  const amount = interaction.options.getInteger('amount');
  const auctions = getGuildAuctions(db);
  const auction = auctions.find(a => a.name.toLowerCase() === auctionName.toLowerCase() && !a.resolved);

  if (!auction) {
    return interaction.reply({ embeds: [simpleEmbed(`No ongoing auction named **${auctionName}** was found.`)], ephemeral: true });
  }
  if (auction.sellerId === interaction.user.id) {
    return interaction.reply({ embeds: [simpleEmbed("You can't bid on your own auction.")], ephemeral: true });
  }
  if (Date.now() >= auction.endsAt) {
    return interaction.reply({ embeds: [simpleEmbed('This auction has already ended and is being resolved.')], ephemeral: true });
  }
  const minBid = auction.currentBidderId ? auction.currentBid + 1 : auction.currentBid;
  if (amount < minBid) {
    return interaction.reply({ embeds: [simpleEmbed(`⚠️ Your bid must be at least ${fmt(minBid)}.`)], ephemeral: true });
  }
  const bidder = getUser(db, interaction.user.id);
  if (bidder.balance < amount) {
    return interaction.reply({ embeds: [simpleEmbed(`⚠️ Insufficient balance. You need ${fmt(amount)}, you have ${fmt(bidder.balance)}.`, 0xe74c3c)], ephemeral: true });
  }

  // Escrow: hold the new bidder's money right now, and refund whoever was
  // outbid, so the balance actually backing the current bid is always real —
  // not just "was enough at the moment they clicked".
  if (auction.currentBidderId) {
    const previousBidder = getUser(db, auction.currentBidderId);
    previousBidder.balance += auction.currentBid;
    logTransaction(previousBidder, 'auction-outbid', auction.currentBid, `Outbid on: ${auction.name}`);
    const prevUser = await interaction.client.users.fetch(auction.currentBidderId).catch(() => null);
    if (prevUser) {
      await prevUser.send({ embeds: [simpleEmbed(`🔨 You've been outbid on **${auction.name}** — the new bid is ${fmt(amount)}. Your ${fmt(auction.currentBid)} has been refunded.`)] }).catch(() => null);
    }
  }
  bidder.balance -= amount;
  logTransaction(bidder, 'auction-bid', -amount, `Bid on: ${auction.name}`);

  auction.currentBid = amount;
  auction.currentBidderId = interaction.user.id;
  saveDB(db);

  return interaction.reply({ embeds: [simpleEmbed(`✅ You're now the highest bidder on **${auction.name}** with ${fmt(amount)}! Ends <t:${Math.floor(auction.endsAt / 1000)}:R>.`)] });
}

async function handleAuctionList(interaction, db) {
  const auctions = getGuildAuctions(db).filter(a => !a.resolved);
  if (!auctions.length) {
    return interaction.reply({ embeds: [simpleEmbed('No ongoing auctions right now. Start one with `/market auction start`!')] });
  }
  const lines = auctions.map(a => {
    const bidText = a.currentBidderId ? `${fmt(a.currentBid)} by <@${a.currentBidderId}>` : `${fmt(a.currentBid)} (no bids yet)`;
    return `🔨 **${a.name}** — ${bidText} — ends <t:${Math.floor(a.endsAt / 1000)}:R> — by <@${a.sellerId}>`;
  });
  const embed = new EmbedBuilder()
    .setColor(0xe67e22)
    .setTitle('🔨 Ongoing Auctions')
    .setDescription(lines.join('\n'));
  return interaction.reply({ embeds: [embed] });
}

async function handleAuctionCancel(interaction, db) {
  const auctionName = interaction.options.getString('auction').trim();
  const auctions = getGuildAuctions(db);
  const auction = auctions.find(a => a.name.toLowerCase() === auctionName.toLowerCase() && !a.resolved);
  if (!auction) {
    return interaction.reply({ embeds: [simpleEmbed(`No ongoing auction named **${auctionName}** was found.`, 0xe74c3c)], ephemeral: true });
  }

  const bidText = auction.currentBidderId ? ` The current bid of ${fmt(auction.currentBid)} will be refunded to <@${auction.currentBidderId}>.` : '';
  const token = createConfirmation(interaction.user.id, 'auctioncancel', { guildId: CTX.guildId, auctionName: auction.name });
  return interaction.reply({
    embeds: [simpleEmbed(`⚠️ Cancel auction **${auction.name}**?${bidText} This can't be undone.`, 0xe67e22)],
    components: [buildConfirmRow(token)],
    ephemeral: true,
  });
}

async function executeAuctionCancel(client, db, guildId, auctionName) {
  const auctions = db.auctions[guildId] || [];
  const auction = auctions.find(a => a.name.toLowerCase() === auctionName.toLowerCase() && !a.resolved);
  if (!auction) return null;
  auction.resolved = true;

  if (auction.currentBidderId) {
    const bidder = getUser(db, auction.currentBidderId);
    bidder.balance += auction.currentBid;
    logTransaction(bidder, 'auction-refund', auction.currentBid, `Auction cancelled: ${auction.name}`);
    const bidderUser = await client.users.fetch(auction.currentBidderId).catch(() => null);
    if (bidderUser) {
      await bidderUser.send({ embeds: [simpleEmbed(`🔨 The auction **${auction.name}** was cancelled by an admin. Your bid of ${fmt(auction.currentBid)} has been refunded.`)] }).catch(() => null);
    }
  }
  saveDB(db);
  return auction;
}

async function handleAuctionAutocomplete(interaction, db) {
  const focused = interaction.options.getFocused().toLowerCase();
  const auctions = getGuildAuctions(db).filter(a => !a.resolved && a.name.toLowerCase().includes(focused));
  await interaction.respond(auctions.slice(0, 25).map(a => ({ name: `${a.name} — current: ${fmt(a.currentBid)}`, value: a.name })));
}

// Called periodically (see the setInterval near client.login below). Finalizes
// any auction whose timer has passed: charges the winner, pays the seller
// (minus the same market tax as regular purchases), delivers the item into the
// winner's inventory, and DMs both sides. If nobody bid, it just closes with
// no charge. Wrapped so one guild's error never blocks another's.
async function resolveEndedAuctions(client, db) {
  let changed = false;
  for (const guildId of Object.keys(db.auctions || {})) {
    const auctions = db.auctions[guildId];
    for (const auction of auctions) {
      if (auction.resolved || Date.now() < auction.endsAt) continue;
      auction.resolved = true;
      changed = true;
      try {
        if (!auction.currentBidderId) {
          // No bids — nothing to charge, just notify the seller.
          const sellerUser = await client.users.fetch(auction.sellerId).catch(() => null);
          if (sellerUser) await sellerUser.send({ embeds: [simpleEmbed(`🔨 Your auction **${auction.name}** ended with no bids.`)] }).catch(() => null);
          continue;
        }
        const winner = getUser(db, auction.currentBidderId);
        const seller = getUser(db, auction.sellerId);
        const tax = Math.round(auction.currentBid * CONFIG.MARKET_TAX_RATE);
        // The winning bid was already deducted (escrowed) from the winner's
        // balance at bid time — don't deduct it again here, just pay the seller.
        seller.balance += (auction.currentBid - tax);
        db.zakatPool = (db.zakatPool || 0) + tax;
        winner.stats = winner.stats || { purchases: 0, zakatPayments: 0, workCount: 0, mudarabahCount: 0, sedekahTotal: 0 };
        winner.stats.purchases = (winner.stats.purchases || 0) + 1;
        winner.inventory.push({
          name: auction.name,
          description: null,
          image: null,
          price: auction.currentBid,
          market: 'Auction',
          sellerId: auction.sellerId,
          purchasedAt: Date.now(),
          roleId: null,
          deliveryContent: auction.deliveryContent,
        });
        logTransaction(winner, 'auction-won', 0, `Won auction: ${auction.name} (already paid at bid time)`);
        logTransaction(seller, 'auction-sale', auction.currentBid - tax, `Auction sold: ${auction.name}`);
        checkAchievements(winner);

        const winnerUser = await client.users.fetch(auction.currentBidderId).catch(() => null);
        if (winnerUser) {
          const embed = new EmbedBuilder().setColor(0x2ecc71).setTitle(`🔨 You won: ${auction.name}`).setDescription(`You paid ${fmt(auction.currentBid)}. Check \`/economy inventory\`.`);
          if (auction.deliveryContent) embed.addFields({ name: '🔓 Your Content', value: auction.deliveryContent });
          await winnerUser.send({ embeds: [embed] }).catch(() => null);
        }
        const sellerUser = await client.users.fetch(auction.sellerId).catch(() => null);
        if (sellerUser) await sellerUser.send({ embeds: [simpleEmbed(`🔨 Your auction **${auction.name}** sold for ${fmt(auction.currentBid)} (${fmt(tax)} went to the community zakat pool).`)] }).catch(() => null);
      } catch (err) {
        console.error('Auction resolution error:', err);
      }
    }
  }
  if (changed) saveDB(db);
}

async function handleOwnMarketAutocomplete(interaction, db) {
  const focused = interaction.options.getFocused().toLowerCase();
  const markets = getGuildMarkets(db);
  const isAdmin = interaction.memberPermissions?.has(PermissionFlagsBits.Administrator);
  const matches = markets
    .filter(m => (m.ownerId === interaction.user.id || isAdmin) && m.name.toLowerCase().includes(focused))
    .slice(0, 25)
    .map(m => ({ name: m.name, value: m.name }));
  await interaction.respond(matches);
}

async function handleAnyMarketAutocomplete(interaction, db) {
  const focused = interaction.options.getFocused().toLowerCase();
  const markets = getGuildMarkets(db);
  const matches = markets
    .filter(m => m.name.toLowerCase().includes(focused))
    .slice(0, 25)
    .map(m => ({ name: m.name, value: m.name }));
  await interaction.respond(matches);
}

async function handleInventory(interaction, db) {
  const targetUser = interaction.options.getUser('user') || interaction.user;
  const buyer = getUser(db, targetUser.id);
  const items = buyer.inventory || [];

  if (!items.length) {
    return interaction.reply({
      embeds: [simpleEmbed(targetUser.id === interaction.user.id
        ? "Your inventory is empty. Buy something with `/market buy`!"
        : `${targetUser.username}'s inventory is empty.`)],
      ephemeral: targetUser.id === interaction.user.id,
    });
  }

  const lines = items.slice(-25).reverse().map((it, idx) => {
    const desc = it.description ? ` — ${it.description}` : '';
    let roleTag = '';
    if (it.roleId) {
      const isEquipped = (buyer.equippedRoles || []).includes(it.roleId);
      roleTag = isEquipped ? ' 🟢 *Equipped*' : ' ⚪ *Not equipped — use `/economy use`*';
    }
    const contentTag = it.deliveryContent ? ' 🔒 *Has private content — check your DMs*' : '';
    return `**${idx + 1}. ${it.name}**${roleTag}${contentTag}${desc}\n*Bought from ${it.market} for ${fmt(it.price)}*`;
  });

  const embed = new EmbedBuilder()
    .setColor(0x9b59b6)
    .setTitle(`🎒 ${targetUser.id === interaction.user.id ? 'Your' : `${targetUser.username}'s`} Inventory`)
    .setDescription(lines.join('\n\n'))
    .setFooter({ text: `${items.length} item(s) total${items.length > 25 ? ' • showing the 25 most recent' : ''}` });

  await interaction.reply({ embeds: [embed], ephemeral: targetUser.id === interaction.user.id });
}

async function handleUseItem(interaction, db) {
  const itemName = interaction.options.getString('item').trim();
  const buyer = getUser(db, interaction.user.id);
  const owned = (buyer.inventory || []).find(it => it.name.toLowerCase() === itemName.toLowerCase() && it.roleId);

  if (!owned) {
    return interaction.reply({ embeds: [simpleEmbed(`You don't own an item named **${itemName}** that grants a role. Check \`/economy inventory\` for what you have.`)], ephemeral: true });
  }

  const guild = interaction.guild;
  const member = await guild.members.fetch(interaction.user.id).catch(() => null);
  if (!member) {
    return interaction.reply({ embeds: [simpleEmbed('⚠️ Could not find your member data in this server. Try again in a moment.')], ephemeral: true });
  }
  const role = guild.roles.cache.get(owned.roleId);
  if (!role) {
    return interaction.reply({ embeds: [simpleEmbed('⚠️ The role tied to this item no longer exists on this server.')], ephemeral: true });
  }

  buyer.equippedRoles = buyer.equippedRoles || [];
  const isEquipped = buyer.equippedRoles.includes(owned.roleId);

  if (isEquipped) {
    await member.roles.remove(owned.roleId).catch(() => null);
    buyer.equippedRoles = buyer.equippedRoles.filter(id => id !== owned.roleId);
    saveDB(db);
    return interaction.reply({ embeds: [simpleEmbed(`🔴 **${owned.name}** unequipped — the **${role.name}** role has been removed.`)], ephemeral: true });
  } else {
    await member.roles.add(owned.roleId).catch(() => null);
    if (!member.roles.cache.has(owned.roleId)) {
      return interaction.reply({ embeds: [simpleEmbed(`⚠️ Couldn't grant the **${role.name}** role — the bot may be missing **Manage Roles** permission or its role is positioned below **${role.name}**.`)], ephemeral: true });
    }
    buyer.equippedRoles.push(owned.roleId);
    saveDB(db);
    return interaction.reply({ embeds: [simpleEmbed(`🟢 **${owned.name}** equipped — you now have the **${role.name}** role!`)], ephemeral: true });
  }
}

async function handleUseItemAutocomplete(interaction, db) {
  const focused = interaction.options.getFocused().toLowerCase();
  const buyer = getUser(db, interaction.user.id);
  const seen = new Set();
  const matches = (buyer.inventory || [])
    .filter(it => it.roleId && it.name.toLowerCase().includes(focused))
    .filter(it => (seen.has(it.name) ? false : (seen.add(it.name), true)))
    .slice(0, 25)
    .map(it => ({ name: it.name, value: it.name }));
  await interaction.respond(matches);
}

async function handleHistory(interaction, db) {
  const u = getUser(db, interaction.user.id);
  const txs = u.transactions || [];
  if (!txs.length) {
    return interaction.reply({ embeds: [simpleEmbed('You have no recorded transactions yet.')], ephemeral: true });
  }
  const lines = txs.slice(-10).reverse().map(t => {
    const sign = t.amount > 0 ? '+' : '';
    const when = `<t:${Math.floor(t.ts / 1000)}:R>`;
    return `${when} **${t.type}**: ${sign}${fmt(t.amount)}${t.note ? ` — ${t.note}` : ''}`;
  });
  const embed = new EmbedBuilder()
    .setColor(0x3498db)
    .setTitle('📜 Your Transaction History')
    .setDescription(lines.join('\n'))
    .setFooter({ text: `${txs.length} total stored • showing the 10 most recent` });
  return interaction.reply({ embeds: [embed], ephemeral: true });
}

async function handleAchievements(interaction, db) {
  const targetUser = interaction.options.getUser('user') || interaction.user;
  const u = getUser(db, targetUser.id);
  const unlocked = new Set(u.achievements || []);
  const lines = CONFIG.ACHIEVEMENTS.map(a => {
    const status = unlocked.has(a.id) ? '✅' : '🔒';
    return `${status} ${a.emoji} **${a.name}** — ${a.desc}`;
  });
  const embed = new EmbedBuilder()
    .setColor(0xf1c40f)
    .setTitle(`🏆 ${targetUser.id === interaction.user.id ? 'Your' : `${targetUser.username}'s`} Achievements`)
    .setDescription(lines.join('\n'))
    .setFooter({ text: `${unlocked.size}/${CONFIG.ACHIEVEMENTS.length} unlocked` });
  return interaction.reply({ embeds: [embed] });
}

async function handleInvite(interaction, db) {
  const s = db.settings[CTX.guildId] = db.settings[CTX.guildId] || {};
  s.referralCodes = s.referralCodes || {};
  const u = getUser(db, interaction.user.id);

  if (!u.referralCode) {
    let code;
    do {
      code = Math.random().toString(36).slice(2, 8).toUpperCase();
    } while (s.referralCodes[code]);
    u.referralCode = code;
    s.referralCodes[code] = interaction.user.id;
    saveDB(db);
  }

  return interaction.reply({
    embeds: [simpleEmbed(`🎟️ Your referral code is **${u.referralCode}**. Share it with a friend — when they redeem it with \`/economy redeem code:${u.referralCode}\`, you both get a bonus! You've referred **${u.referralCount || 0}** member(s) so far.`)],
    ephemeral: true,
  });
}

async function handleRedeem(interaction, db) {
  const code = interaction.options.getString('code').trim().toUpperCase();
  const s = db.settings[CTX.guildId] || {};
  const referrerId = (s.referralCodes || {})[code];
  const u = getUser(db, interaction.user.id);

  if (!referrerId) {
    return interaction.reply({ embeds: [simpleEmbed(`⚠️ No referral code named **${code}** was found in this server.`)], ephemeral: true });
  }
  if (referrerId === interaction.user.id) {
    return interaction.reply({ embeds: [simpleEmbed("You can't redeem your own referral code.")], ephemeral: true });
  }
  if (u.referredBy) {
    return interaction.reply({ embeds: [simpleEmbed('You have already redeemed a referral code before — this is a one-time bonus.')], ephemeral: true });
  }

  const referrer = getUser(db, referrerId);
  u.referredBy = referrerId;
  u.balance += CONFIG.REFERRAL_BONUS_REFEREE;
  referrer.balance += CONFIG.REFERRAL_BONUS_REFERRER;
  referrer.referralCount = (referrer.referralCount || 0) + 1;
  logTransaction(u, 'referral-bonus', CONFIG.REFERRAL_BONUS_REFEREE, `Redeemed code from <@${referrerId}>`);
  logTransaction(referrer, 'referral-reward', CONFIG.REFERRAL_BONUS_REFERRER, `<@${interaction.user.id}> redeemed your code`);
  saveDB(db);

  return interaction.reply({ embeds: [simpleEmbed(`🎉 Referral code redeemed! You received **${fmt(CONFIG.REFERRAL_BONUS_REFEREE)}**, and <@${referrerId}> received **${fmt(CONFIG.REFERRAL_BONUS_REFERRER)}** for referring you.`)] });
}

async function handleQuiz(interaction, db) {
  const u = getUser(db, interaction.user.id);
  const now = Date.now();
  const remaining = (u.lastQuiz || 0) + CONFIG.QUIZ_COOLDOWN_MS - now;
  if (remaining > 0) {
    const mins = Math.ceil(remaining / 60000);
    return interaction.reply({ embeds: [simpleEmbed(`⏳ You've already answered a quiz recently. Try again in ~${mins}m.`)], ephemeral: true });
  }

  const quiz = CONFIG.QUIZZES[randInt(0, CONFIG.QUIZZES.length - 1)];
  const quizIndex = CONFIG.QUIZZES.indexOf(quiz);
  const row = new ActionRowBuilder().addComponents(
    quiz.options.map((opt, i) => new ButtonBuilder()
      .setCustomId(`quiz:${interaction.user.id}:${quizIndex}_${i}`)
      .setLabel(opt)
      .setStyle(ButtonStyle.Secondary)),
  );

  const embed = new EmbedBuilder()
    .setColor(0x9b59b6)
    .setTitle('📖 Quick Quiz')
    .setDescription(quiz.q)
    .setFooter({ text: `Correct answer earns ${fmt(CONFIG.QUIZ_REWARD)}` });

  u.lastQuiz = now; // set on ask, not on answer, so re-triggering the command doesn't reset the cooldown
  saveDB(db);
  return interaction.reply({ embeds: [embed], components: [row] });
}

async function handleQuizAnswer(interaction, db, ownerId, packedIdx) {
  if (interaction.user.id !== ownerId) {
    return interaction.reply({ embeds: [simpleEmbed("This isn't your quiz — run `/economy quiz` yourself.")], ephemeral: true });
  }
  const [quizIndexStr, choiceIdxStr] = packedIdx.split('_');
  const quiz = CONFIG.QUIZZES[Number(quizIndexStr)];
  const choiceIdx = Number(choiceIdxStr);
  if (!quiz) {
    return interaction.update({ embeds: [simpleEmbed('⚠️ This quiz has expired.', 0xe74c3c)], components: [] });
  }

  const u = getUser(db, interaction.user.id);
  const correct = choiceIdx === quiz.correct;
  if (correct) {
    u.balance += CONFIG.QUIZ_REWARD;
    logTransaction(u, 'quiz', CONFIG.QUIZ_REWARD, 'Correct quiz answer');
    saveDB(db);
    await checkRoleRewards(interaction.guild, db, interaction.user.id, u.balance);
  } else {
    saveDB(db);
  }

  const embed = new EmbedBuilder()
    .setColor(correct ? 0x2ecc71 : 0xe74c3c)
    .setTitle('📖 Quick Quiz')
    .setDescription(`${quiz.q}\n\n${correct ? `✅ Correct! You earned **${fmt(CONFIG.QUIZ_REWARD)}**.` : `❌ Not quite. The correct answer was **${quiz.options[quiz.correct]}**.`}`);
  return interaction.update({ embeds: [embed], components: [] });
}

async function handleClaimGiftCode(interaction, db) {
  const code = interaction.options.getString('code').trim().toUpperCase();
  const codes = getGiftCodes(db, CTX.guildId);
  const entry = codes[code];

  if (!entry || entry.expiresAt <= Date.now()) {
    return interaction.reply({ embeds: [simpleEmbed(`⚠️ No active gift code named **${code}** was found. It may have expired.`, 0xe74c3c)], ephemeral: true });
  }
  if (entry.usedBy.includes(interaction.user.id)) {
    return interaction.reply({ embeds: [simpleEmbed(`You've already redeemed **${code}**.`, 0xe74c3c)], ephemeral: true });
  }

  entry.usedBy.push(interaction.user.id);
  const u = getUser(db, interaction.user.id);
  const rewardParts = [];

  if (entry.money) {
    u.balance += entry.money;
    logTransaction(u, 'giftcode', entry.money, `Redeemed code: ${code}`);
    rewardParts.push(fmt(entry.money));
  }
  if (entry.roleId) {
    const member = await interaction.guild.members.fetch(interaction.user.id).catch(() => null);
    if (member) {
      await member.roles.add(entry.roleId).catch(() => null);
      if (member.roles.cache.has(entry.roleId)) {
        rewardParts.push(`the <@&${entry.roleId}> role`);
      } else {
        rewardParts.push(`⚠️ the <@&${entry.roleId}> role (grant failed — check the bot's role position/permissions)`);
      }
    }
  }
  if (entry.prize) {
    rewardParts.push(`"${entry.prize}"`);
  }

  const newAchievements = checkAchievements(u);
  saveDB(db);
  if (entry.money) await checkRoleRewards(interaction.guild, db, interaction.user.id, u.balance);

  let replyText = `🌙 Alhamdulillah! You redeemed **${code}** and received: ${rewardParts.join(', ')}.`;
  if (newAchievements.length) {
    replyText += `\n🏆 Achievement unlocked: ${newAchievements.map(a => `${a.emoji} **${a.name}**`).join(', ')}!`;
  }
  return interaction.reply({ embeds: [simpleEmbed(replyText)] });
}

async function handleLeaderboard(interaction, db) {
  const prefix = `${CTX.guildId}:`;
  const sorted = Object.entries(db.users)
    .filter(([key]) => key.startsWith(prefix))
    .sort((a, b) => b[1].balance - a[1].balance)
    .slice(0, 10);

  if (!sorted.length) return interaction.reply({ embeds: [simpleEmbed('No users yet.')] });

  const lines = sorted.map(([key, data], idx) => {
    const userId = key.slice(prefix.length);
    return `**${idx + 1}.** <@${userId}> — ${fmt(data.balance)}`;
  });

  const embed = new EmbedBuilder()
    .setColor(0x9b59b6)
    .setTitle('🏆 Richest Users')
    .setDescription(lines.join('\n'));

  await interaction.reply({ embeds: [embed] });
}

async function handleAbout(interaction, db) {
  const prefix = `${CTX.guildId}:`;
  const userCount = Object.keys(db.users).filter(k => k.startsWith(prefix)).length;
  const customCount = (db.customProfessions[CTX.guildId] || []).length;
  const marketCount = (db.markets[CTX.guildId] || []).length;
  const rewardCount = ((db.settings[CTX.guildId] || {}).roleRewards || []).length;
  const embed = new EmbedBuilder()
    .setColor(0x2ecc71)
    .setTitle(`🕌 ${CONFIG.BOT_NAME}`)
    .setDescription('A Discord economy bot built on Islamic finance principles — no riba, no maysir. Each server has its own independent economy.')
    .addFields(
      { name: 'Version', value: CONFIG.VERSION, inline: true },
      { name: 'Registered Users (this server)', value: `${userCount}`, inline: true },
      { name: 'Currency', value: `${getCurrencyName()} (${getCurrencySymbol()})`, inline: true },
      { name: 'Custom Professions (this server)', value: `${customCount}`, inline: true },
      { name: 'Open Markets (this server)', value: `${marketCount}`, inline: true },
      { name: 'Role Rewards (this server)', value: `${rewardCount}`, inline: true },
      { name: 'Features', value: 'Zakat • Sedekah • Mudarabah • Qard Hasan • Player-Driven Halal Market • Professions • Custom Professions • Profile Cards • Role Rewards • Data Backup' },
    )
    .setFooter({ text: `${CONFIG.BOT_NAME} ${CONFIG.VERSION}` });
  await interaction.reply({ embeds: [embed] });
}

async function handleTos(interaction, db) {
  const embed = new EmbedBuilder()
    .setColor(0x3498db)
    .setTitle(`📜 Terms of Service (the fun kind) — ${CONFIG.BOT_NAME}`)
    .setDescription(
      `**1. It's fake money, habibi.** ${getCurrencyName()} is 100% pretend. You can't buy a Lamborghini with it, you can't pay your Wi-Fi bill with it, and no, you can't cash it out for real Rupiah no matter how sweetly you ask.\n\n` +
      `**2. This is a game, not a fatwa.** Zakat, sedekah, mudarabah, qard hasan — all fun simulations to vibe with Islamic finance concepts. Doing \`/finance zakat pay\` does not count toward your actual zakat. Please consult an actual scholar for that, not a chatbot economy.\n\n` +
      `**3. "As is," like a mystery box from a garage sale.** Balances, items, and gift codes might get poked, fixed, or nuked by admins if something's buggy or someone's being sneaky. No warranty, no refunds, no crying (okay, a little crying is allowed).\n\n` +
      `**4. Admins are basically the sultan here.** They can mint gift codes, hand out free cash, undo shady purchases, and boot chaos from the market. What they say, goes. Don't @ the bot about it, @ them.\n\n` +
      `**5. Market stalls are BYO-responsibility.** Members set up their own shops and write their own item descriptions — the bot just runs the cash register. If someone's selling questionable vibes, that's on them, not on the bot developer.\n\n` +
      `**6. Don't be That Guy.** Exploiting bugs, spamming buttons like it's a rhythm game, or gaming the referral/gift code system for infinite money will get your balance quietly "corrected" by an admin. Play nice, earn it the halal way.`
    )
    .setFooter({ text: `${CONFIG.BOT_NAME} ${CONFIG.VERSION} — by using the economy features, you agree to these (mostly serious) terms.` });
  await interaction.reply({ embeds: [embed], ephemeral: true });
}

async function handleSetCurrencyEmoji(interaction, db) {
  const input = interaction.options.getString('emoji').trim();

  // Case 1: a custom server emoji, e.g. <:coin:123456789012345678> or <a:coin:...> (animated)
  const customMatch = input.match(/^<a?:\w+:(\d+)>$/);
  if (customMatch) {
    const emojiId = customMatch[1];
    const guildEmoji = interaction.guild?.emojis.cache.get(emojiId);
    if (!guildEmoji) {
      return interaction.reply({
        embeds: [simpleEmbed("⚠️ I couldn't find that custom emoji in this server. Pick one from this server's emoji picker, or type a regular emoji from your keyboard instead.")],
        ephemeral: true,
      });
    }
  } else {
    // Case 2: assume it's a standard unicode emoji typed from a phone/desktop keyboard.
    // Loose sanity check: reject plain text/letters/numbers so people don't accidentally
    // set the symbol to something like "money" instead of an actual emoji.
    const looksLikePlainText = /^[a-zA-Z0-9\s]+$/.test(input);
    if (looksLikePlainText || input.length > 16) {
      return interaction.reply({
        embeds: [simpleEmbed("⚠️ That doesn't look like a valid emoji. Type an emoji from your keyboard (e.g. 💰), or pick a custom emoji from this server.")],
        ephemeral: true,
      });
    }
  }

  db.settings[CTX.guildId] = db.settings[CTX.guildId] || {};
  db.settings[CTX.guildId].currencyEmoji = input;
  saveDB(db);

  return interaction.reply({ embeds: [simpleEmbed(`✅ Currency symbol for **this server** updated to ${input}! Example: **${fmt(1000)}**.\nOther servers using this bot keep their own currency symbol.`)] });
}

async function handleSetCurrencyName(interaction, db) {
  const input = interaction.options.getString('name').trim();

  if (!input.length || input.length > 30) {
    return interaction.reply({
      embeds: [simpleEmbed('⚠️ Currency name must be between 1 and 30 characters.', 0xe74c3c)],
      ephemeral: true,
    });
  }
  if (/https?:\/\/\S+/i.test(input)) {
    return interaction.reply({
      embeds: [simpleEmbed('⚠️ Currency name can\'t contain a link.', 0xe74c3c)],
      ephemeral: true,
    });
  }

  db.settings[CTX.guildId] = db.settings[CTX.guildId] || {};
  db.settings[CTX.guildId].currencyName = input;
  saveDB(db);

  return interaction.reply({ embeds: [simpleEmbed(`✅ Currency name for **this server** updated to **${input}**! Example: **${fmt(1000)}**.\nOther servers using this bot keep their own currency name.`)] });
}
async function handleProfile(interaction, db) {
  const target = interaction.options.getUser('user') || interaction.user;
  const u = getUser(db, target.id);
  saveDB(db);

  const { level, badge, next } = getLevelInfo(u.balance);
  const prof = u.profession ? getProfession(u.profession) : null;
  const professionText = prof ? `${prof.emoji} ${prof.name}` : 'None chosen yet';
  const nextText = next ? `${fmt(next.minBalance - u.balance)} more to reach **${next.badge}**` : 'Highest tier reached!';

  const embed = new EmbedBuilder()
    .setColor(0x9b59b6)
    .setTitle(`🪪 ${target.username}'s Profile`)
    .setThumbnail(target.displayAvatarURL())
    .addFields(
      { name: '💰 Balance', value: fmt(u.balance), inline: true },
      { name: '📊 Level', value: `${level}`, inline: true },
      { name: '🏅 Badge', value: badge, inline: true },
      { name: '👷 Profession', value: professionText, inline: true },
      { name: '📈 Progress to Next Badge', value: nextText },
    )
    .setFooter({ text: `${CONFIG.BOT_NAME} ${CONFIG.VERSION}` });

  await interaction.reply({ embeds: [embed] });
}

async function handleRoleReward(interaction, db) {
  const sub = interaction.options.getSubcommand();
  const rewards = getRoleRewards(db);

  if (sub === 'add') {
    const role = interaction.options.getRole('role');
    const amount = interaction.options.getInteger('amount');

    if (role.managed || role.id === interaction.guild.id) {
      return interaction.reply({ embeds: [simpleEmbed('That role can\'t be assigned by the bot (it\'s managed by an integration, or is @everyone).')], ephemeral: true });
    }
    const botMember = interaction.guild.members.me;
    if (botMember && role.position >= botMember.roles.highest.position) {
      return interaction.reply({ embeds: [simpleEmbed(`⚠️ I can't assign **${role.name}** because it's positioned above (or equal to) my highest role. Move my bot role above it in Server Settings → Roles.`)], ephemeral: true });
    }

    const existing = rewards.find(r => r.roleId === role.id);
    if (existing) existing.amount = amount;
    else rewards.push({ roleId: role.id, amount });
    rewards.sort((a, b) => a.amount - b.amount);
    saveDB(db);

    return interaction.reply({ embeds: [simpleEmbed(`✅ Members will now automatically receive **${role.name}** once their balance reaches **${fmt(amount)}**.\n⚠️ Make sure the bot has "Manage Roles" permission and this bot's role is positioned above **${role.name}**.`)] });
  }

  if (sub === 'remove') {
    const role = interaction.options.getRole('role');
    const idx = rewards.findIndex(r => r.roleId === role.id);
    if (idx === -1) {
      return interaction.reply({ embeds: [simpleEmbed(`**${role.name}** isn't configured as a role reward.`)], ephemeral: true });
    }
    rewards.splice(idx, 1);
    saveDB(db);
    return interaction.reply({ embeds: [simpleEmbed(`✅ Removed the role reward for **${role.name}**. (Members who already have it keep it — this only stops future auto-grants.)`)] });
  }

  if (sub === 'list') {
    saveDB(db);
    if (!rewards.length) {
      return interaction.reply({ embeds: [simpleEmbed('No role rewards configured yet. Add one with `/admin rolereward add`.')], ephemeral: true });
    }
    const lines = rewards.map(r => `• <@&${r.roleId}> — at **${fmt(r.amount)}**`).join('\n');
    const embed = new EmbedBuilder()
      .setColor(0x3498db)
      .setTitle('🎖️ Role Rewards')
      .setDescription(lines)
      .setFooter({ text: 'Requires the Server Members Intent to be enabled for the bot.' });
    return interaction.reply({ embeds: [embed] });
  }
}

async function handleBackup(interaction, db) {
  await interaction.deferReply({ ephemeral: true });

  const guildId = CTX.guildId;
  const prefix = `${guildId}:`;

  // Only export data scoped to THIS server — the underlying database.json is
  // shared across every server the bot is in, so a raw file export would leak
  // other servers' balances and settings. This filters to guildId only.
  const users = {};
  for (const [key, val] of Object.entries(db.users)) {
    if (key.startsWith(prefix)) users[key.slice(prefix.length)] = val;
  }

  const exportData = {
    exportedAt: new Date().toISOString(),
    botVersion: CONFIG.VERSION,
    guildId,
    users,
    customProfessions: db.customProfessions[guildId] || [],
    markets: db.markets[guildId] || [],
    settings: db.settings[guildId] || {},
  };

  const buffer = Buffer.from(JSON.stringify(exportData, null, 2), 'utf8');
  const attachment = new AttachmentBuilder(buffer, { name: `backup-${guildId}-${Date.now()}.json` });
  logAudit(db, guildId, interaction.user.id, 'backup', `${Object.keys(users).length} user record(s) exported`);
  saveDB(db);

  return interaction.editReply({
    embeds: [simpleEmbed(`📦 Backup exported for this server (${Object.keys(users).length} user record(s)). This file contains balances and settings for this server only.`)],
    files: [attachment],
  });
}

async function handleAudit(interaction, db) {
  const s = db.settings[CTX.guildId] || {};
  const log = s.auditLog || [];
  if (!log.length) {
    return interaction.reply({ embeds: [simpleEmbed('No audit log entries yet for this server.')], ephemeral: true });
  }
  const lines = log.slice(-10).reverse().map(e => {
    const when = `<t:${Math.floor(e.ts / 1000)}:R>`;
    return `${when} — <@${e.userId}> **${e.action}**${e.detail ? ` — ${e.detail}` : ''}`;
  });
  const embed = new EmbedBuilder()
    .setColor(0x95a5a6)
    .setTitle('📋 Recent Audit Log')
    .setDescription(lines.join('\n'))
    .setFooter({ text: `${log.length} total entries stored • showing the 10 most recent` });
  return interaction.reply({ embeds: [embed], ephemeral: true });
}

async function handleRefund(interaction, db) {
  const targetUser = interaction.options.getUser('user');
  const itemName = interaction.options.getString('item').trim();
  const buyer = getUser(db, targetUser.id);

  const idx = (buyer.inventory || []).map(it => it.name.toLowerCase()).lastIndexOf(itemName.toLowerCase());
  if (idx === -1) {
    return interaction.reply({ embeds: [simpleEmbed(`${targetUser.username} doesn't have an item named **${itemName}** in their inventory.`, 0xe74c3c)], ephemeral: true });
  }
  const entry = buyer.inventory[idx];

  const token = createConfirmation(interaction.user.id, 'refund', { guildId: CTX.guildId, targetUserId: targetUser.id, itemName: entry.name });
  return interaction.reply({
    embeds: [simpleEmbed(`⚠️ Refund **${entry.name}** (${fmt(entry.price)}) for ${targetUser}? This moves the money back from the seller and removes the item from their inventory.`, 0xe67e22)],
    components: [buildConfirmRow(token)],
    ephemeral: true,
  });
}

async function executeRefund(guild, db, guildId, targetUserId, itemName) {
  const buyer = getUser(db, targetUserId);
  const idx = (buyer.inventory || []).map(it => it.name.toLowerCase()).lastIndexOf(itemName.toLowerCase());
  if (idx === -1) return null;
  const entry = buyer.inventory[idx];
  const seller = getUser(db, entry.sellerId);

  buyer.balance += entry.price;
  seller.balance = Math.max(0, seller.balance - entry.price);
  buyer.stats.purchases = Math.max(0, (buyer.stats.purchases || 0) - 1);

  if (entry.roleId && (buyer.equippedRoles || []).includes(entry.roleId)) {
    const member = await guild.members.fetch(targetUserId).catch(() => null);
    if (member) await member.roles.remove(entry.roleId).catch(() => null);
    buyer.equippedRoles = buyer.equippedRoles.filter(id => id !== entry.roleId);
  }
  buyer.inventory.splice(idx, 1);

  logTransaction(buyer, 'refund', entry.price, `Refunded: ${entry.name}`);
  saveDB(db);
  return entry;
}

async function handleConfirmYes(interaction, db, token) {
  const pending = pendingConfirmations.get(token);
  pendingConfirmations.delete(token); // one-time use either way, even if something below fails

  if (!pending || Date.now() > pending.expiresAt) {
    return interaction.update({ embeds: [simpleEmbed('⚠️ This confirmation has expired. Please run the command again.', 0xe74c3c)], components: [] });
  }
  if (pending.ownerId !== interaction.user.id) {
    return interaction.reply({ embeds: [simpleEmbed("This isn't your confirmation to respond to.", 0xe74c3c)], ephemeral: true });
  }

  const { type, data } = pending;
  if (type === 'refund') {
    const entry = await executeRefund(interaction.guild, db, data.guildId, data.targetUserId, data.itemName);
    if (!entry) {
      return interaction.update({ embeds: [simpleEmbed('⚠️ That item is no longer in their inventory — nothing to refund.', 0xe74c3c)], components: [] });
    }
    logAudit(db, data.guildId, interaction.user.id, 'refund', `${entry.name} for <@${data.targetUserId}> (${fmt(entry.price)})`);
    return interaction.update({ embeds: [simpleEmbed(`✅ Refunded **${entry.name}** — ${fmt(entry.price)} moved back from <@${entry.sellerId}> to <@${data.targetUserId}>, item removed from their inventory.`)], components: [] });
  } else if (type === 'removemarket') {
    const removed = executeRemoveMarket(db, data.guildId, data.marketName);
    if (!removed) {
      return interaction.update({ embeds: [simpleEmbed('⚠️ That market no longer exists.', 0xe74c3c)], components: [] });
    }
    logAudit(db, data.guildId, interaction.user.id, 'market-remove', removed.name);
    return interaction.update({ embeds: [simpleEmbed(`🗑️ Market **${removed.name}** has been closed.`)], components: [] });
  } else if (type === 'auctioncancel') {
    const cancelled = await executeAuctionCancel(interaction.client, db, data.guildId, data.auctionName);
    if (!cancelled) {
      return interaction.update({ embeds: [simpleEmbed('⚠️ That auction no longer exists or already ended.', 0xe74c3c)], components: [] });
    }
    logAudit(db, data.guildId, interaction.user.id, 'auction-cancel', cancelled.name);
    return interaction.update({ embeds: [simpleEmbed(`🔨 Auction **${cancelled.name}** has been cancelled.`)], components: [] });
  }
}

async function handleConfirmNo(interaction, token) {
  pendingConfirmations.delete(token);
  return interaction.update({ embeds: [simpleEmbed('Cancelled — no changes were made.')], components: [] });
}

async function handleHijri(interaction, db) {
  saveDB(db);
  await interaction.reply({ embeds: [buildHijriEmbed()] });
}

async function handlePersian(interaction, db) {
  saveDB(db);
  await interaction.reply({ embeds: [buildPersianEmbed()] });
}

async function handleAutoCalendar(interaction, db) {
  const sub = interaction.options.getSubcommand();
  const ac = getAutoCalendarSettings(db, CTX.guildId);

  if (sub === 'channel') {
    const channel = interaction.options.getChannel('channel');
    const botMember = interaction.guild.members.me;
    const perms = channel.permissionsFor(botMember);
    if (!perms?.has(PermissionFlagsBits.SendMessages) || !perms?.has(PermissionFlagsBits.ViewChannel)) {
      return interaction.reply({ embeds: [simpleEmbed(`⚠️ I don't have permission to send messages in ${channel}. Grant "View Channel" and "Send Messages" there first.`)], ephemeral: true });
    }
    ac.channelId = channel.id;
    ac.enabled = true;
    saveDB(db);
    return interaction.reply({ embeds: [simpleEmbed(`✅ Daily Hijri calendar will now be posted in ${channel} every day at **18:00 WIB (Maghrib)**.`)] });
  }

  if (sub === 'disable') {
    ac.enabled = false;
    saveDB(db);
    return interaction.reply({ embeds: [simpleEmbed('✅ Daily auto-posting has been turned off. (The channel is remembered — use `/admin calendar channel` again to re-enable.)')] });
  }

  if (sub === 'status') {
    saveDB(db);
    if (!ac.channelId) {
      return interaction.reply({ embeds: [simpleEmbed('Auto-calendar hasn\'t been set up yet. Use `/admin calendar channel` to configure it.')], ephemeral: true });
    }
    return interaction.reply({ embeds: [simpleEmbed(`📅 Auto-calendar is **${ac.enabled ? 'enabled ✅' : 'disabled ⏸️'}** for <#${ac.channelId}>, posting daily at **18:00 WIB (Maghrib)**.`)] });
  }
}

async function handleAutoCalendarPersian(interaction, db) {
  const sub = interaction.options.getSubcommand();
  const acp = getAutoCalendarPersianSettings(db, CTX.guildId);

  if (sub === 'channel') {
    const channel = interaction.options.getChannel('channel');
    const botMember = interaction.guild.members.me;
    const perms = channel.permissionsFor(botMember);
    if (!perms?.has(PermissionFlagsBits.SendMessages) || !perms?.has(PermissionFlagsBits.ViewChannel)) {
      return interaction.reply({ embeds: [simpleEmbed(`⚠️ I don't have permission to send messages in ${channel}. Grant "View Channel" and "Send Messages" there first.`)], ephemeral: true });
    }
    acp.channelId = channel.id;
    acp.enabled = true;
    saveDB(db);
    return interaction.reply({ embeds: [simpleEmbed(`✅ Daily Persian calendar will now be posted in ${channel} every day at **18:00 WIB**. This is independent from the Hijri auto-calendar.`)] });
  }

  if (sub === 'disable') {
    acp.enabled = false;
    saveDB(db);
    return interaction.reply({ embeds: [simpleEmbed('✅ Daily Persian auto-posting has been turned off. (The channel is remembered — use `/admin persian-calendar channel` again to re-enable.)')] });
  }

  if (sub === 'status') {
    saveDB(db);
    if (!acp.channelId) {
      return interaction.reply({ embeds: [simpleEmbed('Persian auto-calendar hasn\'t been set up yet. Use `/admin persian-calendar channel` to configure it.')], ephemeral: true });
    }
    return interaction.reply({ embeds: [simpleEmbed(`📅 Persian auto-calendar is **${acp.enabled ? 'enabled ✅' : 'disabled ⏸️'}** for <#${acp.channelId}>, posting daily at **18:00 WIB**.`)] });
  }
}

async function handleErrorLogConfig(interaction, db) {
  const sub = interaction.options.getSubcommand();
  const guildId = interaction.guildId;
  const s = db.settings[guildId] = db.settings[guildId] || {};

  if (sub === 'channel') {
    const channel = interaction.options.getChannel('channel');
    s.errorLogChannelId = channel.id;
    saveDB(db);
    return interaction.reply({ embeds: [simpleEmbed(`✅ Bot errors in this server will now be reported to ${channel}.`)], ephemeral: true });
  } else if (sub === 'disable') {
    if (!s.errorLogChannelId) {
      return interaction.reply({ embeds: [simpleEmbed('Error reporting is already off for this server.')], ephemeral: true });
    }
    delete s.errorLogChannelId;
    saveDB(db);
    return interaction.reply({ embeds: [simpleEmbed('✅ Error reporting has been turned off for this server.')], ephemeral: true });
  }
}

async function handleAddMoney(interaction, db) {
  const targetUser = interaction.options.getUser('user');
  const amount = interaction.options.getInteger('amount');
  const target = getUser(db, targetUser.id);

  target.balance += amount;
  logTransaction(target, 'admin-grant', amount, `Granted by admin <@${interaction.user.id}>`);
  const newAchievements = checkAchievements(target);
  saveDB(db);
  await checkRoleRewards(interaction.guild, db, targetUser.id, target.balance);
  logAudit(db, CTX.guildId, interaction.user.id, 'addmoney', `${fmt(amount)} to ${targetUser.username}`);

  try {
    await targetUser.send({ embeds: [simpleEmbed(`🎁 An admin granted you **${fmt(amount)}**! Your new balance: ${fmt(target.balance)}.`)] });
  } catch (_) {
    // recipient's DMs may be closed — the grant already succeeded regardless
  }

  let replyText = `✅ Granted **${fmt(amount)}** to ${targetUser}. Their new balance: ${fmt(target.balance)}.`;
  if (newAchievements.length) {
    replyText += `\n🏆 They also unlocked: ${newAchievements.map(a => `${a.emoji} **${a.name}**`).join(', ')}!`;
  }
  return interaction.reply({ embeds: [simpleEmbed(replyText)], ephemeral: true });
}

// Gift codes live per-server at db.settings[guildId].giftCodes, keyed by the
// uppercased code string. Each holds an optional money reward, an optional
// role reward, and/or a free-text description of a non-balance prize — an
// admin decides which combination to set when creating it. usedBy tracks who
// has already redeemed it, since each code is one-time-per-member.
function getGiftCodes(db, guildId) {
  const s = db.settings[guildId] = db.settings[guildId] || {};
  if (!s.giftCodes) s.giftCodes = {};
  return s.giftCodes;
}

async function handleGiftCodeCreate(interaction, db) {
  const code = interaction.options.getString('code').trim().toUpperCase();
  const duration = interaction.options.getInteger('duration');
  const money = interaction.options.getInteger('money');
  const role = interaction.options.getRole('role');
  const prize = interaction.options.getString('prize')?.trim() || null;

  if (!money && !role && !prize) {
    return interaction.reply({ embeds: [simpleEmbed('⚠️ Set at least one reward: `money`, `role`, or `prize`.', 0xe74c3c)], ephemeral: true });
  }
  if (/https?:\/\/\S+/i.test(prize || '')) {
    return interaction.reply({ embeds: [simpleEmbed('⚠️ `prize` is shown publicly in `/admin giftcode list` — avoid putting links there.', 0xe74c3c)], ephemeral: true });
  }

  const codes = getGiftCodes(db, CTX.guildId);
  if (codes[code] && codes[code].expiresAt > Date.now()) {
    return interaction.reply({ embeds: [simpleEmbed(`⚠️ Code **${code}** is already active. Revoke it first with \`/admin giftcode revoke\` if you want to replace it.`, 0xe74c3c)], ephemeral: true });
  }

  codes[code] = {
    createdBy: interaction.user.id,
    money: money || 0,
    roleId: role ? role.id : null,
    prize,
    expiresAt: Date.now() + duration * 60 * 1000,
    usedBy: [],
    createdAt: Date.now(),
  };
  saveDB(db);
  logAudit(db, CTX.guildId, interaction.user.id, 'giftcode-create', code);

  const rewardParts = [];
  if (money) rewardParts.push(fmt(money));
  if (role) rewardParts.push(`the **${role.name}** role`);
  if (prize) rewardParts.push(`"${prize}"`);
  return interaction.reply({
    embeds: [simpleEmbed(`🌙 Gift code **${code}** created — rewards: ${rewardParts.join(', ')}. Valid for ${duration} minute(s). Members redeem it with \`/economy giftcode\`.`)],
    ephemeral: true,
  });
}

async function handleGiftCodeList(interaction, db) {
  const codes = getGiftCodes(db, CTX.guildId);
  const now = Date.now();
  const active = Object.entries(codes).filter(([, c]) => c.expiresAt > now);

  if (!active.length) {
    return interaction.reply({ embeds: [simpleEmbed('No active gift codes right now.')], ephemeral: true });
  }
  const lines = active.map(([code, c]) => {
    const rewardParts = [];
    if (c.money) rewardParts.push(fmt(c.money));
    if (c.roleId) rewardParts.push(`role <@&${c.roleId}>`);
    if (c.prize) rewardParts.push(`"${c.prize}"`);
    return `**${code}** — ${rewardParts.join(', ')} — expires <t:${Math.floor(c.expiresAt / 1000)}:R> — ${c.usedBy.length} redemption(s)`;
  });
  return interaction.reply({ embeds: [simpleEmbed(`🌙 **Active Gift Codes**\n\n${lines.join('\n')}`)], ephemeral: true });
}

async function handleGiftCodeRevoke(interaction, db) {
  const code = interaction.options.getString('code').trim().toUpperCase();
  const codes = getGiftCodes(db, CTX.guildId);
  if (!codes[code] || codes[code].expiresAt <= Date.now()) {
    return interaction.reply({ embeds: [simpleEmbed(`No active gift code named **${code}** was found.`, 0xe74c3c)], ephemeral: true });
  }
  delete codes[code];
  saveDB(db);
  logAudit(db, CTX.guildId, interaction.user.id, 'giftcode-revoke', code);
  return interaction.reply({ embeds: [simpleEmbed(`✅ Gift code **${code}** has been revoked.`)], ephemeral: true });
}

async function handleGiftCodeAutocomplete(interaction, db) {
  const focused = interaction.options.getFocused().toLowerCase();
  const codes = getGiftCodes(db, CTX.guildId);
  const now = Date.now();
  const matches = Object.keys(codes)
    .filter(c => codes[c].expiresAt > now && c.toLowerCase().includes(focused))
    .slice(0, 25)
    .map(c => ({ name: c, value: c }));
  await interaction.respond(matches);
}

async function handleSetAdzanChannel(interaction, db) {
  const channel = interaction.options.getChannel('channel');
  const locationInput = interaction.options.getString('location');

  const botMember = interaction.guild.members.me;
  const perms = channel.permissionsFor(botMember);
  if (!perms?.has(PermissionFlagsBits.SendMessages) || !perms?.has(PermissionFlagsBits.ViewChannel)) {
    return interaction.reply({ embeds: [simpleEmbed(`⚠️ I don't have permission to send messages in ${channel}. Grant "View Channel" and "Send Messages" there first.`)], ephemeral: true });
  }

  await interaction.deferReply();

  const parsed = parseLocationInput(locationInput);
  let fetched;
  try {
    fetched = await fetchPrayerTimes(parsed.geocodeQuery);
  } catch (err) {
    return interaction.editReply({ embeds: [simpleEmbed(`⚠️ Couldn't find prayer times for "${locationInput}". Double-check the spelling, e.g. \`Indonesia/Jakarta\` or \`Indonesia/Jakarta/DKI Jakarta\`. (${err.message})`, 0xe74c3c)] });
  }

  const entries = getAdzanChannels(db, CTX.guildId);
  const existing = entries.find(e => e.channelId === channel.id);
  const entry = existing || { channelId: channel.id };
  entry.raw = parsed.raw;
  entry.geocodeQuery = parsed.geocodeQuery;
  entry.timings = fetched.timings;
  entry.timezone = fetched.timezone;
  entry.timingsDateKey = getLocalDateKey(fetched.timezone);
  entry.postedFlags = {};
  if (!existing) entries.push(entry);

  saveDB(db);

  const preview = CONFIG.ADZAN_PRAYERS.map(p => `${p}: ${stripTimeSuffix(fetched.timings[p])}`).join(' • ');
  return interaction.editReply({ embeds: [simpleEmbed(`✅ Prayer time reminders enabled in ${channel} for **${parsed.raw}**.\n${preview} (timezone: ${fetched.timezone})`)] });
}

async function handleRemoveAdzanChannel(interaction, db) {
  const channel = interaction.options.getChannel('channel');
  const entries = getAdzanChannels(db, CTX.guildId);
  const idx = entries.findIndex(e => e.channelId === channel.id);

  if (idx === -1) {
    return interaction.reply({ embeds: [simpleEmbed(`${channel} isn't configured for prayer time reminders.`)], ephemeral: true });
  }

  entries.splice(idx, 1);
  saveDB(db);
  return interaction.reply({ embeds: [simpleEmbed(`✅ Prayer time reminders removed from ${channel}.`)] });
}

async function handleListAdzanChannels(interaction, db) {
  const entries = getAdzanChannels(db, CTX.guildId);
  saveDB(db);

  if (!entries.length) {
    return interaction.reply({ embeds: [simpleEmbed('No channels are configured for prayer time reminders yet. Use `/admin adzan set` to add one.')], ephemeral: true });
  }

  const list = entries.map(e => `• <#${e.channelId}> — **${e.raw}**${e.timezone ? ` (${e.timezone})` : ''}`).join('\n');
  const embed = new EmbedBuilder()
    .setColor(0x16a085)
    .setTitle('🕌 Adzan Reminder Channels')
    .setDescription(list);
  return interaction.reply({ embeds: [embed] });
}

// ---------------------------------------------------------------------------
function randInt(min, max) {
  return Math.floor(Math.random() * (max - min + 1)) + min;
}

// ---------------------------------------------------------------------------
// Errors here have no single guild to scope to (they aren't tied to one interaction), so as a
// best-effort we report them to every server that has configured an error log channel. This
// only runs for genuinely unexpected crashes — normal per-command errors are already handled
// and reported per-guild inside the interactionCreate handler above.
async function broadcastGlobalError(label, error) {
  console.error(`[${label}]`, error);
  try {
    const db = loadDB();
    const stack = (error && error.stack) ? error.stack.slice(0, 1000) : String(error).slice(0, 1000);
    const embed = new EmbedBuilder()
      .setColor(0xe74c3c)
      .setTitle(`⚠️ Bot Error — ${label}`)
      .addFields({ name: 'Details', value: `\`\`\`${stack}\`\`\`` })
      .setTimestamp();
    const guildIds = Object.keys(db.settings || {}).filter(id => db.settings[id]?.errorLogChannelId);
    for (const guildId of guildIds) {
      const channel = await client.channels.fetch(db.settings[guildId].errorLogChannelId).catch(() => null);
      if (channel) await channel.send({ embeds: [embed] }).catch(() => null);
    }
  } catch (_) {
    // Never let error reporting itself crash the process.
  }
}
process.on('unhandledRejection', (error) => broadcastGlobalError('Unhandled Rejection', error));
process.on('uncaughtException', (error) => broadcastGlobalError('Uncaught Exception', error));

// Fail fast and loud instead of hanging silently: a missing/blank token is one
// of the most common reasons a bot never reaches "Logged in as..." on a host
// like Wispbyte — without this check, client.login() just sits there trying
// (or fails with a cryptic low-level error) instead of telling you what's wrong.
if (!TOKEN) {
  console.error('❌ DISCORD_TOKEN is missing. Set it in your host\'s environment variables panel (or .env locally), then restart.');
  process.exit(1);
}
if (!CLIENT_ID) {
  console.error('❌ CLIENT_ID is missing. Set it in your host\'s environment variables panel (or .env locally), then restart.');
  process.exit(1);
}

// The Hijri and Persian calendar features rely on Node's built-in ICU data
// for the 'islamic-umalqura' and 'persian' calendar systems. Official Node.js
// 18+ builds from nodejs.org include full ICU by default, but some minimal
// Docker images used by budget hosts (a common setup on panels like
// Wispbyte) ship a stripped-down "small-icu" build that silently falls back
// to the Gregorian calendar instead of throwing an error — so /islamic hijri
// and /islamic persian would show a WRONG date with no error at all. Catch
// that here, once, at startup, so it's visible in the console immediately
// instead of discovered by a confused member days later.
function checkICUCalendarSupport() {
  const hijriCal = new Intl.DateTimeFormat('en-u-ca-islamic-umalqura').resolvedOptions().calendar;
  const persianCal = new Intl.DateTimeFormat('en-u-ca-persian').resolvedOptions().calendar;
  if (hijriCal !== 'islamic-umalqura') {
    console.warn(`⚠️ This Node.js build doesn't support the Islamic (Hijri) calendar (got calendar "${hijriCal}" instead of "islamic-umalqura"). /islamic hijri and the Hijri auto-calendar will show WRONG dates until this is fixed. This means Node was built without full ICU data — try a different Node.js version/image on your host, or ask your host to use an official Node.js 18+ build from nodejs.org.`);
  }
  if (persianCal !== 'persian') {
    console.warn(`⚠️ This Node.js build doesn't support the Persian calendar (got calendar "${persianCal}" instead of "persian"). /islamic persian and its auto-calendar will show WRONG dates until this is fixed — see the Hijri warning above for why.`);
  }
}
checkICUCalendarSupport();

console.log('Starting bot — connecting to Discord...');
const loginStallWarning = setTimeout(() => {
  console.warn('⚠️ Still not connected after 20s. This usually means: an invalid DISCORD_TOKEN, the "Server Members Intent" not enabled in the Developer Portal (Bot tab), or the host\'s network blocking the connection to Discord.');
}, 20000);

client.login(TOKEN)
  .then(() => clearTimeout(loginStallWarning))
  .catch((err) => {
    clearTimeout(loginStallWarning);
    console.error('❌ Failed to log in:', err.message || err);
    console.error('Double-check DISCORD_TOKEN is correct and current (tokens are invalidated if regenerated in the Developer Portal).');
  });
